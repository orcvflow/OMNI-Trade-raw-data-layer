// main.go — Raw Data Layer entry point
//
// Architecture: Single-process MVP wiring all components together.
// Data flow: [Adapters] → [Worker Pool] → [Canonicalizer] → [Validator]
//                                                               ↓
//                           [Strategies] ← [ZMQ Publisher] ← [WAL] → [DolphinDB]
//
// Design rules (CLAUDE.md):
//   - Never panic: every goroutine has defer/recover
//   - Never lose data: WAL is always-on before DolphinDB
//   - Never hang: bounded queues with explicit backpressure
//   - Always observable: /health HTTP endpoint
//   - Always recoverable: exponential backoff on reconnect
package main

import (
	"context"
	"flag"
	"fmt"
	"log/slog"
	"net/http"
	"os"
	"os/signal"
	"runtime"
	"syscall"
	"time"

	"raw-data-layer/pkg/adapter"
	"raw-data-layer/pkg/canonicalizer"
	"raw-data-layer/pkg/mapper"
	"raw-data-layer/pkg/publisher"
	"raw-data-layer/pkg/storage"
	"raw-data-layer/pkg/validation"
	"raw-data-layer/pkg/workerpool"
)

// ─────────────────────────────────────────────────────────────────────────────
// Config (simplified — production would use viper/yaml)
// ─────────────────────────────────────────────────────────────────────────────

type Config struct {
	MappingsDir string
	WALDir      string

	// Binance
	BinanceEnabled  bool
	BinanceEndpoint string
	BinanceSymbols  []string

	// IB
	IBEnabled bool
	IBHost    string
	IBPort    int

	// Worker Pool
	PoolWorkers   int
	PoolQueueSize int

	// ZeroMQ
	ZMQEnabled  bool
	ZMQEndpoint string

	// DolphinDB
	DBEnabled  bool
	DBHost     string
	DBPort     int
	DBUser     string
	DBPassword string

	// Health
	HealthPort int

	// Logging
	LogLevel string
}

func defaultConfig() Config {
	return Config{
		MappingsDir:     "./mappings",
		WALDir:          "./data/wal",
		BinanceEnabled:  true,
		BinanceEndpoint: "wss://testnet.binance.vision/ws",
		BinanceSymbols:  []string{"btcusdt", "ethusdt", "bnbusdt"},
		IBEnabled:       false, // disabled by default for MVP
		IBHost:          "localhost",
		IBPort:          7497,
		PoolWorkers:     50,
		PoolQueueSize:   10000,
		ZMQEnabled:      true,
		ZMQEndpoint:     "tcp://*:5555",
		DBEnabled:       false,
		DBHost:          "localhost",
		DBPort:          8848,
		DBUser:          "admin",
		DBPassword:      "123456",
		HealthPort:      8080,
		LogLevel:        "info",
	}
}

// ─────────────────────────────────────────────────────────────────────────────
// Application
// ─────────────────────────────────────────────────────────────────────────────

type App struct {
	cfg      Config
	log      *slog.Logger
	ctx      context.Context
	cancel   context.CancelFunc

	// Components
	symbolMapper *mapper.SymbolMapper
	canon        *canonicalizer.Canonicalizer
	pool         *workerpool.Pool
	validator    *validation.Validator
	zmqPub       *publisher.ZMQPublisher
	wal          *storage.WAL
	dbWriter     *storage.DolphinDBWriter

	// Adapters
	adapters []adapter.Adapter
	rawCh    chan adapter.RawMessage
}

func newApp(cfg Config) *App {
	ctx, cancel := context.WithCancel(context.Background())

	level := slog.LevelInfo
	if cfg.LogLevel == "debug" {
		level = slog.LevelDebug
	}

	logger := slog.New(slog.NewJSONHandler(os.Stdout, &slog.HandlerOptions{Level: level}))

	return &App{
		cfg:      cfg,
		log:      logger,
		ctx:      ctx,
		cancel:   cancel,
		rawCh:    make(chan adapter.RawMessage, cfg.PoolQueueSize),
		adapters: make([]adapter.Adapter, 0),
	}
}

// init wires up all components.
func (a *App) init() error {
	// Never panic at the top level
	defer func() {
		if r := recover(); r != nil {
			a.log.Error("panic in init", "recover", fmt.Sprintf("%v", r))
		}
	}()

	a.log.Info("initializing raw-data-layer",
		"go_version", runtime.Version(),
		"gomaxprocs", runtime.GOMAXPROCS(0),
	)

	// 1. Symbol mapper
	sm, err := mapper.NewSymbolMapper(a.cfg.MappingsDir)
	if err != nil {
		return fmt.Errorf("symbol mapper: %w", err)
	}
	a.symbolMapper = sm
	a.log.Info("symbol mapper initialized", "sources", sm.GetSources())

	// 2. Canonicalizer
	a.canon = canonicalizer.NewCanonicalizer(sm)

	// 3. Worker pool
	poolCfg := workerpool.PoolConfig{
		MinWorkers:         a.cfg.PoolWorkers,
		MaxWorkers:         a.cfg.PoolWorkers * 2,
		QueueSize:          a.cfg.PoolQueueSize,
		AutoscaleEnabled:   true,
		ScaleUpThreshold:   0.8,
		ScaleDownThreshold: 0.5,
	}
	a.pool = workerpool.NewPool(poolCfg, a.canon.Process)

	// 4. Validator
	a.validator = validation.NewValidator(validation.DefaultValidationRules())

	// 5. WAL — always started, even if DolphinDB is enabled
	walCfg := storage.WALConfig{
		Directory:      a.cfg.WALDir,
		MaxFileSize:    100 * 1024 * 1024, // 100MB
		MaxMessages:    10000,
		RotateInterval: 1 * time.Minute,
	}
	wal, err := storage.NewWAL(walCfg)
	if err != nil {
		return fmt.Errorf("WAL: %w", err)
	}
	a.wal = wal

	// 6. DolphinDB writer (optional)
	dbCfg := storage.DolphinDBConfig{
		Host:         a.cfg.DBHost,
		Port:         a.cfg.DBPort,
		Username:     a.cfg.DBUser,
		Password:     a.cfg.DBPassword,
		Database:     "raw_data",
		BatchSize:    1000,
		BatchTimeout: 1 * time.Second,
	}
	a.dbWriter = storage.NewDolphinDBWriter(dbCfg, a.wal)

	// 7. ZeroMQ publisher (optional)
	if a.cfg.ZMQEnabled {
		zmqCfg := publisher.PublisherConfig{
			Endpoint:          a.cfg.ZMQEndpoint,
			HeartbeatInterval: 5 * time.Second,
			SendTimeout:       1 * time.Second,
		}
		pub, err := publisher.NewZMQPublisher(zmqCfg)
		if err != nil {
			// Non-fatal: continue without ZMQ
			a.log.Warn("ZMQ publisher init failed (continuing without ZMQ)", "error", err)
		} else {
			a.zmqPub = pub
		}
	}

	// 8. Adapters
	adapterCfg := adapter.AdapterConfig{
		Enabled:           true,
		ReconnectAttempts: 10,
		BackoffSeconds:    []int{1, 2, 4, 8, 16, 30},
		Timeout:           10 * time.Second,
	}

	if a.cfg.BinanceEnabled {
		b := adapter.NewBinanceAdapter(a.cfg.BinanceEndpoint, a.cfg.BinanceSymbols, adapterCfg)
		a.adapters = append(a.adapters, b)
	}

	if a.cfg.IBEnabled {
		ib := adapter.NewIBAdapter(a.cfg.IBHost, a.cfg.IBPort, 1, []string{"AAPL", "MSFT", "GOOGL"}, adapterCfg)
		a.adapters = append(a.adapters, ib)
	}

	a.log.Info("components initialized",
		"adapters", len(a.adapters),
		"zmq", a.cfg.ZMQEnabled,
		"db", a.cfg.DBEnabled,
	)
	return nil
}

// start launches all background goroutines.
func (a *App) start() error {
	// WAL
	if err := a.wal.Start(); err != nil {
		return fmt.Errorf("WAL start: %w", err)
	}
	a.log.Info("WAL started", "dir", a.cfg.WALDir)

	// DolphinDB (attempt connect; failure is non-fatal — WAL takes over)
	a.dbWriter.Start()
	if a.cfg.DBEnabled {
		if err := a.dbWriter.Connect(); err != nil {
			a.log.Warn("DolphinDB connect failed — WAL-only mode", "error", err)
		} else {
			a.log.Info("DolphinDB connected", "host", a.cfg.DBHost, "port", a.cfg.DBPort)
		}
	}

	// ZeroMQ
	if a.zmqPub != nil {
		if err := a.zmqPub.Start(); err != nil {
			a.log.Warn("ZMQ start failed (continuing without ZMQ)", "error", err)
			a.zmqPub = nil
		} else {
			a.log.Info("ZMQ publisher started", "endpoint", a.cfg.ZMQEndpoint)
		}
	}

	// Worker pool
	if err := a.pool.Start(); err != nil {
		return fmt.Errorf("pool start: %w", err)
	}
	a.log.Info("worker pool started",
		"min_workers", a.cfg.PoolWorkers,
		"queue_size", a.cfg.PoolQueueSize,
	)

	// Output pipeline goroutine: pool output → validate → publish → store
	go a.outputPipeline()

	// Adapters
	for _, adp := range a.adapters {
		adpCopy := adp
		if err := adpCopy.Connect(a.ctx); err != nil {
			a.log.Warn("adapter connect failed (will retry)", "adapter", adpCopy.Name(), "error", err)
		}
		if err := adpCopy.Start(a.ctx, a.rawCh); err != nil {
			a.log.Error("adapter start failed", "adapter", adpCopy.Name(), "error", err)
			continue
		}
		a.log.Info("adapter started", "name", adpCopy.Name())
	}

	// Fan-in goroutine: rawCh → worker pool
	go a.fanIn()

	// Health HTTP server
	go a.serveHealth()

	a.log.Info("raw-data-layer started successfully")
	return nil
}

// fanIn reads from rawCh and submits to worker pool.
func (a *App) fanIn() {
	defer func() {
		if r := recover(); r != nil {
			a.log.Error("panic in fanIn", "recover", fmt.Sprintf("%v", r))
		}
	}()

	for {
		select {
		case <-a.ctx.Done():
			return
		case msg, ok := <-a.rawCh:
			if !ok {
				return
			}
			if err := a.pool.Submit(msg); err != nil {
				// Backpressure — log at debug to avoid log spam
				a.log.Debug("backpressure", "source", msg.Source, "error", err)
			}
		}
	}
}

// outputPipeline reads from pool output and runs validate → publish → store.
func (a *App) outputPipeline() {
	defer func() {
		if r := recover(); r != nil {
			a.log.Error("panic in outputPipeline", "recover", fmt.Sprintf("%v", r))
		}
	}()

	for processed := range a.pool.Output() {
		if processed.Error != nil {
			a.log.Debug("processing error (raw preserved)", "error", processed.Error)
		}

		// Build canonical event from raw (re-canonicalize for validation)
		ev := &canonicalizer.CanonicalEvent{
			EventID:           fmt.Sprintf("evt_%d", time.Now().UnixNano()),
			Source:            processed.Raw.Source,
			CanonicalSymbol:   a.symbolMapper.ToCanonical(processed.Raw.Source, ""),
			ExchangeTimestamp: processed.Raw.ReceivedAt,
			LocalHWTimestamp:  time.Now().UnixNano(),
			EventType:         "TRADE",
			RawPayload:        processed.Raw.Payload,
			RawFormat:         "JSON",
		}

		// Layer validation
		startNs := time.Now().UnixNano()
		result := a.validator.Validate(ev, startNs)
		if !result.Passed {
			a.log.Debug("validation failed", "event_id", ev.EventID, "layers", result.Layers)
		}

		// Publish via ZMQ (best-effort)
		if a.zmqPub != nil {
			if err := a.zmqPub.Publish(ev); err != nil {
				a.log.Debug("zmq publish error", "error", err)
			}
		}

		// Store — WAL first, then DolphinDB (inside dbWriter)
		if err := a.dbWriter.Write(ev); err != nil {
			a.log.Warn("dbWriter.Write error", "error", err)
		}
	}
}

// serveHealth starts the HTTP health check server.
func (a *App) serveHealth() {
	defer func() {
		if r := recover(); r != nil {
			a.log.Error("panic in serveHealth", "recover", fmt.Sprintf("%v", r))
		}
	}()

	mux := http.NewServeMux()

	mux.HandleFunc("/health", a.healthHandler)
	mux.HandleFunc("/ready", a.readinessHandler)
	mux.HandleFunc("/live", a.livenessHandler)

	addr := fmt.Sprintf(":%d", a.cfg.HealthPort)
	srv := &http.Server{
		Addr:         addr,
		Handler:      mux,
		ReadTimeout:  5 * time.Second,
		WriteTimeout: 10 * time.Second,
	}

	a.log.Info("health server starting", "addr", addr)
	if err := srv.ListenAndServe(); err != nil && err != http.ErrServerClosed {
		a.log.Error("health server error", "error", err)
	}
}

func (a *App) healthHandler(w http.ResponseWriter, r *http.Request) {
	poolStats := a.pool.Stats()
	walStats := a.wal.Stats()
	dbStats := a.dbWriter.Stats()
	valStats := a.validator.Stats()

	var memStats runtime.MemStats
	runtime.ReadMemStats(&memStats)

	status := "ok"
	if !poolStats.IsHealthy() {
		status = "degraded"
	}

	w.Header().Set("Content-Type", "application/json")
	if status != "ok" {
		w.WriteHeader(http.StatusServiceUnavailable)
	}

	fmt.Fprintf(w, `{
  "status": %q,
  "timestamp": %q,
  "pool": {"workers": %d, "queue_depth": %d, "processed": %d, "dropped": %d},
  "wal": {"running": %v, "total_written": %d, "rotations": %d},
  "db": {"connected": %v, "total_written": %d, "pending": %d},
  "validation": {"total": %d, "pass_rate": %.3f},
  "memory": {"alloc_mb": %.1f, "sys_mb": %.1f, "goroutines": %d}
}`,
		status,
		time.Now().UTC().Format(time.RFC3339),
		poolStats.ActiveWorkers, poolStats.QueueDepth, poolStats.Processed, poolStats.Dropped,
		walStats.Running, walStats.TotalWritten, walStats.TotalRotations,
		dbStats.Connected, dbStats.TotalWritten, dbStats.PendingBatch,
		valStats.TotalValidated, valStats.PassRate,
		float64(memStats.Alloc)/1024/1024, float64(memStats.Sys)/1024/1024, runtime.NumGoroutine(),
	)
}

func (a *App) readinessHandler(w http.ResponseWriter, r *http.Request) {
	if a.pool.Stats().ActiveWorkers > 0 {
		w.WriteHeader(http.StatusOK)
		fmt.Fprint(w, `{"ready":true}`)
	} else {
		w.WriteHeader(http.StatusServiceUnavailable)
		fmt.Fprint(w, `{"ready":false}`)
	}
}

func (a *App) livenessHandler(w http.ResponseWriter, r *http.Request) {
	w.WriteHeader(http.StatusOK)
	fmt.Fprint(w, `{"alive":true}`)
}

// stop gracefully shuts down all components.
func (a *App) stop() {
	a.log.Info("shutting down...")

	// Cancel context → signals all goroutines
	a.cancel()

	// Stop adapters
	for _, adp := range a.adapters {
		if err := adp.Stop(); err != nil {
			a.log.Warn("adapter stop error", "adapter", adp.Name(), "error", err)
		}
	}
	close(a.rawCh)

	// Stop pool (flushes output)
	a.pool.Stop()

	// Stop ZMQ
	if a.zmqPub != nil {
		a.zmqPub.Stop()
	}

	// Stop DB writer (flushes batch)
	a.dbWriter.Stop()

	// Stop WAL (flushes buffer)
	a.wal.Stop()

	a.log.Info("shutdown complete")
}

// ─────────────────────────────────────────────────────────────────────────────
// main
// ─────────────────────────────────────────────────────────────────────────────

func main() {
	// Never panic at main level
	defer func() {
		if r := recover(); r != nil {
			fmt.Fprintf(os.Stderr, "FATAL PANIC: %v\n", r)
			os.Exit(1)
		}
	}()

	cfg := defaultConfig()

	// CLI flags override defaults
	flag.StringVar(&cfg.MappingsDir, "mappings", cfg.MappingsDir, "Path to symbol mapping JSON files")
	flag.StringVar(&cfg.WALDir, "wal-dir", cfg.WALDir, "WAL storage directory")
	flag.BoolVar(&cfg.BinanceEnabled, "binance", cfg.BinanceEnabled, "Enable Binance adapter")
	flag.BoolVar(&cfg.IBEnabled, "ib", cfg.IBEnabled, "Enable IB Gateway adapter")
	flag.BoolVar(&cfg.ZMQEnabled, "zmq", cfg.ZMQEnabled, "Enable ZeroMQ publisher")
	flag.BoolVar(&cfg.DBEnabled, "db", cfg.DBEnabled, "Enable DolphinDB writer")
	flag.StringVar(&cfg.DBHost, "db-host", cfg.DBHost, "DolphinDB host")
	flag.IntVar(&cfg.DBPort, "db-port", cfg.DBPort, "DolphinDB port")
	flag.IntVar(&cfg.HealthPort, "health-port", cfg.HealthPort, "Health check HTTP port")
	flag.StringVar(&cfg.LogLevel, "log-level", cfg.LogLevel, "Log level (debug|info|warn|error)")
	flag.Parse()

	app := newApp(cfg)

	if err := app.init(); err != nil {
		fmt.Fprintf(os.Stderr, "init error: %v\n", err)
		os.Exit(1)
	}

	if err := app.start(); err != nil {
		fmt.Fprintf(os.Stderr, "start error: %v\n", err)
		os.Exit(1)
	}

	// Wait for shutdown signal
	quit := make(chan os.Signal, 1)
	signal.Notify(quit, syscall.SIGINT, syscall.SIGTERM)
	sig := <-quit

	app.log.Info("received signal", "signal", sig.String())
	app.stop()
}
