---
tags: [MOC, master-index, causal-raw-data-engine, prompt-infrastructure]
category: map-of-content
module: causal-raw-data-engine
created: 2026-07-11
version: 1.0
---

# MMS Causal Raw Data Engine — Prompt İnfrastrukturu Master İndeks

> **Vizyon:** Maliyyə bazarlarını ehtimal nəzəriyyəsinin (stoxastik) yalanlarından təmizləyib, Deterministik Fizika və Riyazi Aksiomlar çərçivəsində modelləşdirən "Süni İntellekt Orqanizmi"nin Module 1-i.

---

## 🏗️ Arxitektura Prinsipi

```
┌─────────────────────────────────────────────────────────────────────┐
│                    BIRJA SERVERİ (ITCH/FIX/WS)                      │
│              Raw Bytes: price, volume, timestamp                     │
└──────────────────────────┬──────────────────────────────────────────┘
                           │
                           ▼
┌─────────────────────────────────────────────────────────────────────┐
│  ╔══════════════════════════════════════════════════════════════╗   │
│  ║  MODULE 1: CAUSAL RAW DATA ENGINE  (bu layihə)              ║   │
│  ║                                                              ║   │
│  ║  ┌─────────────┐   ┌──────────────┐   ┌───────────────┐    ║   │
│  ║  │ decode_to_  │──▶│ process_tick │──▶│  Ring Buffer  │    ║   │
│  ║  │   q32()     │   │   _batch()   │   │  (Q32.32)     │    ║   │
│  ║  │ zero-copy   │   │ HOT PATH     │   │  Pre-alloc    │    ║   │
│  ║  │ frombuffer  │   │ Branchless   │   │  Cache-align  │    ║   │
│  ║  └─────────────┘   └──────────────┘   └───────┬───────┘    ║   │
│  ║         │                   │                   │            ║   │
│  ║    ┌────┴────┐     ┌───────┴────────┐    ┌─────┴─────┐     ║   │
│  ║    │ Q32.32  │     │ Aristotel Gate │    │ Signature │     ║   │
│  ║    │ Fixed   │     │ Hamiltonian KE │    │ (Rough    │     ║   │
│  ║    │ Point   │     │ Bounds Check   │    │  Path)    │     ║   │
│  ║    └─────────┘     └────────────────┘    └───────────┘     ║   │
│  ╚══════════════════════════════════════════════════════════════╝   │
└──────────────────────────┬──────────────────────────────────────────┘
                           │
                           ▼
┌─────────────────────────────────────────────────────────────────────┐
│              TƏMİZ CAUSAL MATRISLƏR (downstream modullar)           │
│    [Price Matrix]  [Volume Matrix]  [Energy Matrix]  [Signature]   │
│    dtype: uint64   dtype: uint64    dtype: uint64    dtype: uint64 │
│    format: Q32.32  format: Q32.32   format: Q32.32   format: Q32.32│
└─────────────────────────────────────────────────────────────────────┘
```

---

## 📂 Fayl Strukturu

```
MMS_RAW_DATA/
├── 00_MASTER_INDEX.md              ← bu fayl
├── AXTARIS_SXEMI.md               ← prompt istifadə ardıcıllığı
│
├── academic_search/               ← 6 akademik axtarış promtu
│   ├── 01_rough_path_signature_theory.md
│   ├── 02_hamiltonian_mechanics_finance.md
│   ├── 03_fixed_point_arithmetic_hft.md
│   ├── 04_branchless_programming_cpu.md
│   ├── 05_ring_buffer_zero_alloc.md
│   └── 06_causal_inference_tick_data.md
│
├── system_roles/                  ← 6 AI agent rolu
│   ├── 01_axiomatic_systems_engineer.md
│   ├── 02_rough_path_mathematician.md
│   ├── 03_fixed_point_arithmetic_specialist.md
│   ├── 04_branchless_code_auditor.md
│   ├── 05_hot_path_performance_engineer.md
│   └── 06_raw_data_engine_builder.md
│
└── engineering_specs/             ← 6 mühəndislik spesifikasiyası
    ├── 01_causal_raw_data_engine_class.md
    ├── 02_q32_32_fixed_point_spec.md
    ├── 03_branchless_tick_validation.md
    ├── 04_hamiltonian_energy_matrix.md
    ├── 05_rough_path_signature_computation.md
    └── 06_axiomatic_unit_tests.md
```

---

## 🔄 İstifadə Axını (Workflow)

### Faz 1: Akademik Təməl (Günlər 1-3)
```
01_rough_path → 02_hamiltonian → 03_fixed_point → 04_branchless → 05_ring_buffer → 06_causal
     │               │               │                │               │              │
     ▼               ▼               ▼                ▼               ▼              ▼
  Lyons et al.   Baaquie et al.   Q-format refs   Pipeline refs  Disruptor refs  Granger refs
```
**Çıxış:** DOI-doğrulanmış ədəbiyyat bazası

### Faz 2: Agent Rollarını Yarat (Gün 4)
```
Hər sistem rolu bir AI agent-inin "system prompt"u olur.
06_raw_data_engine_builder MASTER roludur — digər 5 rolu sintez edir.
```
**Çıxış:** 6 ixtisaslaşmış AI agent

### Faz 3: Mühəndislik İmplementasiyası (Günlər 5-14)
```
Spec 01 (Core Class)
  ├── Spec 02 (Q32.32) ── hər əməliyyat üçün test
  ├── Spec 03 (Validation) ── Aristotel + Bounds + Volume gate
  ├── Spec 04 (Hamiltonian) ── enerji matrisi
  ├── Spec 05 (Signature) ── rough path streaming
  └── Spec 06 (Tests) ── aksiomatik doğrulama
```
**Çıxış:** Tam işləyən CausalRawDataEngine sinfi

---

## 📊 Prompt Növü Müqayisəsi

| Növ | Say | Məqsəd | İstifadəçi |
|-----|-----|--------|------------|
| **Akademik Axtarış** | 6 | Ədəbiyyat bazası qurmaq | Tədqiqatçı agent |
| **Sistem Rolu** | 6 | AI agent şəxsiyyəti | Hər kod agent-i |
| **Mühəndislik Spec** | 6 | İmplementasiya planı | Kod yazan agent |
| **CƏMİ** | **18** | — | — |

---

## 🎯 MMS Konstitusiyası Uyğunluğu

| Konstitusiya Qaydası | Promptlarda Tətbiqi |
|---------------------|---------------------|
| §1 — 7 Rolu Ruthless Council | Hər sistem rolu bir council üzvünü təmsil edir |
| §2.2 — 3 Sübut Növü | Akademik promtlar DOI doğrulaması tələb edir |
| §2.3 — Hot Path Qaydaları | Mühəndislik speclərində hər əməliyyat branchless/zero-alloc |
| §2.4 — Monetiar Dəqiqlik | Q32.32 spec-i ayrıca fayl |
| §2.5 — Falsifikasiya | Hər spec-də falsifikasiya şərtləri |
| §4 — Məcburi Özünütənqid | Hər agent rolunda embedded |
| §5 — Etibar Etiketləri | Hər faylda 🟢/🟡/🔴 |

---

## 🔑 Əsas Riyazi Modellər

### 1. Rough Path Signature (T. Lyons, 1998)
$$S(X)_{s,t} = 1 + \int_s^t dX + \int_s^t \int_s^u dX \otimes dX + \cdots$$

**Tətbiq:** Tick data-nın causal strukturunu itirmədən sıx representasiya.

### 2. Hamiltonian Mexanikası
$$H(Q, P) = T(P) + V(Q) = \frac{P^2}{2m} + V(Q)$$

**Tətbiq:** Q=qiymət, P=həcm. Kinetik enerji: `(P * P) >> 32` (Q32.32).

### 3. Aristotel Məntiqi (Səbəb-Nəticə)
$$\text{Volume} = 0 \implies \Delta\text{Price} = 0$$

**Tətbiq:** `mask = (vol == 0).astype(uint64); price = mask * prev + (1-mask) * new`

---

## 📚 Kritik İstinadlar (DOI Doğrulanmalıdır)

| Mövzu | Müəllif | İl | Status |
|-------|---------|-----|--------|
| Rough Path Theory | T. Lyons | 1998 | Axtarılır (Prompt 01) |
| Quantum Finance | Baaquie | 2004 | Axtarılır (Prompt 02) |
| Crypto Wash Trading | Cong et al. | 2023 | DOI: 10.1287/mnsc.2021.02709 ✓ |
| Volume Clocks | Easley et al. | 2012 | DOI: 10.3905/jpm.2012.39.1.019 ✓ |
| Variable-lag GC | Amornbunchornvej | 2021 | DOI: 10.1145/3441452 ✓ |
| AF_XDP Latency | IEEE ICC'24 | 2024 | DOI: arXiv:2402.10513 ✓ |

---

## ⚠️ Qadağan Edilmiş Nümunələr (Anti-Patterns)

| Qadağan | Səbəb | Əvəz |
|---------|-------|------|
| `float`, `double` | IEEE 754 qeyri-dəqiqlik | `uint64` Q32.32 |
| `if/else` (hot path) | Branch misprediction ~15ns | Bitwise mask |
| `list.append()` | Heap allocation + GC | Ring buffer yaz |
| `dict[key]` | Hash computation + collision | Static array index |
| `try/catch` | Exception = hidden branch | Sentinel value + mask |
| `a / b` | Division ~20 cycles | `(a << 32) / b` yalnız cold path |
| `math.sqrt()` | Transcendental function | Yaxınlaşma (integer Newton) |

---

AZ Xülasəsi: Bu indeks faylı MMS Causal Raw Data Engine layihəsinin 18 promptunu (6 akademik + 6 rol + 6 spec) birləşdirən master naviqasiya sənədidir. İstifadə axını, arxitektura diaqramı və konstitusiya uyğunluq cədvəli daxildir.
