"""
MMS Causal Raw Data Engine — Academic Search Prompts
=====================================================

Module 1 akademik axtarış promtlarının kəşf, yüklənmə və metadata çıxarılması
üçün Python interfeysi. Bu paket 6 ixtisaslaşmış axtarış promtu ehtiva edir —
hər biri DOI-doğrulanmış ədəbiyyat bazası qurmaq üçün nəzərdə tutulub.

Project:    MMS Quant Research
Module:     Causal Raw Data Engine (Module 1)
Category:   prompt-infrastructure / academic-search
Created:    2026-07-11
Version:    1.0

MMS Konstitusiyası Uyğunluğu
-----------------------------
- §2.2 — Yalnız 3 sübut növü: Riyazi (tavtologiya), İqtisadi (DOI), Statistik (öz data)
- §2.3 — Hot path: division YOX, sqrt YOX, float YOX, heap allocation YOX
- §2.5 — Hər promtda falsifikasiya şərtləri mövcuddur
- §5   — Etibar etiketləri: 🟢 VERIFIED / 🟡 PARTIALLY VERIFIED / 🔴 UNVERIFIED

İstifadə
--------
    from search_prompts.MMS_RAW_DATA.academic_search import (
        PROMPT_REGISTRY,
        get_prompt,
        get_prompt_path,
        parse_frontmatter,
        list_prompts,
    )

    # Bütün promtların siyahısı
    for prompt_id, meta in PROMPT_REGISTRY.items():
        print(f"{prompt_id}: {meta['title']}")

    # Tək promtun məzmununu oxu
    content = get_prompt("01_rough_path_signature_theory")

    # Frontmatter metadata çıxar
    meta = parse_frontmatter("01_rough_path_signature_theory")
    print(meta["tags"])

Faza 1 İcra Sxemi (AXTARIS_SXEMI.md-ə əsasən)
-----------------------------------------------
    Agent-A ──▶ 01_rough_path_signature_theory
    Agent-B ──▶ 02_hamiltonian_mechanics_finance
    Agent-C ──▶ 03_fixed_point_arithmetic_hft
    Agent-D ──▶ 04_branchless_programming_cpu
    Agent-E ──▶ 05_ring_buffer_zero_alloc
    Agent-F ──▶ 06_causal_inference_tick_data

    ÇIXIŞ MEYARI: Hər agent minimum 5 DOI-doğrulanmış paper qaytarmalıdır.

Anti-Patternlər (QADAĞAN)
--------------------------
- Prompt fayllarını runtime-da dəyişdirmək (read-only resurslardır)
- DOI doğrulamasını ötürmək (hər paper doi.org-da yoxlanmalıdır)
- "Hamı bilir ki" əsaslandırması (MMS §2.2 pozuntusu)
- Placeholder nəticələr qəbul etmək (minimum 5 DOI paper tələbi)

Fayl Strukturu
--------------
    academic_search/
    ├── __init__.py                                    ← bu fayl
    ├── 01_rough_path_signature_theory.md              ← Rough Path / Lyons signatures
    ├── 02_hamiltonian_mechanics_finance.md            ← Hamiltonian / Baaquie / symplectic
    ├── 03_fixed_point_arithmetic_hft.md               ← Q32.32 / FPGA / division-free
    ├── 04_branchless_programming_cpu.md               ← CMOV / SIMD / pipeline hazards
    ├── 05_ring_buffer_zero_alloc.md                   ← SPSC / Disruptor / cache-line
    └── 06_causal_inference_tick_data.md               ← Granger / transfer entropy / PC algo

Asılılıqlar
-----------
    stdlib only: pathlib, re, typing (xarici paket tələb olunmur)

Etibar Etiketi
--------------
    🟢 VERIFIED — Bu modul metodologiyadır, iddia deyil. Axtarış sorğuları
    özlüyündə heç bir faktiki iddia irəli sürmür; yalnız mövcud ədəbiyyatı
    tapmaq üçün vasitədir.
"""

from __future__ import annotations

import re
from pathlib import Path
from typing import Any

# ---------------------------------------------------------------------------
# Sabitlər (Constants)
# ---------------------------------------------------------------------------

#: Bu paketin kök qovluğu
_PACKAGE_DIR: Path = Path(__file__).resolve().parent

#: Promt fayl adı → metadata cütlüyü.
#: Qeydiyyat sırası AXTARIS_SXEMI.md Faza 1 icra ardıcıllığını əks etdirir.
PROMPT_REGISTRY: dict[str, dict[str, Any]] = {
    "01_rough_path_signature_theory": {
        "filename": "01_rough_path_signature_theory.md",
        "title": "Rough Path Theory & Path Signatures",
        "domain": "rough-path",
        "key_authors": ["Lyons", "Friz", "Hairer", "Chevyrev"],
        "arxiv_categories": ["math.PR", "q-fin.CP", "q-fin.ST", "cs.NA", "stat.ML"],
        "date_range": "1998–2026",
        "mms_constitution_refs": ["§2.2", "§2.3", "§2.5"],
        "search_query_count": 10,
    },
    "02_hamiltonian_mechanics_finance": {
        "filename": "02_hamiltonian_mechanics_finance.md",
        "title": "Hamiltonian Mechanics in Financial Systems",
        "domain": "hamiltonian-mechanics",
        "key_authors": ["Baaquie", "Bouchaud", "Potters", "Lillo"],
        "arxiv_categories": ["q-fin.GN", "q-fin.ST", "q-fin.TR", "physics.soc-ph", "math.SG"],
        "date_range": "1995–2026",
        "mms_constitution_refs": ["§2.2", "§2.3", "§2.5"],
        "search_query_count": 10,
    },
    "03_fixed_point_arithmetic_hft": {
        "filename": "03_fixed_point_arithmetic_hft.md",
        "title": "Fixed-Point Arithmetic for High-Frequency Trading",
        "domain": "fixed-point-arithmetic",
        "key_authors": ["Kahan", "Koren", "Muller", "Treleaven"],
        "arxiv_categories": ["cs.AR", "cs.NA", "q-fin.CP", "q-fin.TR"],
        "date_range": "1990–2026",
        "mms_constitution_refs": ["§2.2", "§2.3", "§2.4", "§2.5"],
        "search_query_count": 10,
    },
    "04_branchless_programming_cpu": {
        "filename": "04_branchless_programming_cpu.md",
        "title": "Branchless Programming & CPU Pipeline Optimization",
        "domain": "branchless-programming",
        "key_authors": ["Fog", "Lemire", "Thompson", "Carruth"],
        "arxiv_categories": ["cs.AR", "cs.PF", "cs.PL"],
        "date_range": "2000–2026",
        "mms_constitution_refs": ["§2.2", "§2.3", "§2.5"],
        "search_query_count": 10,
    },
    "05_ring_buffer_zero_alloc": {
        "filename": "05_ring_buffer_zero_alloc.md",
        "title": "Ring Buffer, Zero-Allocation & Lock-Free Data Structures",
        "domain": "zero-allocation",
        "key_authors": ["Thompson", "Herlihy", "Shavit", "Vyukov"],
        "arxiv_categories": ["cs.DC", "cs.DS", "cs.PF", "cs.OS"],
        "date_range": "1991–2026",
        "mms_constitution_refs": ["§2.2", "§2.3", "§2.5"],
        "search_query_count": 10,
    },
    "06_causal_inference_tick_data": {
        "filename": "06_causal_inference_tick_data.md",
        "title": "Causal Inference in High-Frequency Financial Data",
        "domain": "causal-inference",
        "key_authors": ["Granger", "Schreiber", "Spirtes", "Pearl"],
        "arxiv_categories": ["stat.ME", "stat.ML", "q-fin.ST", "cs.IT", "cs.LG"],
        "date_range": "1969–2026",
        "mms_constitution_refs": ["§2.2", "§2.3", "§2.5"],
        "search_query_count": 10,
    },
}

#: YAML frontmatter-dən çıxarılan sahə adları
_FRONTMATTER_FIELDS: frozenset[str] = frozenset({
    "tags", "category", "module", "created", "trust",
})

#: Frontmatter regex — faylın əvvəlindəki --- bloku
_FRONTMATTER_RE: re.Pattern[str] = re.compile(
    r"\A---\s*\n(.*?)\n---", re.DOTALL
)

#: Minimum DOI-doğrulanmış paper sayı (AXTARIS_SXEMI.md Qapı 1)
MIN_DOI_PAPERS_PER_PROMPT: int = 5

#: Maksimum agent cəhdi (AXTARIS_SXEMI.md Xəta Bərpa Protokolü)
MAX_AGENT_RETRIES: int = 3

# ---------------------------------------------------------------------------
# Fayl Yükləmə (File Loading)
# ---------------------------------------------------------------------------


def get_prompt_path(prompt_id: str) -> Path:
    """Promt ID-sinə görə fayl yolunu qaytarır.

    Parameters
    ----------
    prompt_id : str
        Qeydiyyatdakı açar, məs. ``"01_rough_path_signature_theory"``.
        ``.md`` uzantısı isteğe bağlıdır — avtomatik əlavə olunur.

    Returns
    -------
    Path
        Faylın mütləq yolu.

    Raises
    ------
    KeyError
        ``prompt_id`` qeydiyyatda yoxdursa.
    FileNotFoundError
        Fayl diskdə mövcud deyilsə.
    """
    if prompt_id not in PROMPT_REGISTRY:
        raise KeyError(
            f"Naməlum promt ID: {prompt_id!r}. "
            f"Mövcud ID-lər: {list(PROMPT_REGISTRY)}"
        )
    path = _PACKAGE_DIR / PROMPT_REGISTRY[prompt_id]["filename"]
    if not path.exists():
        raise FileNotFoundError(f"Promt faylı tapılmadı: {path}")
    return path


def get_prompt(prompt_id: str) -> str:
    """Promt faylının tam məzmununu UTF-8 string kimi qaytarır.

    Parameters
    ----------
    prompt_id : str
        Qeydiyyatdakı açar.

    Returns
    -------
    str
        Faylın tam məzmunu (frontmatter daxil).
    """
    return get_prompt_path(prompt_id).read_text(encoding="utf-8")


# ---------------------------------------------------------------------------
# Frontmatter Ayrıştırma (Frontmatter Parsing)
# ---------------------------------------------------------------------------


def parse_frontmatter(prompt_id: str) -> dict[str, Any]:
    """Promt faylının YAML frontmatter-ini sadə ayrışdırıcı ilə çıxarır.

    Xəbərdarlıq: Bu, tam YAML parser DEYİL — sadə ``key: value`` və
    ``key: [list]`` formatlarını dəstəkləyir. Mürəkkəb YAML strukturları
    üçün ``pyyaml`` istifadə edin.

    Parameters
    ----------
    prompt_id : str
        Qeydiyyatdakı açar.

    Returns
    -------
    dict[str, Any]
        Frontmatter sahələri. Məs.::

            {
                "tags": ["search-prompt", "rough-path", ...],
                "category": "academic-search",
                "module": "causal-raw-data-engine",
                "created": "2026-07-11",
                "trust": "🟢 VERIFIED ...",
            }
    """
    content = get_prompt(prompt_id)
    match = _FRONTMATTER_RE.match(content)
    if match is None:
        return {}

    raw_block = match.group(1)
    result: dict[str, Any] = {}

    for line in raw_block.splitlines():
        line = line.strip()
        if not line or ":" not in line:
            continue
        key, _, value = line.partition(":")
        key = key.strip()
        value = value.strip()

        # Sadə YAML list: [item1, item2, ...]
        if value.startswith("[") and value.endswith("]"):
            items = value[1:-1].split(",")
            result[key] = [item.strip().strip("\"'") for item in items if item.strip()]
        else:
            result[key] = value.strip("\"'")

    return result


# ---------------------------------------------------------------------------
# Kəşf API-si (Discovery API)
# ---------------------------------------------------------------------------


def list_prompts(
    *,
    domain: str | None = None,
    tag: str | None = None,
) -> list[str]:
    """Qeydiyyatdakı promt ID-lərini siyahılayır, isteğe bağlı filtr ilə.

    Parameters
    ----------
    domain : str, optional
        Domen adına görə filtr, məs. ``"rough-path"``.
    tag : str, optional
        Frontmatter tag-ına görə filtr (disk oxuma tələb edir).

    Returns
    -------
    list[str]
        Filtrlənmiş promt ID-ləri.
    """
    ids = list(PROMPT_REGISTRY)

    if domain is not None:
        ids = [
            pid for pid in ids
            if PROMPT_REGISTRY[pid]["domain"] == domain
        ]

    if tag is not None:
        filtered: list[str] = []
        for pid in ids:
            meta = parse_frontmatter(pid)
            tags = meta.get("tags", [])
            if isinstance(tags, list) and tag in tags:
                filtered.append(pid)
        ids = filtered

    return ids


def get_search_queries(prompt_id: str) -> list[str]:
    """Promt faylından bütün axtarış sorğularını çıxarır.

    Hər sorğu `` ``` `` fenced code block-u içindədir və "Sorğu" başlığı
    altında yerləşir.

    Parameters
    ----------
    prompt_id : str
        Qeydiyyatdakı açar.

    Returns
    -------
    list[str]
        Axtarış sorğularının siyahısı (platform qeydləri olmadan).
    """
    content = get_prompt(prompt_id)

    # "### Sorğu N —" başlıqlarından sonrakı code block-ları tap
    pattern = re.compile(
        r"###\s+Sorğu\s+\d+.*?\n```[^\n]*\n(.*?)```",
        re.DOTALL,
    )
    return [m.group(1).strip() for m in pattern.finditer(content)]


def get_doi_verified_papers(prompt_id: str) -> list[str]:
    """Promtdakı DOI doğrulama protokoluna uyğun doğrulanmış DOI-ləri qaytarır.

    Qeyd: Bu funksiya promt faylında **mövcud olan** DOI-ləri çıxarır.
    Yeni axtarış nəticələri üçün DOI doğrulaması agent tərəfindən
    icra olunmalıdır (bax: AXTARIS_SXEMI.md, Faza 1).

    Parameters
    ----------
    prompt_id : str
        Qeydiyyatdakı açar.

    Returns
    -------
    list[str]
        Faylda tapılmış DOI string-ləri (10.xxxx/... formatında).
    """
    content = get_prompt(prompt_id)
    doi_pattern = re.compile(r"10\.\d{4,9}/[^\s,;\"')\]]+")
    return list(set(doi_pattern.findall(content)))


# ---------------------------------------------------------------------------
# Keyfiyyət Qapısı Yoxlaması (Quality Gate — AXTARIS_SXEMI.md Qapı 1)
# ---------------------------------------------------------------------------


def validate_prompt(prompt_id: str) -> dict[str, bool]:
    """AXTARIS_SXEMI.md Qapı 1 keyfiyyət meyarlarını yoxlayır.

    Meyarlar:
    - [✓] Minimum 5 DOI-doğrulanmış paper var
    - [✓] Hər paper-in arXiv/DOI linki var
    - [✓] "Falsifikasiya" bölməsi mövcuddur
    - [✓] Azərbaycan xülasəsi var
    - [✓] MMS Konstitusiyasına istinad var

    Parameters
    ----------
    prompt_id : str
        Qeydiyyatdakı açar.

    Returns
    -------
    dict[str, bool]
        Hər meyarın adı → keçib/keçmədiyi. Bütün 5 ``True`` olmalıdır.
    """
    content = get_prompt(prompt_id)
    meta = PROMPT_REGISTRY[prompt_id]

    doi_count = len(get_doi_verified_papers(prompt_id))
    has_arxiv_link = "arxiv.org" in content or "arXiv" in content
    has_falsification = "falsifikasiya" in content.lower() or "Falsifikasiya" in content
    has_azerbaijani_summary = "Xülasə" in content or "xülasə" in content
    has_constitution_ref = "Konstitusiya" in content or "konstitusiya" in content

    return {
        "min_5_doi_papers": doi_count >= MIN_DOI_PAPERS_PER_PROMPT,
        "has_arxiv_or_doi_links": has_arxiv_link,
        "has_falsification_section": has_falsification,
        "has_azerbaijani_summary": has_azerbaijani_summary,
        "has_mms_constitution_ref": has_constitution_ref,
    }


def validate_all() -> dict[str, dict[str, bool]]:
    """Bütün promtlar üçün Qapı 1 yoxlamasını icra edir.

    Returns
    -------
    dict[str, dict[str, bool]]
        ``{prompt_id: {criterion: passed}}`` xəritəsi.
    """
    return {pid: validate_prompt(pid) for pid in PROMPT_REGISTRY}


# ---------------------------------------------------------------------------
# Modul Səviyyə Dunder-lər
# ---------------------------------------------------------------------------

__version__: str = "1.0.0"
__author__: str = "MMS Quant Research"
__all__: list[str] = [
    "PROMPT_REGISTRY",
    "MIN_DOI_PAPERS_PER_PROMPT",
    "MAX_AGENT_RETRIES",
    "get_prompt",
    "get_prompt_path",
    "parse_frontmatter",
    "list_prompts",
    "get_search_queries",
    "get_doi_verified_papers",
    "validate_prompt",
    "validate_all",
]
