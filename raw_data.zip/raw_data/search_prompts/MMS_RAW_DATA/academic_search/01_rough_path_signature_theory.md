---
tags: [search-prompt, rough-path, lyons, signature, causal]
category: academic-search
module: causal-raw-data-engine
created: 2026-07-11
trust: 🟢 VERIFIED (prompts are methodology, not claims)
---

# Axtarış Promtu: Rough Path Theory & Path Signatures

## Məqsəd

Terry Lyons' Rough Path Theory-nin computational maliyyə tətbiqləri üçün əsas ədəbiyyatı tap.
Causal Raw Data Engine modulunda tick səviyyəsində exchange məlumatlarını causal matrislərə
çevirmək üçün rough path signature-lərdən istifadə edirik. Bu axtarış həmin riyazi aparatın
nəzəri əsaslarını, computational alqoritmlərini və maliyyə tətbiqlərini əhatə etməlidir.

**MMS Konstitusiyası Tələbləri:**
- Yalnız 3 sübut növü qəbul edilir: Riyazi (tavtologiya), İqtisadi (DOI-doğrulanmış paper), Statistik (öz məlumatlarımızda)
- "Hamı bilir ki" = SÜBUT DEYİL
- Hər bir iddia üçün falsifikasiya şərtləri tələb olunur
- Hot path: division YOX, sqrt YOX, float YOX, heap allocation YOX
- Dəyər = dəqiqlik × sürət × maliyyə təhlükəsizliyi

## Axtarış Sorğuları (arXiv, Semantic Scholar, Google Scholar)

### Sorğu 1 — Əsas Nəzəriyyə
```
"rough path" AND "signature" AND ("Lyons" OR "iterated integrals") AND "financial time series"
```
**Platform:** arXiv (math.PR, q-fin.ST), Semantic Scholar
**Gözlənilən nəticə:** Lyons (1998), Friz & Victoir (2010) əsas işləri

### Sorğu 2 — Signature Kernel
```
"signature kernel" AND ("finance" OR "time series classification") AND "computational complexity"
```
**Platform:** arXiv (stat.ML, cs.LG), Google Scholar
**Gözlənilən nəticə:** Chevyrev, Nandi (2020+) signature kernel paper-ləri

### Sorğu 3 — Streaming/Online Computation
```
"online signature computation" OR "streaming rough path" OR "incremental signature" AND "real-time"
```
**Platform:** arXiv (cs.DS, cs.NA), Google Scholar
**Gözlənilən nəticə:** Streaming signature alqoritmləri, O(d^k) complexity bounds

### Sorğu 4 — Maliyyə Tətbiqləri
```
"rough path" AND ("market microstructure" OR "tick data" OR "high frequency" OR "order flow")
```
**Platform:** arXiv (q-fin.CP, q-fin.ST), SSRN, Google Scholar
**Gözlənilən nəticə:** Maliyyə bazarlarında rough path tətbiqləri

### Sorğu 5 — Rough Path Feature Map
```
"rough path feature map" AND ("universal approximation" OR "feature extraction") AND "time series"
```
**Platform:** arXiv (stat.ML), Semantic Scholar
**Gözlənilən nəticə:** Signature-nin universal feature map kimi istifadəsi

### Sorğu 6 — Iterated Integrals Computational
```
"iterated integrals" AND ("computation" OR "algorithm" OR "numerical") AND ("signature" OR "Chen-Fliess")
```
**Platform:** arXiv (math.NA, cs.NA), Google Scholar
**Gözlənilən nəticə:** Iterated integral-ların computational üsulları

### Sorğu 7 — Log-Signature & Dimensionality
```
"log-signature" AND ("dimension reduction" OR "basis" OR "Hall basis" OR "Lyndon words") AND "computation"
```
**Platform:** arXiv (math.CO, cs.SC), Google Scholar
**Gözlənilən nəticə:** Log-signature üçün effektiv hesablama üsulları

### Sorğu 8 — Signature & Causality
```
"path signature" AND ("causal" OR "Granger" OR "information flow") AND ("time series" OR "stochastic")
```
**Platform:** arXiv (math.PR, stat.ME), Google Scholar
**Gözlənilən nəticə:** Signature-lərin causal analizlə əlaqəsi

### Sorğu 9 — Truncated Signature & Depth Selection
```
"truncated signature" AND "depth" AND ("optimal" OR "selection" OR "convergence rate") AND "financial"
```
**Platform:** Semantic Scholar, arXiv (q-fin.ST)
**Gözlənilən nəticə:** Optimal truncation depth seçim meyarları

### Sorğu 10 — Signature on Irregular Paths
```
"rough path" AND ("irregular sampling" OR "unevenly spaced" OR "tick time") AND "signature"
```
**Platform:** arXiv (math.PR, q-fin.CP), Google Scholar
**Gözlənilən nəticə:** Qeyri-bərabər zamanlı məlumatlarda signature hesablanması

## Əsas Müəlliflər

| Müəllif | Sahə | Əsas İş |
|---------|------|---------|
| Terry Lyons | Rough Path Theory banisi | "Differential equations driven by rough paths" (1998, 2002) |
| Peter Friz | Rough paths & financial math | "Multidimensional Stochastic Processes as Rough Paths" (2010) |
| Martin Hairer | Regularity structures | "A Theory of Regularity Structures" (2014, Fields Medal) |
| Xi Geng | Rough paths computation | Computational rough path algorithms |
| Ilya Chevyrev | Signature kernels | "Signature moments to characterize laws" (2020+) |
| Christian Bayer | Rough paths in finance | "Pricing American options by rough paths" |
| Peter Laurence | Signature in markets | Market signature applications |
| Thomas Cass | Rough paths & ML | Machine learning with signatures |
| Will Perrault | Signature methods | Computational signature methods |
| Antoine Jacquier | Rough volatility & signatures | Rough Bergomi, signature-based models |

## Filtr Kriteriyaları

- **Tarix:** 1998–2026 (Lyons-un ilk işindən indiyə qədər)
- **Kateqoriyalar:** math.PR, q-fin.CP, q-fin.ST, cs.NA, stat.ML, math.NA, cs.LG
- **Növ:** Peer-reviewed jurnal məqalələri VƏ YA arXiv preprint (yüksək citation sayı ilə)
- **Dil:** İngiliscə
- **Minimum sitat:** 5+ (Google Scholar) — istisna: son 2 ilin işləri üçün minimum yoxdur
- **Etibarlılıq:** Hər paper üçün DOI və ya arXiv ID tələb olunur

## Gözlənilən Nəticələr

Hər bir tapılmış paper-dən aşağıdakılardan ən azı biri gözlənilir:

1. **Teoremlər:** Signature-nin universallığı, convergence rate-lər, error bound-lar
2. **Alqoritmlər:** Online/streaming signature hesablanması, truncated signature alqoritmləri
3. **Complexity bound-lar:** O(d^k) zamanı və yaddaş mürəkkəbliyi, burada d = ölçü, k = depth
4. **Falsifikasiya şərtləri:** Hər nəticənin hansı şəraitdə keçərsiz olduğu
5. **Numerik sabitlik:** Fixed-point aritmetikada tətbiq imkanları (MMS hot-path qaydaları)

### Xüsusi Gözləntilər:
- Signature-nin hot-path-da hesablanması mümkündürmü? (Q32.32 fixed-point ilə)
- Truncation depth-in seçimi üçün formal meyarlar hansılardır?
- Signature kernel-in streaming variantı mövcuddurmu?
- Qeyri-bərabər zamanlı (tick) məlumatlar üçün signature necə hesablanır?

## Uyğunluq Testi

Bu ədəbiyyat Causal Raw Data Engine-ə necə xidmət edir:

| Kriteriya | İzah |
|-----------|------|
| **Causal matris çıxarışı** | Path signature-lər exchange data-nın invariant xüsusiyyətlərini çıxarır |
| **Hot-path uyğunluğu** | Signature hesablanması branchless və fixed-point ilə implementasiya edilə bilərmi? |
| **Streaming uyğunluğu** | Online signature alqoritmləri real-time tick emalına uyğundurmu? |
| **Causal validity** | Signature-lər因果 (causal) informasiyanı saxlayırmı, yoxsa yalnız path-dependent statistikadır? |
| **MMS Konstitusiyası** | Hər paper DOI ilə doğrulanmalıdır; "hamı bilir ki" sübut sayılmır |

**Falsifikasiya Testi:** Əgər signature-lər tick data-nın causal strukturunu özündə saxlamırsa,
bu yanaşma keçərsizdir və alternativ (məs., transfer entropy) axtarılmalıdır.

## DOI Doğrulama Protokolü

Hər bir tapılmış paper üçün aşağıdakı addımlar MƏCBURİDİR:

### Addım 1: DOI Tapılması
```
1. Paper-in metadata-sında DOI sahəsini yoxla
2. DOI yoxdursa: CrossRef API (https://api.crossref.org/works?query=TITLE) ilə axtar
3. arXiv paper-ləri üçün: arXiv ID-ni qeyd et, DOI varsa əlavə et
```

### Addım 2: DOI Doğrulaması
```
1. https://doi.org/DOI_HERE ünvanına GET sorğusu göndər
2. HTTP 200 və ya 302 (redirect to publisher) gözlənilir
3. Redirect target-ın publisher domenini yoxla:
   - ✅ springer.com, elsevier.com, cambridge.org, wiley.com, siam.org
   - ✅ arxiv.org (preprint)
   - ✅ doi.org → publisher redirect
   - ❌ doi.org → error/404 = KEÇƏRSİZ
```

### Addım 3: Metadata Uyğunluğu
```
1. CrossRef-dən qayıdan metadata ilə axtarış nəticəsini müqayisə et:
   - Başlıq (title)
   - Müəlliflər (authors)
   - İl (year)
   - Jurnal/Konfrans (container-title)
2. Uyğunsuzluq varsa → paper-i QƏBUL ETMƏ
```

### Addım 4: Etibarlılıq Skoru
```
Hər paper-ə aşağıdakı skoru ver:
- DOI doğrulandı: +2
- Peer-reviewed jurnal: +2
- arXiv preprint (10+ citation): +1
- Müəllif tanınmış (əsas müəlliflər siyahısında): +1
- Son 5 il: +1
- Minimum qəbul skoru: 3
```

## Azerbaijani Xülasə

Bu axtarış promtu Rough Path Theory (Terry Lyons) və path signature-lərin computational
maliyyədə tətbiqi üçün ədəbiyyat tapmağa yönəlib. Əsas məqsəd: tick səviyyəsində exchange
məlumatlarından causal matrislər çıxarmaq üçün riyazi aparat tapmaq.

**Əsas suallar:**
1. Signature-lər real-time (streaming) hesablana bilərmi?
2. Q32.32 fixed-point aritmetikada signature hesablamaq mümkündürmü?
3. Signature-lər causal informasiyanı saxlayırmı?
4. Optimal truncation depth necə seçilir?

**MMS Konstitusiyası uyğunluğu:** Hər paper DOI ilə doğrulanmalıdır. İddialar falsifikasiya
edilə bilən olmalıdır. Hot-path məhdudiyyətləri (float YOX, division YOX, heap allocation YOX)
nəzərə alınmalıdır.

---

**İstifadə qaydası:** Bu promtu AI research agent-ə verin. Agent hər sorğunu göstərilən
platformalarda icra etməli, tapılmış paper-ləri DOI Doğrulama Protokolundan keçirməli və
nəticələri Uyğunluq Testinə əsasən qiymətləndirməlidir.

🟢 **VERIFIED** — Bu promtlar metodologiyadır, iddia deyil. Axtarış sorğuları özlüyündə
heç bir faktiki iddia irəli sürmür; yalnız mövcud ədəbiyyatı tapmaq üçün vasitədir.
