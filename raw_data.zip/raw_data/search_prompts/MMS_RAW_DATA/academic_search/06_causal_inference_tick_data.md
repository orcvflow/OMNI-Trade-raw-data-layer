---
tags: [search-prompt, causal-inference, granger, transfer-entropy, tick-data, microstructure]
category: academic-search
module: causal-raw-data-engine
created: 2026-07-11
trust: 🟢 VERIFIED (prompts are methodology, not claims)
---

# Axtarış Promtu: Causal Inference in High-Frequency Financial Data

## Məqsəd

Yüksək tezlikli maliyyə məlumatlarında (tick data) causal inference üçün əsas ədəbiyyatı tap.
Causal Raw Data Engine modulunun əsas məqsədi məhz budur: exchange-dən gələn raw tick
məlumatlarından causal matrislər çıxarmaq. Bu axtarış Granger causality, transfer entropy,
causal discovery alqoritmləri (PC, FCI, GES) və information-theoretic causality ölçülərini
əhatə etməlidir.

**MMS Konstitusiyası Tələbləri:**
- Yalnız 3 sübut növü qəbul edilir: Riyazi (tavtologiya), İqtisadi (DOI-doğrulanmış paper), Statistik (öz məlumatlarımızda)
- "Hamı bilir ki" = SÜBUT DEYİL — "A B-yə səbəb olur" SÜBUT DEYİL, formal causal test lazımdır
- Hər bir iddia üçün falsifikasiya şərtləri tələb olunur
- Hot path: division YOX, sqrt YOX, float YOX, heap allocation YOX
- Dəyər = dəqiqlik × sürət × maliyyə təhlükəsizliyi

## Axtarış Sorğuları (arXiv, Semantic Scholar, Google Scholar, SSRN, NBER)

### Sorğu 1 — Granger Causality Tick Level
```
"Granger causality" AND ("tick" OR "high frequency" OR "ultra-high frequency" OR "intraday") AND ("financial" OR "stock" OR "market")
```
**Platform:** arXiv (stat.ME, q-fin.ST), SSRN, Google Scholar
**Gözlənilən nəticə:** Tick səviyyəsində Granger causality tətbiqləri

### Sorğu 2 — Transfer Entropy Market Microstructure
```
"transfer entropy" AND ("market microstructure" OR "order flow" OR "order book" OR "tick data") AND ("causality" OR "information flow")
```
**Platform:** arXiv (q-fin.ST, physics.soc-ph), Google Scholar
**Gözlənilən nəticə:** Transfer entropy ilə market microstructure-da causal analiz

### Sorğu 3 — Causal Discovery High-Frequency Finance
```
"causal discovery" AND ("high frequency" OR "tick" OR "microstructure") AND ("PC algorithm" OR "FCI" OR "GES" OR "constraint-based") AND "financial"
```
**Platform:** arXiv (stat.ML, q-fin.ST), Google Scholar, Semantic Scholar
**Gözlənilən nəticə:** Causal discovery alqoritmlərinin maliyyə data-sında tətbiqi

### Sorğu 4 — Variable-Lag Granger Causality
```
"variable-lag Granger causality" OR "time-varying lag" AND "Granger" AND ("financial" OR "economic" OR "market") AND "causality"
```
**Platform:** arXiv (stat.ME, econ.EM), Google Scholar, NBER
**Gözlənilən nəticə:** Dəyişən lag-lı Granger causality metodları

### Sorğu 5 — Volume Clock Causal Inference
```
"volume clock" OR "tick clock" OR "business time" AND ("causal" OR "Granger" OR "sampling") AND ("financial" OR "market" OR "high frequency")
```
**Platform:** arXiv (q-fin.ST), SSRN, Google Scholar
**Gözlənilən nəticə:** Volume clock vs time clock-un causal analizə təsiri

### Sorğu 6 — Tick Data Causal Validity
```
"tick data" AND ("causal validity" OR "causal inference" OR "identification") AND ("cleaning" OR "filtering" OR "microstructure noise")
```
**Platform:** arXiv (q-fin.ST, stat.ME), SSRN, Google Scholar
**Gözlənilən nəticə:** Tick data təmizlənməsinin causal validliyə təsiri

### Sorğu 7 — Information-Theoretic Causality Finance
```
"information theoretic" AND ("causality" OR "causal") AND ("mutual information" OR "transfer entropy" OR "conditional entropy") AND ("financial" OR "market")
```
**Platform:** arXiv (q-fin.ST, cs.IT, physics.soc-ph), Google Scholar
**Gözlənilən nəticə:** Informasiya nəzəriyyəsi əsaslı causal ölçülər

### Sorğu 8 — PC Algorithm Financial Time Series
```
"PC algorithm" OR "Peter-Clark algorithm" AND ("financial" OR "stock" OR "market" OR "time series") AND ("causal graph" OR "DAG" OR "directed acyclic graph")
```
**Platform:** arXiv (stat.ML, q-fin.ST), Google Scholar, Semantic Scholar
**Gözlənilən nəticə:** PC alqoritminin maliyyə zaman sıralarında tətbiqi

### Sorğu 9 — Causal Inference Irregular Time Series
```
"causal inference" AND ("irregular" OR "unevenly spaced" OR "asynchronous" OR "non-uniform") AND "time series" AND ("financial" OR "tick")
```
**Platform:** arXiv (stat.ME, q-fin.ST), Google Scholar
**Gözlənilən nəticə:** Qeyri-bərabər zamanlı data-da causal inference metodları

### Sorğu 10 — Instantaneous Causality Market
```
"instantaneous causality" OR "contemporaneous causality" OR "zero-lag causality" AND ("market" OR "financial" OR "trading") AND ("algorithm" OR "method")
```
**Platform:** arXiv (q-fin.ST, stat.ME), Google Scholar
**Gözlənilən nəticə:** Eyni anda baş verən causal əlaqələrin aşkarlanması

## Əsas Müəlliflər

| Müəllif | Sahə | Əsas İş |
|---------|------|---------|
| Clive Granger | Granger causality | "Investigating Causal Relations by Econometric Models" (1969, Nobel Prize) |
| Thomas Schreiber | Transfer entropy | "Measuring Information Transfer" (2000) — transfer entropy ixtiraçısı |
| Peter Spirtes | Causal discovery | "Causation, Prediction, and Search" (2000) — PC alqoritmi |
| Clark Glymour | Causal discovery | PC alqoritmi həmmüəllifi, causal search theory |
| Judea Pearl | Causal inference | "Causality" (2009) — do-calculus, SCM framework |
| Peter Bühlmann | Causal inference time series | Causal inference in high-dimensional time series |
| Diego Klabjan | Financial causality | Causal discovery in financial data |
| Alessio Sancetta | Causal finance | Causal inference in econometrics |
| Jon Cunningham | Gaussian processes | GP-based causal discovery |
| Shohei Shimizu | LiNGAM | "A Linear Non-Gaussian Acyclic Model for Causal Discovery" |

## Filtr Kriteriyaları

- **Tarix:** 1969–2026 (Granger-in ilk işindən indiyə qədər)
- **Kateqoriyalar:** stat.ME, stat.ML, q-fin.ST, q-fin.EM, econ.EM, cs.IT, cs.LG, physics.soc-ph
- **Növ:** Peer-reviewed jurnal məqalələri, Nobel Prize işləri, VƏ YA yüksək citation-lı arXiv preprint-lər
- **Dil:** İngiliscə
- **Minimum sitat:** 20+ (Google Scholar) — istisna: son 3 ilin causal discovery işləri üçün 5+
- **Etibarlılıq:** DOI və ya arXiv ID tələb olunur

## Gözlənilən Nəticələr

Hər bir tapılmış paper-dən aşağıdakılardan ən azı biri gözlənilir:

1. **Causal test metodları:** Granger, transfer entropy, PC — hansı tick data üçün uyğundur?
2. **Lag selection:** Optimal lag uzunluğu necə seçilir? (BIC, AIC, cross-validation)
3. **Sampling frequency:** Causal inference üçün optimal sampling tezliyi nədir?
4. **Volume clock advantage:** Volume clock causal discovery-də time clock-dan daha yaxşıdır?
5. **Microstructure noise:** Bid-ask bounce, discrete pricing causal validliyi necə pozur?
6. **Falsifikasiya şərtləri:** Hər causal test-in hansı hallarda yanlış nəticə verdiyi

### Xüsusi Gözləntilər:
- Tick data-da Granger causality-nin statistical power-ı nə qədərdir? (false positive rate)
- Transfer entropy computation-ın complexity-si O(n²) və ya O(n log n)?
- PC alqoritmi yüksək ölçülü (100+ asset) market data-da işləyirmi?
- Volume clock ilə time clock arasında causal discovery nəticələri nə qədər fərqlənir?
- Instantaneous (zero-lag) causality market data-da necə aşkarlanır?

## Uyğunluq Testi

Bu ədəbiyyat Causal Raw Data Engine-ə necə xidmət edir:

| Kriteriya | İzah |
|-----------|------|
| **Causal matris çıxarışı** | Bu, modulun ƏSAS məhsuludur — hər paper birbaşa relevance daşıyır |
| **Hot-path uyğunluğu** | Causal test alqoritmləri Q32.32 fixed-point-da implementasiya edilə bilərmi? |
| **Streaming uyğunluğu** | Causal inference real-time (online) hesablana bilərmi, yoxsa batch-only-dur? |
| **Maliyyə təhlükəsizliyi** | Yanlış causal nəticə → yanlış trade → maliyyə itkisi; false positive rate kritikdir |
| **MMS Konstitusiyası** | "A B-yə səbəb olur" İDDİADIR — formal causal test + falsifikasiya şərti lazımdır |

**Falsifikasiya Testi:** Əgər causal inference alqoritmi synthetic data-da düzgün nəticə
vermirsə (ground truth məlum olduğu halda), real market data-da etibarlı DEYİL. Hər paper
üçün synthetic data benchmark-ı yoxlanmalıdır.

## DOI Doğrulama Protokolü

Hər bir tapılmış paper üçün aşağıdakı addımlar MƏCBURİDİR:

### Addım 1: DOI Tapılması
```
1. Paper-in metadata-sında DOI sahəsini yoxla
2. DOI yoxdursa: CrossRef API (https://api.crossref.org/works?query=TITLE) ilə axtar
3. arXiv paper-ləri üçün: arXiv ID-ni qeyd et, DOI varsa əlavə et
4. SSRN paper-ləri üçün: SSRN Abstract ID + DOI (varsa)
5. NBER paper-ləri: NBER Working Paper number + DOI
```

### Addım 2: DOI Doğrulaması
```
1. https://doi.org/DOI_HERE ünvanına GET sorğusu göndər
2. HTTP 200 və ya 302 (redirect to publisher) gözlənilir
3. Redirect target-ın publisher domenini yoxla:
   - ✅ springer.com, elsevier.com, wiley.com, cambridge.org
   - ✅ jstor.org, projecteuclid.org (statistika jurnalları)
   - ✅ arxiv.org (preprint)
   - ✅ nber.org (NBER working papers)
   - ✅ ssrn.com (SSRN papers)
   - ❌ doi.org → error/404 = KEÇƏRSİZ
```

### Addım 3: Metadata Uyğunluğu
```
1. CrossRef-dən qayıdan metadata ilə axtarış nəticəsini müqayisə et:
   - Başlıq (title)
   - Müəlliflər (authors)
   - İl (year)
   - Jurnal/Konfrans
2. Uyğunsuzluq varsa → paper-i QƏBUL ETMƏ
```

### Addım 4: Etibarlılıq Skoru
```
Hər paper-ə aşağıdakı skoru ver:
- DOI doğrulandı: +2
- Peer-reviewed jurnal (Econometrica, JASA, Annals of Statistics): +3
- Nobel Prize əlaqəli: +2
- arXiv preprint (30+ citation): +1
- Müəllif tanınmış (əsas müəlliflər siyahısında): +1
- Synthetic data benchmark ilə: +1
- Minimum qəbul skoru: 3
```

## Azerbaijani Xülasə

Bu axtarış promtu yüksək tezlikli maliyyə məlumatlarında (tick data) causal inference üçün
ədəbiyyat tapmağa yönəlib. Bu, Causal Raw Data Engine modulunun ƏSAS promtudur — çünki
modulun məhsulu məhz causal matrislərdir.

**Əsas suallar:**
1. Granger causality, transfer entropy, PC alqoritmi — hansı tick data üçün ən uyğundur?
2. Causal inference real-time (online) hesablana bilərmi? (hot-path uyğunluğu)
3. Volume clock causal discovery-də time clock-dan daha yaxşı nəticə verirmi?
4. Microstructure noise (bid-ask bounce) causal validliyi necə pozur?
5. Yanlış causal nəticənin false positive rate-i nə qədərdir? (maliyyə təhlükəsizliyi)

**MMS Konstitusiyası uyğunluğu:** "A B-yə səbəb olur" iddiası ən güclü iddiadır və ən
güclü sübut tələb edir. Korrelyasiya səbəbiyyət DEYİL. Granger causality korrelyasiyadan
güclüdür, amma həqiqi səbəbiyyət DEYİL (yalnız proqnozlaşdırma səbəbiyyətidir). Hər causal
iddia üçün falsifikasiya şərti göstərilməlidir: "Əgər [şərt], onda bu causal əlaqə KEÇƏRSİZDİR."

**Kritik qeyd:** Granger causality = proqnozlaşdırma səbəbiyyəti, həqiqi səbəbiyyət DEYİL.
Transfer entropy = informasiya axını, həqiqi səbəbiyyət DEYİL. PC alqoritmi = həqiqi causal
struktur, amma faithfulness assumption tələb edir. Bu fərqləri başa düşmək KRİTİKDİR.

---

**İstifadə qaydası:** Bu promtu AI research agent-ə verin. Agent hər sorğunu göstərilən
platformalarda icra etməli, tapılmış paper-ləri DOI Doğrulama Protokolundan keçirməli və
nəticələri Uyğunluq Testinə əsasən qiymətləndirməlidir. Xüsusilə Granger-in Nobel Prize
işinə, Schreiber-in transfer entropy işinə və Spirtes/Glymour-un PC alqoritminə diqqət
yetirin. Hər causal metod üçün synthetic data benchmark-ı olan paper-lərə üstünlük verin.

🟢 **VERIFIED** — Bu promtlar metodologiyadır, iddia deyil. Axtarış sorğuları özlüyündə
heç bir faktiki iddia irəli sürmür; yalnız mövcud ədəbiyyatı tapmaq üçün vasitədir.
