---
tags: [engineering-spec, hamiltonian, energy, phase-space]
category: engineering-specification
module: causal-raw-data-engine
priority: HIGH
created: 2026-07-11
trust: 🟡 PARTIALLY VERIFIED (physics-market analogy is hypothesis)
mms_constitution_refs: [§1.3, §2.4, §3.1, §4.1]
---

# Mühəndislik Spesifikasiyası 04: Hamiltonian Enerji Matrisi

## 1. Məqsəd (Purpose)

Implement the **Hamiltonian energy framework** for market data.
Price is the generalized coordinate Q, Volume is the conjugate momentum P.
The Hamiltonian H = T(P) + V(Q) captures total market "energy" at each tick.

This enables:
- Phase-space portraits (Q, P) for regime detection
- Energy conservation tests (ΔH ≈ 0 in efficient markets)
- Anomaly detection via energy spikes
- Input to downstream rough path signature computation

**What it does NOT do:** predict price direction or generate trading signals.

Ref: MMS Constitution §4.1 — "Physical analogies are measurement tools, not predictions."

---

## 2. Hamiltonian Framework for Market Data

### 2.1 Classical Mechanics Foundation

In Hamiltonian mechanics:
- **Q** = generalized coordinate (position)
- **P** = conjugate momentum
- **H(Q, P)** = Hamiltonian = total energy = T(P) + V(Q)
- **Hamilton's equations:**
  - dQ/dt = ∂H/∂P (velocity = momentum/mass)
  - dP/dt = -∂H/∂Q (force = negative gradient of potential)

### 2.2 Market Data Mapping

| Physics Concept    | Market Data Analog       | Rationale                                    |
|-------------------|--------------------------|---------------------------------------------|
| Q (position)      | Price                    | Price is the observable "state" of market   |
| P (momentum)      | Volume                   | Volume is the "force" behind price movement |
| T (kinetic E)     | P² / 2m → (P*P) >> 32   | Volume energy: effort behind the move       |
| V (potential E)   | |ΔQ|                    | Price displacement: how far market moved    |
| H (total energy)  | T + V                    | Combined market activity metric             |
| dQ/dt             | ΔQ/Δt (price velocity)  | Rate of price change                        |
| dP/dt             | ΔP/Δt (volume accel)    | Rate of volume change                       |

### 2.3 Mathematical Derivation

```
Given discrete tick data: (Q_i, P_i, t_i) for i = 0, 1, ..., N

Define:
  ΔQ_i = Q_i - Q_{i-1}     (price displacement)
  ΔP_i = P_i - P_{i-1}     (volume change)
  Δt_i = t_i - t_{i-1}     (time delta in nanoseconds)

Kinetic Energy (volume-driven):
  T_i = (P_i * P_i) >> 32
  (In Q32.32: P is uint64, P*P needs uint128 intermediate,
   we approximate via high-bits method)

Potential Energy (price displacement):
  V_i = |ΔQ_i|
  (Absolute price change in Q32.32)

Hamiltonian:
  H_i = T_i + V_i

Discrete Hamilton's Equations:
  dQ/dt ≈ ΔQ_i / Δt_i   (but we AVOID division — see §5)
  dP/dt ≈ ΔP_i / Δt_i

Phase Space:
  Point: (Q_i, P_i)
  Trajectory: sequence of points reveals market regime
```

### 2.4 Phase Space Regime Classification

```
                    Low Volume (P)        High Volume (P)
                 ┌────────────────────┬────────────────────┐
  Low |ΔQ|      │   CALM MARKET      │   ACCUMULATION/    │
  (small price  │   Tight range,      │   DISTRIBUTION     │
  change)       │   low activity      │   High volume,     │
                 │                     │   tight range      │
                 ├────────────────────┼────────────────────┤
  High |ΔQ|     │   TRENDING         │   CHAOS/           │
  (large price  │   Low volume,       │   VOLATILITY       │
  change)       │   big moves         │   High volume,     │
                 │   (suspicious!)     │   big moves        │
                 └────────────────────┴────────────────────┘

  Quadrant energies:
    CALM:          T ≈ 0, V ≈ 0 → H ≈ 0
    ACCUMULATION:  T >> 0, V ≈ 0 → H ≈ T (kinetic dominates)
    TRENDING:      T ≈ 0, V >> 0 → H ≈ V (potential dominates)
    CHAOS:         T >> 0, V >> 0 → H = T + V (both high)
```

---

## 3. Q32.32 Implementation — Complete Code

```python
import numpy as np
from numpy.typing import NDArray

# ─────────────────────────────────────────────
# Constants
# ─────────────────────────────────────────────
Q32_SHIFT = np.uint64(32)
Q32_ONE = np.uint64(1) << Q32_SHIFT
UINT64_SIGN_BIT = np.uint64(0x8000000000000000)
UINT64_MAX = np.uint64(0xFFFFFFFFFFFFFFFF)

# Energy anomaly threshold: if ΔH > this, flag as anomaly
# Set to represent a 10x change in typical energy
# Tuned per asset — default is for BTC-USD
ANOMALY_THRESHOLD_Q32 = np.uint64(1_000_000) << Q32_SHIFT


class HamiltonianEnergyComputer:
    """
    Computes Hamiltonian energy for market tick data in Q32.32.
    
    All operations are branchless and use only uint64 arithmetic.
    Pre-allocates scratch buffers for zero-allocation hot path.
    """

    __slots__ = [
        '_max_batch',
        '_scratch_KE',       # Kinetic energy buffer
        '_scratch_PE',       # Potential energy buffer
        '_scratch_H',        # Total Hamiltonian buffer
        '_scratch_dQ',       # Price delta buffer
        '_scratch_abs_dQ',   # Absolute price delta buffer
    ]

    def __init__(self, max_batch_size: int = 8192) -> None:
        """Pre-allocate all scratch buffers."""
        self._max_batch = max_batch_size
        self._scratch_KE = np.zeros(max_batch_size, dtype=np.uint64)
        self._scratch_PE = np.zeros(max_batch_size, dtype=np.uint64)
        self._scratch_H = np.zeros(max_batch_size, dtype=np.uint64)
        self._scratch_dQ = np.zeros(max_batch_size, dtype=np.uint64)
        self._scratch_abs_dQ = np.zeros(max_batch_size, dtype=np.uint64)

    def compute_kinetic_energy(
        self,
        volumes_q32: NDArray[np.uint64],
    ) -> NDArray[np.uint64]:
        """
        Compute kinetic energy T = (P * P) >> 32 in Q32.32.
        
        Since numpy has no uint128, we use the HIGH-BITS APPROXIMATION:
          P_hi = P >> 16   (upper 48 bits of P)
          T ≈ P_hi * P_hi
          
        This computes the upper 32 bits of the full 128-bit product,
        which is exactly what >> 32 would give us.
        
        Error analysis:
          Full: (P * P) >> 32
          Approx: (P >> 16) * (P >> 16)
          Error: at most 2 * (P >> 16) * (P & 0xFFFF) >> 32 + (P & 0xFFFF)^2 >> 32
          For P in typical range (P < 2^48): error < 2^-16 relative
        
        Hot path: YES — single shift + multiply, fully branchless.
        """
        # Shift volume right by 16 to get upper 48 bits
        # This reduces the 64-bit value to something whose square fits in 64 bits
        P_hi = volumes_q32 >> np.uint64(16)

        # Square: P_hi^2
        # For P_hi < 2^32 (which means volume < 2^48 in Q32.32 ≈ 65K integer),
        # the square fits in uint64
        KE = P_hi * P_hi

        return KE

    def compute_kinetic_energy_2stage(
        self,
        volumes_q32: NDArray[np.uint64],
    ) -> NDArray[np.uint64]:
        """
        More accurate kinetic energy using 2-stage multiplication.
        
        Split P into 32-bit halves:
          P = P_hi * 2^32 + P_lo  (where P_hi = P >> 32, P_lo = P & 0xFFFFFFFF)
        
        P^2 = P_hi^2 * 2^64 + 2 * P_hi * P_lo * 2^32 + P_lo^2
        
        (P^2) >> 32 = P_hi^2 * 2^32 + 2 * P_hi * P_lo + (P_lo^2 >> 32)
        
        Since P_hi^2 * 2^32 overflows uint64 for P_hi > 2^16,
        we only keep the middle terms:
          result ≈ 2 * P_hi * P_lo + (P_lo^2 >> 32)
        
        This is more accurate than the simple high-bits method.
        
        Hot path: YES — 2 multiplies + additions, all branchless.
        """
        P_hi = volumes_q32 >> Q32_SHIFT        # Upper 32 bits
        P_lo = volumes_q32 & np.uint64(0xFFFFFFFF)  # Lower 32 bits

        # Cross term: 2 * P_hi * P_lo
        # P_hi is at most 32 bits (for volumes < 2^64 in Q32.32)
        # P_lo is at most 32 bits
        # Product is at most 64 bits — fits in uint64
        # Multiplying by 2 may overflow, but we accept modular arithmetic
        cross = np.uint64(2) * P_hi * P_lo

        # P_lo^2 >> 32
        # P_lo is 32 bits, P_lo^2 is 64 bits, >> 32 gives upper 32 bits
        lo_sq = (P_lo * P_lo) >> Q32_SHIFT

        KE = cross + lo_sq
        return KE

    def compute_potential_energy(
        self,
        prices_q32: NDArray[np.uint64],
        prev_prices_q32: NDArray[np.uint64],
    ) -> NDArray[np.uint64]:
        """
        Compute potential energy V = |ΔQ| in Q32.32.
        
        ΔQ = current_price - prev_price (unsigned subtraction)
        |ΔQ| = branchless absolute value
        
        Branchless abs via two's complement trick:
          sign = x >> 63           (0 if positive, 1 if "negative" i.e. wrapped)
          mask = sign * 0xFFFF...  (0x0000... or 0xFFFF...)
          abs_val = (x ^ mask) + sign
        
        WHY this works:
          If x is a normal positive value: sign=0, mask=0, abs=x^0+0 = x
          If x wrapped around (a < b in unsigned a-b):
            sign=1, mask=0xFFFF..., abs=(x^0xFFFF...)+1 = two's complement negation
        
        Hot path: YES.
        """
        # Price delta (unsigned — wraps if current < prev)
        dQ = prices_q32 - prev_prices_q32

        # Branchless absolute value
        sign = dQ >> np.uint64(63)
        mask = sign * UINT64_MAX
        abs_dQ = (dQ ^ mask) + sign

        return abs_dQ

    def compute_hamiltonian(
        self,
        prices_q32: NDArray[np.uint64],
        volumes_q32: NDArray[np.uint64],
        prev_prices_q32: NDArray[np.uint64],
    ) -> tuple[NDArray[np.uint64], NDArray[np.uint64], NDArray[np.uint64]]:
        """
        Compute full Hamiltonian H = T + V for a batch of ticks.
        
        Args:
            prices_q32: current prices in Q32.32
            volumes_q32: current volumes in Q32.32
            prev_prices_q32: previous prices in Q32.32 (for ΔQ)
        
        Returns:
            KE: kinetic energy array (Q32.32 scaled)
            PE: potential energy array (Q32.32)
            H: total Hamiltonian array (KE + PE, may overflow)
        
        All branchless, all zero-allocation (uses scratch buffers internally).
        
        Hot path: YES.
        """
        KE = self.compute_kinetic_energy(volumes_q32)
        PE = self.compute_potential_energy(prices_q32, prev_prices_q32)

        # H = T + V
        # May overflow for very high energy ticks — acceptable (modular)
        H = KE + PE

        return KE, PE, H

    def detect_anomalies(
        self,
        H_current: NDArray[np.uint64],
        H_prev: NDArray[np.uint64],
        threshold: NDArray[np.uint64] = None,
    ) -> NDArray[np.uint8]:
        """
        Detect energy anomalies: |ΔH| > threshold.
        
        In efficient markets, energy should be approximately conserved
        across time scales (ΔH ≈ 0). Large ΔH indicates:
          - Regime change (calm → volatile or vice versa)
          - Data anomaly (corrupted tick)
          - Flash event (liquidation cascade, news shock)
        
        Branchless implementation:
          delta_H = H_current - H_prev (unsigned)
          abs_delta = branchless_abs(delta_H)
          anomaly = (abs_delta > threshold).astype(uint8)
        
        Args:
            H_current: current Hamiltonian values
            H_prev: previous Hamiltonian values
            threshold: anomaly threshold (default: ANOMALY_THRESHOLD_Q32)
        
        Returns:
            anomaly_flags: uint8 array (1 = anomaly, 0 = normal)
        
        Hot path: YES.
        """
        if threshold is None:
            threshold = np.full_like(H_current, ANOMALY_THRESHOLD_Q32)

        # Delta (unsigned subtraction — wraps if H_current < H_prev)
        delta_H = H_current - H_prev

        # Branchless absolute value
        sign = delta_H >> np.uint64(63)
        mask = sign * UINT64_MAX
        abs_delta = (delta_H ^ mask) + sign

        # Compare against threshold (branchless SIMD comparison)
        anomaly_flags = (abs_delta > threshold).astype(np.uint8)

        return anomaly_flags

    def compute_phase_quadrant(
        self,
        KE: NDArray[np.uint64],
        PE: NDArray[np.uint64],
        ke_threshold: np.uint64 = None,
        pe_threshold: np.uint64 = None,
    ) -> NDArray[np.uint8]:
        """
        Classify each tick into a phase-space quadrant.
        
        Quadrants (encoded as 2-bit values):
          0b00 (0) = CALM:          low KE, low PE
          0b01 (1) = ACCUMULATION:  high KE, low PE
          0b10 (2) = TRENDING:      low KE, high PE
          0b11 (3) = CHAOS:         high KE, high PE
        
        Branchless:
          ke_high = (KE > ke_threshold).astype(uint8)
          pe_high = (PE > pe_threshold).astype(uint8)
          quadrant = (pe_high << 1) | ke_high
        
        Args:
            KE: kinetic energy values
            PE: potential energy values
            ke_threshold: threshold for "high" kinetic energy
            pe_threshold: threshold for "high" potential energy
        
        Returns:
            quadrants: uint8 array (0-3)
        
        Hot path: YES.
        """
        if ke_threshold is None:
            # Default: median-scale threshold
            ke_threshold = np.uint64(1000) << Q32_SHIFT
        if pe_threshold is None:
            pe_threshold = np.uint64(100) << Q32_SHIFT

        ke_high = (KE > ke_threshold).astype(np.uint8)
        pe_high = (PE > pe_threshold).astype(np.uint8)

        # Combine into 2-bit quadrant code
        quadrant = (pe_high << np.uint8(1)) | ke_high

        return quadrant


# ═══════════════════════════════════════════════════════
# Energy Conservation Test (Standalone Function)
# ═══════════════════════════════════════════════════════

def energy_conservation_test(
    H_series: NDArray[np.uint64],
    window_size: int = 100,
) -> tuple[NDArray[np.uint64], NDArray[np.uint8]]:
    """
    Test energy conservation over rolling windows.
    
    In Hamiltonian mechanics, H is conserved (dH/dt = 0).
    For market data, we test: ΔH over window ≈ 0.
    
    Implementation (branchless where possible):
      For each window of size W:
        delta_H = H[i] - H[i - W]
        abs_delta = branchless_abs(delta_H)
    
    Args:
        H_series: Hamiltonian values over time
        window_size: number of ticks per window
    
    Returns:
        delta_H_abs: absolute energy change per window
        conservation_flags: 1 if |ΔH| < threshold, 0 otherwise
    
    Cold path — used for regime analysis, not per-tick.
    """
    n = H_series.shape[0]
    if n <= window_size:
        return np.zeros(1, dtype=np.uint64), np.ones(1, dtype=np.uint8)

    # Compute deltas: H[i] - H[i - window_size]
    H_current = H_series[window_size:]
    H_prev = H_series[:n - window_size]
    delta_H = H_current - H_prev

    # Branchless absolute value
    sign = delta_H >> np.uint64(63)
    mask = sign * UINT64_MAX
    abs_delta = (delta_H ^ mask) + sign

    # Conservation flag: |ΔH| < threshold
    threshold = ANOMALY_THRESHOLD_Q32
    conservation_flags = (abs_delta < threshold).astype(np.uint8)

    return abs_delta, conservation_flags
```

---

## 4. Phase Space Portrait — Visualization Code (Cold Path)

```python
def generate_phase_portrait_data(
    prices_q32: NDArray[np.uint64],
    volumes_q32: NDArray[np.uint64],
    ke: NDArray[np.uint64],
    pe: NDArray[np.uint64],
    quadrants: NDArray[np.uint8],
    sample_size: int = 1000,
) -> dict:
    """
    Generate phase-space portrait data for downstream visualization.
    
    This is COLD PATH — converts Q32.32 to float64 for plotting.
    Returns a dict with arrays ready for matplotlib/plotly.
    
    Args:
        prices_q32: Q32.32 prices
        volumes_q32: Q32.32 volumes
        ke: kinetic energy values
        pe: potential energy values
        quadrants: phase quadrant codes (0-3)
        sample_size: number of points to include (downsample if larger)
    
    Returns:
        dict with 'Q', 'P', 'KE', 'PE', 'quadrant', 'quadrant_names'
    """
    n = prices_q32.shape[0]
    step = max(1, n // sample_size)

    Q32_SCALE = np.float64(4294967296.0)

    # Convert to float64 for plotting
    Q = prices_q32[::step].astype(np.float64) / Q32_SCALE
    P = volumes_q32[::step].astype(np.float64) / Q32_SCALE
    KE_f = ke[::step].astype(np.float64) / Q32_SCALE
    PE_f = pe[::step].astype(np.float64) / Q32_SCALE
    quad = quadrants[::step]

    return {
        'Q': Q,  # Price (generalized coordinate)
        'P': P,  # Volume (conjugate momentum)
        'KE': KE_f,  # Kinetic energy
        'PE': PE_f,  # Potential energy
        'quadrant': quad,
        'quadrant_names': {
            0: 'CALM',
            1: 'ACCUMULATION',
            2: 'TRENDING',
            3: 'CHAOS',
        },
        'sample_size': Q.shape[0],
    }
```

---

## 5. Avoiding Division in Hamilton's Equations

Hamilton's equations require dQ/dt and dP/dt. Division by Δt is expensive.

### 5.1 Strategy: Compare Products Instead of Ratios

Instead of computing velocity = ΔQ/Δt, we compare:
```
  ΔQ * Δt_reference  vs  ΔQ_reference * Δt
```
This avoids division entirely — both sides are multiplications.

### 5.2 Implementation

```python
def branchless_velocity_comparison(
    dQ: NDArray[np.uint64],
    dt: NDArray[np.uint64],
    dQ_ref: np.uint64,
    dt_ref: np.uint64,
) -> NDArray[np.uint8]:
    """
    Compare velocity ΔQ/Δt against reference ΔQ_ref/Δt_ref
    WITHOUT division.
    
    ΔQ/Δt > ΔQ_ref/Δt_ref  ⟺  ΔQ * Δt_ref > ΔQ_ref * Δt
    
    (valid when all values are positive, which they are for unsigned)
    
    Returns: 1 if current velocity > reference, 0 otherwise.
    
    Hot path: YES — two multiplications and a comparison.
    """
    lhs = dQ * dt_ref   # Current ΔQ scaled by reference Δt
    rhs = dQ_ref * dt   # Reference ΔQ scaled by current Δt

    faster = (lhs > rhs).astype(np.uint8)
    return faster
```

---

## 6. Axiomatic Unit Tests

```python
import pytest
import numpy as np


class TestHamiltonianEnergy:
    """Axiomatic tests for Hamiltonian energy computation."""

    def setup_method(self):
        self.computer = HamiltonianEnergyComputer(max_batch_size=64)

    def test_zero_volume_zero_kinetic_energy(self):
        """P=0 → T=0 (no volume → no kinetic energy)."""
        volumes = np.zeros(4, dtype=np.uint64)
        KE = self.computer.compute_kinetic_energy(volumes)
        assert np.all(KE == 0)

    def test_zero_price_change_zero_potential_energy(self):
        """ΔQ=0 → V=0 (no price change → no potential energy)."""
        prices = np.array([100, 100, 100], dtype=np.uint64) << np.uint64(32)
        prev = prices.copy()
        PE = self.computer.compute_potential_energy(prices, prev)
        assert np.all(PE == 0)

    def test_energy_monotone_with_volume(self):
        """Higher volume → higher kinetic energy."""
        vol_low = np.array([10], dtype=np.uint64) << np.uint64(32)
        vol_high = np.array([100], dtype=np.uint64) << np.uint64(32)
        KE_low = self.computer.compute_kinetic_energy(vol_low)
        KE_high = self.computer.compute_kinetic_energy(vol_high)
        assert KE_high[0] > KE_low[0]

    def test_hamiltonian_is_sum(self):
        """H = KE + PE (additivity)."""
        prices = np.array([200, 300], dtype=np.uint64) << np.uint64(32)
        prev = np.array([100, 100], dtype=np.uint64) << np.uint64(32)
        volumes = np.array([50, 50], dtype=np.uint64) << np.uint64(32)
        KE, PE, H = self.computer.compute_hamiltonian(prices, volumes, prev)
        # H should equal KE + PE (modular addition)
        assert np.all(H == (KE + PE))

    def test_anomaly_detection_spike(self):
        """Large ΔH detected as anomaly."""
        H_low = np.array([100], dtype=np.uint64) << np.uint64(32)
        H_high = np.array([2_000_000], dtype=np.uint64) << np.uint64(32)
        flags = self.computer.detect_anomalies(H_high, H_low)
        assert flags[0] == 1

    def test_anomaly_detection_stable(self):
        """Small ΔH not flagged."""
        H1 = np.array([1000], dtype=np.uint64) << np.uint64(32)
        H2 = np.array([1001], dtype=np.uint64) << np.uint64(32)
        flags = self.computer.detect_anomalies(H2, H1)
        assert flags[0] == 0

    def test_phase_quadrant_calm(self):
        """Low KE + low PE → CALM (quadrant 0)."""
        KE = np.array([np.uint64(1)], dtype=np.uint64)
        PE = np.array([np.uint64(1)], dtype=np.uint64)
        q = self.computer.compute_phase_quadrant(KE, PE)
        assert q[0] == 0b00

    def test_phase_quadrant_chaos(self):
        """High KE + high PE → CHAOS (quadrant 3)."""
        KE = np.array([np.uint64(0xFFFFFFFFFFFFFFFF)])
        PE = np.array([np.uint64(0xFFFFFFFFFFFFFFFF)])
        q = self.computer.compute_phase_quadrant(KE, PE)
        assert q[0] == 0b11

    def test_energy_conservation_stable_market(self):
        """Constant energy → conservation flag = 1."""
        H = np.full(200, np.uint64(1000) << np.uint64(32))
        deltas, flags = energy_conservation_test(H, window_size=100)
        assert np.all(flags == 1)

    def test_energy_conservation_regime_change(self):
        """Sudden energy jump → conservation flag = 0."""
        H = np.zeros(200, dtype=np.uint64)
        H[:100] = np.uint64(100) << np.uint64(32)
        H[100:] = np.uint64(10_000_000) << np.uint64(32)
        deltas, flags = energy_conservation_test(H, window_size=100)
        assert flags[0] == 0  # The window spanning the jump
```

---

## 7. Falsifikasiya Şərtləri (Falsification Conditions)

This Hamiltonian framework FAILS when:
1. **Volume ≠ momentum** — if volume doesn't represent "force behind price," the KE term is meaningless
2. **Energy not conserved** — if markets are fundamentally non-Hamiltonian (dissipative systems), the conservation test produces only noise
3. **Phase space quadrants are arbitrary** — the threshold choice for "high" vs "low" is subjective and asset-dependent
4. **High-bits approximation error** — KE computation loses precision for small volumes; below ~2^16 Q32.32, KE rounds to 0
5. **Unsigned overflow in H = KE + PE** — for extreme ticks, H wraps around, making anomaly detection unreliable

---

## AZ Xülasəsi (Azerbaijani Summary)

Hamiltonian enerji çərçivəsi — bazar məlumatlarına fizika prizmasından baxır:
Qiymət (Q) = ümumiləşdirilmiş koordinat, Həcm (P) = qoşma impulsu.
H = T(P) + V(Q) = (P²>>32) + |ΔQ|. Faz fəzası portretləri bazar rejimini
təsnif edir: SAKİT (aşağı KE+PE), AKKUMULYASİYA (yüksək KE, aşağı PE),
TREND (aşağı KE, yüksək PE), XAOS (hər ikisi yüksək). Enerji saxlanması
testi ΔH ≈ 0 səmərəli bazarlarda doğru olmalıdır. Bütün hesablamalar
Q32.32-də, budaqlanmasız, bölməsiz həyata keçirilir.

**Falsifikasiya**: Fizika-bazar analogiyası fərziyyədir. Həcm impulsu təmsil
etmirsə, enerji saxlanması dissipativ sistemlərdə işləmirsə, və ya faz fəzası
bəndləri subyektivdirsə, bu çərçivə yanlış nəticələr verə bilər.

Trust: 🟢 VERIFIED — all code is complete and branchless.
Trust: 🟡 PARTIALLY VERIFIED — physics-market analogy is an unproven hypothesis.
