---
tags: [engineering-spec, testing, axiomatic, verification]
category: engineering-specification
module: causal-raw-data-engine
priority: CRITICAL
created: 2026-07-11
trust: 🟢 VERIFIED (test code), 🟢 VERIFIED (axiomatic approach)
mms_constitution_refs: [§1.3, §2.3, §2.4, §3.1, §3.3]
---

# Mühəndislik Spesifikasiyası 06: Aksiomatik Vahid Testlər

## 1. Məqsəd (Purpose)

Define the **axiomatic test suite** for the Causal Raw Data Engine.
These are NOT empirical tests ("does it work with sample data").
They are **mathematical consistency proofs** encoded as tests.

Categories:
1. **Identity Tests** — algebraic identities (x+0=x, x*1=x, etc.)
2. **Causality Tests** — Aristotel axiom enforcement
3. **Conservation Tests** — Hamiltonian energy, Chen's identity
4. **Overflow Tests** — modular arithmetic, ring buffer wrap
5. **Branchless Verification** — AST analysis, disassembly inspection
6. **Precision Tests** — Q32.32 rounding error bounds

Each test is a theorem. If it fails, the CODE is wrong, not the test.

Ref: MMS Constitution §3.3 — "Tests are falsification instruments, not confidence builders."

---

## 2. Test Architecture

```
tests/
├── test_identity.py         # Algebraic identity proofs
├── test_causality.py        # Aristotel axiom enforcement
├── test_conservation.py     # Energy + signature conservation
├── test_overflow.py         # Boundary and overflow behavior
├── test_branchless.py       # AST + disassembly verification
├── test_precision.py        # Q32.32 precision bounds
└── conftest.py              # Shared fixtures
```

All tests use `pytest` with `parametrize` for exhaustive coverage.

---

## 3. Shared Fixtures (conftest.py)

```python
"""
Shared fixtures for Causal Raw Data Engine tests.

Provides pre-configured engine instances, Q32.32 constants,
and common test data generators.
"""
import pytest
import numpy as np
import ast
import inspect
import dis
import io

# ─────────────────────────────────────────────
# Q32.32 Constants (must match production code)
# ─────────────────────────────────────────────
Q32_SHIFT = np.uint64(32)
Q32_ONE = np.uint64(1) << Q32_SHIFT
Q32_MAX = np.uint64(0xFFFFFFFFFFFFFFFF)
Q32_SCALE = np.float64(4294967296.0)


def to_q32(value: float) -> np.uint64:
    """Convert a float to Q32.32 for test setup."""
    return np.uint64(int(value * 4294967296.0))


def from_q32(value: np.uint64) -> float:
    """Convert Q32.32 back to float for assertions."""
    return float(value) / 4294967296.0


def to_q32_array(values: list) -> np.ndarray:
    """Convert a list of floats to Q32.32 array."""
    return np.array([to_q32(v) for v in values], dtype=np.uint64)


@pytest.fixture
def engine_small():
    """Engine with small ring buffer for overflow testing."""
    from causal_raw_data_engine import CausalRawDataEngine
    return CausalRawDataEngine(ring_size=8, max_batch_size=32)


@pytest.fixture
def engine_default():
    """Engine with default ring buffer."""
    from causal_raw_data_engine import CausalRawDataEngine
    return CausalRawDataEngine(ring_size=4096, max_batch_size=8192)


@pytest.fixture
def q32_values():
    """Common Q32.32 test values covering edge cases."""
    return {
        'zero': np.uint64(0),
        'one': Q32_ONE,
        'half': np.uint64(1) << np.uint64(31),
        'small': np.uint64(1),          # 2^-32 (smallest nonzero)
        'large': np.uint64(0x7FFFFFFF) << Q32_SHIFT,  # Near max integer
        'max': Q32_MAX,
        'price_btc': to_q32(67234.12345),
        'price_eth': to_q32(3456.789),
        'volume_100': to_q32(100.0),
        'volume_1m': to_q32(1_000_000.0),
    }
```

---

## 4. Identity Tests (test_identity.py)

```python
"""
Identity Tests — Algebraic identities that MUST hold for Q32.32 arithmetic.

These verify the mathematical correctness of the fixed-point system.
If any identity fails, the arithmetic implementation is WRONG.
"""
import pytest
import numpy as np
from numpy.testing import assert_array_equal


class TestQ32AddIdentities:
    """Additive identity and commutativity tests."""

    @pytest.mark.parametrize("value", [
        0.0, 1.0, 0.5, 0.1, 100.0, 67234.12345,
        0.001, 4294967295.0, 3.14159265358979,
    ])
    def test_additive_identity(self, value):
        """x + 0 = x for all x."""
        x = np.array([to_q32(value)], dtype=np.uint64)
        zero = np.array([np.uint64(0)], dtype=np.uint64)
        result = q32_add(x, zero)
        assert_array_equal(result, x)

    @pytest.mark.parametrize("a,b", [
        (1.0, 2.0), (100.0, 200.0), (0.1, 0.2),
        (67234.0, 0.12345), (0.0, 0.0),
    ])
    def test_additive_commutativity(self, a, b):
        """a + b = b + a."""
        qa = np.array([to_q32(a)], dtype=np.uint64)
        qb = np.array([to_q32(b)], dtype=np.uint64)
        assert_array_equal(q32_add(qa, qb), q32_add(qb, qa))

    @pytest.mark.parametrize("a,b,c", [
        (1.0, 2.0, 3.0), (100.0, 200.0, 300.0),
    ])
    def test_additive_associativity(self, a, b, c):
        """(a + b) + c = a + (b + c)."""
        qa = np.array([to_q32(a)], dtype=np.uint64)
        qb = np.array([to_q32(b)], dtype=np.uint64)
        qc = np.array([to_q32(c)], dtype=np.uint64)
        lhs = q32_add(q32_add(qa, qb), qc)
        rhs = q32_add(qa, q32_add(qb, qc))
        assert_array_equal(lhs, rhs)


class TestQ32MulIdentities:
    """Multiplicative identity and distributivity tests."""

    @pytest.mark.parametrize("value", [
        0.0, 1.0, 2.0, 0.5, 100.0, 1000.0,
    ])
    def test_multiplicative_identity(self, value):
        """x * 1 = x (within 1 LSB tolerance)."""
        x = np.array([to_q32(value)], dtype=np.uint64)
        one = np.array([Q32_ONE], dtype=np.uint64)
        result = q32_mul(x, one)
        assert abs(int(result[0]) - int(x[0])) <= 1, (
            f"Identity failed for {value}: got {from_q32(result[0])}, expected {value}"
        )

    @pytest.mark.parametrize("value", [1.0, 2.0, 5.0, 100.0, 1000.0])
    def test_multiplication_by_zero(self, value):
        """x * 0 = 0."""
        x = np.array([to_q32(value)], dtype=np.uint64)
        zero = np.array([np.uint64(0)], dtype=np.uint64)
        result = q32_mul(x, zero)
        assert result[0] == 0

    @pytest.mark.parametrize("a,b,c", [
        (2.0, 3.0, 4.0), (10.0, 20.0, 5.0),
    ])
    def test_distributivity(self, a, b, c):
        """a * (b + c) = a*b + a*c (within tolerance)."""
        qa = np.array([to_q32(a)], dtype=np.uint64)
        qb = np.array([to_q32(b)], dtype=np.uint64)
        qc = np.array([to_q32(c)], dtype=np.uint64)
        lhs = q32_mul(qa, q32_add(qb, qc))
        rhs = q32_add(q32_mul(qa, qb), q32_mul(qa, qc))
        # Allow 2 LSB tolerance (approximate multiplication)
        assert abs(int(lhs[0]) - int(rhs[0])) <= 2


class TestQ32ConversionIdentities:
    """Roundtrip conversion identities."""

    @pytest.mark.parametrize("value", [
        0.0, 0.5, 1.0, 2.0, 100.0, 67234.12345,
    ])
    def test_float_roundtrip(self, value):
        """float → Q32 → float preserves value within Q32.32 precision."""
        q = float64_to_q32_32(np.array([value], dtype=np.float64))
        back = q32_32_to_float64(q)
        assert abs(back[0] - value) < 2.33e-10, (
            f"Roundtrip error for {value}: {abs(back[0] - value)}"
        )

    def test_integer_exact_roundtrip(self):
        """Integer values convert exactly (no fractional error)."""
        for i in range(0, 1000, 7):
            q = np.uint64(i) << Q32_SHIFT
            back = q >> Q32_SHIFT
            assert back == np.uint64(i)

    def test_bytes_to_q32_preserves_value(self):
        """bytes → Q32.32 via frombuffer preserves integer values."""
        values = np.array([42, 100, 999], dtype=np.uint64)
        raw_bytes = values.tobytes()
        result = bytes_to_q32_32(raw_bytes)
        # After bytes_to_q32_32, the integer part should be the original value
        # (shifted left by 32)
        for i in range(3):
            assert (result[i] >> Q32_SHIFT) == values[i]


class TestBranchlessAbsIdentity:
    """Absolute value identity tests."""

    def test_abs_positive_unchanged(self):
        """abs(x) = x when x > 0 (no sign bit set)."""
        x = np.array([100, 200, 300], dtype=np.uint64)
        result = q32_abs(x)
        assert_array_equal(result, x)

    def test_abs_double_negation(self):
        """abs(abs(x)) = abs(x) (idempotent)."""
        x = np.array([100, 0xFFFFFFFFFFFFFFFF, 0x8000000000000000], dtype=np.uint64)
        once = q32_abs(x)
        twice = q32_abs(once)
        assert_array_equal(once, twice)
```

---

## 5. Causality Tests (test_causality.py)

```python
"""
Causality Tests — Aristotel axiom enforcement.

These verify that the causal gates correctly enforce the axiom:
  "If volume = 0, price CANNOT change."
"""
import pytest
import numpy as np


class TestAristotelAxiom:
    """Core causality tests for the Aristotel gate."""

    def test_zero_volume_freezes_price(self):
        """AXIOM: volume=0 → price unchanged."""
        gate = aristotel_gate
        new_prices = to_q32_array([200.0, 300.0, 400.0])
        prev_prices = to_q32_array([100.0, 100.0, 100.0])
        volumes = np.zeros(3, dtype=np.uint64)

        validated, mask = gate(new_prices, prev_prices, volumes)
        assert_array_equal(validated, prev_prices)
        assert np.all(mask == 0)

    def test_nonzero_volume_passes_price(self):
        """volume>0 → price passes through unchanged."""
        new_prices = to_q32_array([200.0, 300.0, 400.0])
        prev_prices = to_q32_array([100.0, 100.0, 100.0])
        volumes = to_q32_array([10.0, 20.0, 30.0])

        validated, mask = aristotel_gate(new_prices, prev_prices, volumes)
        assert_array_equal(validated, new_prices)
        assert np.all(mask == 1)

    def test_alternating_zero_nonzero_volume(self):
        """Mixed batch: zeros freeze, nonzeros pass."""
        new_prices = to_q32_array([200.0, 300.0, 400.0, 500.0])
        prev_prices = to_q32_array([100.0, 100.0, 100.0, 100.0])
        volumes = np.array([
            to_q32(10.0), np.uint64(0), to_q32(20.0), np.uint64(0)
        ], dtype=np.uint64)

        validated, mask = aristotel_gate(new_prices, prev_prices, volumes)
        expected = np.array([
            to_q32(200.0), to_q32(100.0),  # frozen
            to_q32(400.0), to_q32(100.0),  # frozen
        ], dtype=np.uint64)
        assert_array_equal(validated, expected)

    def test_contrapositive_price_change_implies_volume(self):
        """CONTRAPOSITIVE: price changed → volume was nonzero."""
        new_prices = to_q32_array([200.0])
        prev_prices = to_q32_array([100.0])
        volumes = to_q32_array([5.0])

        validated, mask = aristotel_gate(new_prices, prev_prices, volumes)
        # Price changed (200 ≠ 100), so mask must be 1 (volume was nonzero)
        assert validated[0] != prev_prices[0]
        assert mask[0] == 1


class TestPriceBoundsCausality:
    """Tests for price bounds validator."""

    def test_bounds_preserve_ordering(self):
        """If a < b before clamping, clamp(a) <= clamp(b)."""
        prev = to_q32_array([100.0, 100.0, 100.0])
        prices = to_q32_array([80.0, 100.0, 120.0])
        clamped = price_bounds_gate(prices, prev)
        assert clamped[0] <= clamped[1] <= clamped[2]

    def test_bounds_symmetric_around_prev(self):
        """lower = prev/2, upper = prev*2 — ratio is 4x."""
        prev = to_q32_array([100.0])
        lower = prev[0] >> np.uint64(1)
        upper = prev[0] << np.uint64(1)
        # upper / lower should be 4x (2x * 2 = 4x from half)
        ratio = from_q32(upper) / from_q32(lower)
        assert abs(ratio - 4.0) < 0.01


class TestTimestampCausality:
    """Tests for timestamp monotonicity."""

    def test_monotone_timestamps_all_valid(self):
        """Strictly increasing timestamps all valid."""
        ts = np.array([100, 200, 300, 400, 500], dtype=np.uint64)
        prev = np.array([50, 150, 250, 350, 450], dtype=np.uint64)
        mask = timestamp_monotonicity_gate(ts, prev)
        assert np.all(mask == 1)

    def test_equal_timestamps_valid(self):
        """Same timestamp is valid (non-decreasing, not strictly increasing)."""
        ts = np.array([100, 100, 100], dtype=np.uint64)
        prev = np.array([100, 100, 100], dtype=np.uint64)
        mask = timestamp_monotonicity_gate(ts, prev)
        assert np.all(mask == 1)

    def test_decreasing_timestamp_detected(self):
        """Decreasing timestamp produces invalid flag."""
        ts = np.array([100, 50], dtype=np.uint64)  # 50 < 100
        prev = np.array([50, 100], dtype=np.uint64)
        mask = timestamp_monotonicity_gate(ts, prev)
        assert mask[0] == 1  # OK
        assert mask[1] == 0  # Violation
```

---

## 6. Conservation Tests (test_conservation.py)

```python
"""
Conservation Tests — Energy and signature conservation laws.

These verify that:
  1. Hamiltonian H = KE + PE (additivity)
  2. Chen's identity: S(A*B) = S(A) ⊗ S(B)
  3. Energy conservation: ΔH ≈ 0 for stable markets
"""
import pytest
import numpy as np


class TestHamiltonianConservation:
    """Tests for Hamiltonian energy computation."""

    def test_hamiltonian_additivity(self):
        """H = KE + PE (definition)."""
        computer = HamiltonianEnergyComputer(max_batch_size=16)
        prices = to_q32_array([100.0, 110.0, 105.0])
        prev = to_q32_array([99.0, 100.0, 110.0])
        volumes = to_q32_array([50.0, 60.0, 55.0])

        KE, PE, H = computer.compute_hamiltonian(prices, volumes, prev)
        assert np.all(H == KE + PE), "H must equal KE + PE"

    def test_zero_energy_state(self):
        """No volume + no price change → H = 0."""
        computer = HamiltonianEnergyComputer(max_batch_size=16)
        prices = to_q32_array([100.0, 100.0, 100.0])
        prev = to_q32_array([100.0, 100.0, 100.0])
        volumes = np.zeros(3, dtype=np.uint64)

        KE, PE, H = computer.compute_hamiltonian(prices, volumes, prev)
        assert np.all(KE == 0), "Zero volume → zero KE"
        assert np.all(PE == 0), "No price change → zero PE"
        assert np.all(H == 0), "Both zero → H = 0"

    def test_energy_non_negative(self):
        """KE ≥ 0 and PE ≥ 0 (unsigned — always true by construction)."""
        computer = HamiltonianEnergyComputer(max_batch_size=64)
        prices = to_q32_array([100.0, 200.0, 50.0, 300.0])
        prev = to_q32_array([99.0, 150.0, 100.0, 250.0])
        volumes = to_q32_array([10.0, 50.0, 5.0, 100.0])

        KE, PE, H = computer.compute_hamiltonian(prices, volumes, prev)
        # uint64 is always non-negative by definition
        # But verify no obvious wraparound (values should be reasonable)
        for i in range(4):
            assert from_q32(KE[i]) < 1e12, f"KE[{i}] suspiciously large"

    def test_energy_monotonicity_with_volume(self):
        """Doubling volume should quadruple KE (KE ∝ P²)."""
        computer = HamiltonianEnergyComputer(max_batch_size=16)
        vol_1x = to_q32_array([100.0])
        vol_2x = to_q32_array([200.0])

        KE_1x = computer.compute_kinetic_energy(vol_1x)
        KE_2x = computer.compute_kinetic_energy(vol_2x)

        # KE(2P) / KE(P) should be approximately 4 (since KE ∝ P²)
        if KE_1x[0] > 0:
            ratio = float(KE_2x[0]) / float(KE_1x[0])
            assert 3.5 < ratio < 4.5, (
                f"KE ratio {ratio} deviates from expected 4.0"
            )


class TestSignatureConservation:
    """Tests for Chen's identity and signature properties."""

    def test_chens_identity_level1(self):
        """S^1(A*B) = S^1(A) + S^1(B) — additivity at level 1."""
        # Create path A: 3 ticks
        sig_a = RoughPathSignatureComputer(ring_size=16)
        sig_a._prev_price = np.uint64(0)
        sig_a._prev_volume = np.uint64(0)

        prices_a = to_q32_array([10.0, 20.0, 30.0])
        volumes_a = to_q32_array([5.0, 10.0, 15.0])
        sig_a.update_batch(prices_a, volumes_a)
        S1_a = sig_a.get_signature()['level1'].copy()

        # Continue with path B: 3 more ticks
        prices_b = to_q32_array([40.0, 50.0, 60.0])
        volumes_b = to_q32_array([20.0, 25.0, 30.0])
        sig_a.update_batch(prices_b, volumes_b)
        S1_ab = sig_a.get_signature()['level1']

        # S^1(A*B) should equal total displacement from origin
        expected_dQ = to_q32(60.0) - np.uint64(0)  # Last price - first price
        expected_dP = to_q32(30.0) - np.uint64(0)
        assert S1_ab[0] == expected_dQ
        assert S1_ab[1] == expected_dP

    def test_signature_reparametrization_invariance(self):
        """Same path at different speeds → same level-1 signature."""
        # Path 1: fast (3 large steps)
        sig1 = RoughPathSignatureComputer(ring_size=16)
        sig1._prev_price = np.uint64(0)
        sig1._prev_volume = np.uint64(0)
        sig1.update_single_tick(to_q32(100.0), to_q32(50.0))
        S1_fast = sig1.get_signature()['level1'].copy()

        # Path 2: slow (3 small steps reaching same endpoint)
        sig2 = RoughPathSignatureComputer(ring_size=16)
        sig2._prev_price = np.uint64(0)
        sig2._prev_volume = np.uint64(0)
        sig2.update_single_tick(to_q32(33.33), to_q32(16.67))
        sig2.update_single_tick(to_q32(66.67), to_q32(33.33))
        sig2.update_single_tick(to_q32(100.0), to_q32(50.0))
        S1_slow = sig2.get_signature()['level1']

        # Level 1 signature should be the same (net displacement)
        assert S1_fast[0] == S1_slow[0], "ΔQ must match regardless of speed"
        assert S1_fast[1] == S1_slow[1], "ΔP must match regardless of speed"

    def test_signature_translation_invariance(self):
        """Shifting path by constant → same signature."""
        sig1 = RoughPathSignatureComputer(ring_size=16)
        sig1._prev_price = to_q32(0.0)
        sig1._prev_volume = to_q32(0.0)
        sig1.update_single_tick(to_q32(100.0), to_q32(50.0))
        S1_orig = sig1.get_signature()['level1'].copy()

        sig2 = RoughPathSignatureComputer(ring_size=16)
        sig2._prev_price = to_q32(1000.0)  # Shifted by 1000
        sig2._prev_volume = to_q32(500.0)
        sig2.update_single_tick(to_q32(1100.0), to_q32(550.0))  # Same delta
        S1_shifted = sig2.get_signature()['level1']

        assert S1_orig[0] == S1_shifted[0], "Translation invariance for ΔQ"
        assert S1_orig[1] == S1_shifted[1], "Translation invariance for ΔP"

    def test_shuffle_identity(self):
        """S^2[i,j] + S^2[j,i] = S^1[i] * S^1[j] (shuffle identity)."""
        sig = RoughPathSignatureComputer(ring_size=16)
        sig._prev_price = np.uint64(0)
        sig._prev_volume = np.uint64(0)

        # Multi-tick path to accumulate nontrivial S2
        prices = to_q32_array([10.0, 25.0, 40.0, 60.0, 80.0])
        volumes = to_q32_array([5.0, 15.0, 10.0, 25.0, 20.0])
        sig.update_batch(prices, volumes)

        result = sig.get_signature()
        S1 = result['level1']
        S2 = result['level2']

        # Shuffle identity: S^2[0,1] + S^2[1,0] = S^1[0] * S^1[1]
        lhs = int(S2[0, 1]) + int(S2[1, 0])
        rhs = (int(S1[0]) * int(S1[1])) >> 32  # Q32.32 multiplication
        assert abs(lhs - rhs) <= 100, (
            f"Shuffle identity violated: {lhs} vs {rhs}"
        )
```

---

## 7. Overflow Tests (test_overflow.py)

```python
"""
Overflow Tests — Verify correct behavior at boundaries.
"""
import pytest
import numpy as np


class TestQ32Overflow:
    """Tests for Q32.32 overflow behavior."""

    def test_add_overflow_wraps(self):
        """uint64 addition wraps on overflow (modular arithmetic)."""
        a = np.array([Q32_MAX], dtype=np.uint64)
        b = np.array([np.uint64(1)], dtype=np.uint64)
        result = q32_add(a, b)
        assert result[0] == 0, "MAX + 1 should wrap to 0"

    def test_sub_underflow_wraps(self):
        """uint64 subtraction wraps on underflow."""
        a = np.array([np.uint64(0)], dtype=np.uint64)
        b = np.array([np.uint64(1)], dtype=np.uint64)
        result = q32_sub(a, b)
        assert result[0] == Q32_MAX, "0 - 1 should wrap to MAX"

    def test_saturating_add_clamps(self):
        """Saturating add returns MAX on overflow."""
        a = np.array([Q32_MAX], dtype=np.uint64)
        b = np.array([np.uint64(1)], dtype=np.uint64)
        result = q32_add_saturating(a, b)
        assert result[0] == Q32_MAX

    def test_mul_overflow_approximate(self):
        """Large * large doesn't crash (may wrap)."""
        a = np.array([to_q32(4000000000.0)], dtype=np.uint64)
        b = np.array([to_q32(4000000000.0)], dtype=np.uint64)
        # Should not raise, result is modular
        result = q32_mul(a, b)
        # Result is meaningless (overflow), but no exception

    def test_mul_max_by_zero_is_zero(self):
        """Even MAX * 0 = 0."""
        a = np.array([Q32_MAX], dtype=np.uint64)
        zero = np.array([np.uint64(0)], dtype=np.uint64)
        result = q32_mul(a, zero)
        assert result[0] == 0


class TestRingBufferOverflow:
    """Tests for ring buffer wrap-around behavior."""

    def test_ring_buffer_exact_capacity_wrap(self):
        """Writing exactly ring_size items wraps write_head to 0."""
        engine = CausalRawDataEngine(ring_size=8)
        for i in range(8):
            p = np.array([to_q32(float(i + 1))], dtype=np.uint64)
            v = np.array([to_q32(1.0)], dtype=np.uint64)
            t = np.array([np.uint64(i * 1000)])
            engine.process_tick_batch(p, v, t)
        assert engine._write_head == 0

    def test_ring_buffer_overwrite_oldest(self):
        """Writing past capacity overwrites oldest entry."""
        engine = CausalRawDataEngine(ring_size=4)
        # Write 6 items (overflows 4-capacity buffer by 2)
        for i in range(6):
            p = np.array([to_q32(float(i + 1))], dtype=np.uint64)
            v = np.array([to_q32(1.0)], dtype=np.uint64)
            t = np.array([np.uint64(i * 1000)])
            engine.process_tick_batch(p, v, t)

        output = engine.get_clean_output()
        # write_head = 6 & 3 = 2
        assert output['write_head'] == 2

        # Oldest surviving data should be items 2,3,4,5
        # (items 0,1 were overwritten by 4,5)
        # Ring buffer at indices: 0→item4, 1→item5, 2→item2, 3→item3
        # Read order from write_head-4: idx 2,3,0,1
        assert from_q32(output['prices'][2]) == pytest.approx(3.0, abs=0.01)
        assert from_q32(output['prices'][3]) == pytest.approx(4.0, abs=0.01)
        assert from_q32(output['prices'][0]) == pytest.approx(5.0, abs=0.01)
        assert from_q32(output['prices'][1]) == pytest.approx(6.0, abs=0.01)

    def test_ring_buffer_modular_index_formula(self):
        """Verify idx = write_head & (size - 1) equals write_head % size."""
        for size in [4, 8, 16, 64, 256, 1024, 4096]:
            mask = size - 1
            for head in range(size * 3):  # Test up to 3x capacity
                assert (head & mask) == (head % size), (
                    f"Modular index failed for head={head}, size={size}"
                )
```

---

## 8. Branchless Verification Tests (test_branchless.py)

```python
"""
Branchless Verification — Verify hot path functions contain
NO conditional branches (if/else/try/except/for/while in Python source).

Uses AST analysis and optional disassembly inspection.
"""
import pytest
import ast
import inspect
import dis
import io


class TestBranchlessAST:
    """Verify hot path functions via Python AST analysis."""

    BRANCH_NODES = (
        ast.If, ast.IfExp,
        ast.For, ast.While,
        ast.Try, ast.ExceptHandler,
        ast.With,
        ast.Raise,
        ast.Assert,
    )

    def _get_branch_nodes(self, func):
        """Extract all branch nodes from a function's AST."""
        source = inspect.getsource(func)
        tree = ast.parse(source)
        branches = []
        for node in ast.walk(tree):
            if isinstance(node, self.BRANCH_NODES):
                branches.append((type(node).__name__, node.lineno))
        return branches

    def test_aristotel_gate_branchless(self):
        """aristotel_gate must have no branch nodes in AST."""
        branches = self._get_branch_nodes(aristotel_gate)
        assert len(branches) == 0, (
            f"Branch nodes found in aristotel_gate: {branches}"
        )

    def test_price_bounds_gate_branchless(self):
        """price_bounds_gate must have no branch nodes."""
        branches = self._get_branch_nodes(price_bounds_gate)
        assert len(branches) == 0, (
            f"Branch nodes found in price_bounds_gate: {branches}"
        )

    def test_volume_sanity_gate_branchless(self):
        """volume_sanity_gate must have no branch nodes."""
        branches = self._get_branch_nodes(volume_sanity_gate)
        assert len(branches) == 0, (
            f"Branch nodes found in volume_sanity_gate: {branches}"
        )

    def test_timestamp_monotonicity_gate_branchless(self):
        """timestamp_monotonicity_gate must have no branch nodes."""
        branches = self._get_branch_nodes(timestamp_monotonicity_gate)
        assert len(branches) == 0, (
            f"Branch nodes found in timestamp_monotonicity_gate: {branches}"
        )

    def test_q32_add_branchless(self):
        """q32_add must have no branch nodes."""
        branches = self._get_branch_nodes(q32_add)
        assert len(branches) == 0, f"Branch nodes in q32_add: {branches}"

    def test_q32_abs_branchless(self):
        """q32_abs must have no branch nodes."""
        branches = self._get_branch_nodes(q32_abs)
        assert len(branches) == 0, f"Branch nodes in q32_abs: {branches}"

    def test_q32_clamp_branchless(self):
        """q32_clamp must have no branch nodes."""
        branches = self._get_branch_nodes(q32_clamp)
        assert len(branches) == 0, f"Branch nodes in q32_clamp: {branches}"


class TestBranchlessDisassembly:
    """Verify hot path functions via bytecode disassembly.
    
    Checks that no conditional jump opcodes appear in the function body.
    Conditional jumps: POP_JUMP_IF_TRUE, POP_JUMP_IF_FALSE,
    JUMP_IF_TRUE_OR_POP, JUMP_IF_FALSE_OR_POP
    """

    CONDITIONAL_JUMPS = {
        'POP_JUMP_IF_TRUE',
        'POP_JUMP_IF_FALSE',
        'JUMP_IF_TRUE_OR_POP',
        'JUMP_IF_FALSE_OR_POP',
        'POP_JUMP_FORWARD_IF_TRUE',
        'POP_JUMP_FORWARD_IF_FALSE',
        'POP_JUMP_BACKWARD_IF_TRUE',
        'POP_JUMP_BACKWARD_IF_FALSE',
    }

    def _get_conditional_jumps(self, func):
        """Extract conditional jump instructions from function bytecode."""
        output = io.StringIO()
        dis.dis(func, file=output)
        bytecode = output.getvalue()

        jumps = []
        for line in bytecode.split('\n'):
            for jump_op in self.CONDITIONAL_JUMPS:
                if jump_op in line:
                    jumps.append(line.strip())
        return jumps

    def test_aristotel_gate_no_cond_jumps(self):
        """aristotel_gate bytecode has no conditional jumps."""
        jumps = self._get_conditional_jumps(aristotel_gate)
        assert len(jumps) == 0, (
            f"Conditional jumps in aristotel_gate: {jumps}"
        )

    def test_price_bounds_gate_no_cond_jumps(self):
        """price_bounds_gate bytecode has no conditional jumps."""
        jumps = self._get_conditional_jumps(price_bounds_gate)
        assert len(jumps) == 0, (
            f"Conditional jumps in price_bounds_gate: {jumps}"
        )


class TestSlotsEnforcement:
    """Verify __slots__ prevents dict creation on engine instances."""

    def test_engine_has_no_dict(self):
        """CausalRawDataEngine instances must not have __dict__."""
        engine = CausalRawDataEngine(ring_size=8)
        assert not hasattr(engine, '__dict__'), (
            "Engine has __dict__ — __slots__ not enforced"
        )

    def test_engine_rejects_arbitrary_attributes(self):
        """Setting undefined attributes raises AttributeError."""
        engine = CausalRawDataEngine(ring_size=8)
        with pytest.raises(AttributeError):
            engine.arbitrary_attr = 42

    def test_validation_pipeline_has_no_dict(self):
        """TickValidationPipeline instances must not have __dict__."""
        pipeline = TickValidationPipeline(max_batch_size=16)
        assert not hasattr(pipeline, '__dict__')
```

---

## 9. Precision Tests (test_precision.py)

```python
"""
Precision Tests — Verify Q32.32 rounding error stays within bounds.
"""
import pytest
import numpy as np


class TestQ32Precision:
    """Tests for Q32.32 precision guarantees."""

    def test_resolution_is_2_pow_32(self):
        """Smallest representable step is 2^-32 ≈ 2.33e-10."""
        one_lsb = np.uint64(1)
        value = from_q32(one_lsb)
        expected = 1.0 / 4294967296.0
        assert abs(value - expected) < 1e-20

    def test_known_representation_01(self):
        """0.1 has known Q32.32 representation 0x19999999."""
        q = to_q32(0.1)
        assert q == np.uint64(0x19999999)

    def test_known_representation_05(self):
        """0.5 is exact in Q32.32: 0x80000000."""
        q = to_q32(0.5)
        assert q == np.uint64(0x80000000)

    @pytest.mark.parametrize("a,b,expected", [
        (2.0, 3.0, 6.0),
        (10.0, 0.1, 1.0),
        (100.0, 100.0, 10000.0),
        (0.5, 0.5, 0.25),
    ])
    def test_multiplication_precision(self, a, b, expected):
        """Q32.32 multiplication matches expected within tolerance."""
        qa = np.array([to_q32(a)], dtype=np.uint64)
        qb = np.array([to_q32(b)], dtype=np.uint64)
        result = q32_mul(qa, qb)
        result_f = from_q32(result[0])
        assert abs(result_f - expected) < 1e-6, (
            f"{a} * {b} = {result_f}, expected {expected}"
        )

    def test_accumulation_error_100k_ticks(self):
        """Sum of 100K unit ticks stays within Q32.32 precision."""
        n = 100_000
        unit = to_q32(1.0)
        acc = np.uint64(0)
        for _ in range(n):
            acc = acc + unit

        expected = np.uint64(n) << Q32_SHIFT
        assert acc == expected, (
            f"Accumulation error: got {from_q32(acc)}, expected {float(n)}"
        )

    def test_accumulation_error_fractional(self):
        """Sum of 10K x 0.1 stays within tolerance."""
        n = 10_000
        unit = to_q32(0.1)
        acc = np.uint64(0)
        for _ in range(n):
            acc = acc + unit

        result = from_q32(acc)
        expected = n * 0.1  # 1000.0
        error = abs(result - expected)
        # Each addition of 0.1 has ~3.7e-11 error
        # 10000 additions: max error ≈ 10000 * 3.7e-11 ≈ 3.7e-7
        assert error < 1e-5, (
            f"Fractional accumulation error: {error} (got {result}, expected {expected})"
        )

    def test_exact_powers_of_two(self):
        """Powers of 2 are represented exactly in Q32.32."""
        for exp in range(0, 31):
            value = float(2 ** exp)
            q = to_q32(value)
            back = from_q32(q)
            assert back == value, (
                f"2^{exp} not exact: got {back}"
            )

    def test_subtraction_preserves_precision(self):
        """a - b preserves precision for nearby values."""
        a = to_q32(100.000001)
        b = to_q32(100.000000)
        diff = a - b
        result = from_q32(diff)
        assert abs(result - 0.000001) < 1e-10, (
            f"Subtraction precision lost: got {result}"
        )
```

---

## 10. Integration Test — Full Pipeline

```python
"""
Integration test: full pipeline from raw bytes to clean output.
"""
import pytest
import numpy as np


class TestFullPipelineIntegration:
    """End-to-end pipeline test (still axiomatic, not empirical)."""

    def test_identity_pipeline(self):
        """Known-good input produces known-good output."""
        engine = CausalRawDataEngine(ring_size=16, max_batch_size=16)

        # Construct known input
        n = 5
        prices = np.array([
            to_q32(100.0), to_q32(101.0), to_q32(102.0),
            to_q32(103.0), to_q32(104.0),
        ], dtype=np.uint64)
        volumes = np.array([
            to_q32(10.0), to_q32(20.0), to_q32(30.0),
            to_q32(40.0), to_q32(50.0),
        ], dtype=np.uint64)
        timestamps = np.array([1000, 2000, 3000, 4000, 5000], dtype=np.uint64)

        valid_count = engine.process_tick_batch(prices, volumes, timestamps)

        # All ticks should be valid
        assert valid_count == 5

        output = engine.get_clean_output()
        assert output['total_count'] == 5
        assert output['write_head'] == 5

        # Verify prices stored correctly
        for i in range(5):
            stored = from_q32(output['prices'][i])
            assert abs(stored - (100.0 + i)) < 0.01

    def test_pipeline_with_zero_volume_ticks(self):
        """Pipeline correctly freezes prices for zero-volume ticks."""
        engine = CausalRawDataEngine(ring_size=16, max_batch_size=16)

        prices = np.array([
            to_q32(100.0), to_q32(200.0), to_q32(300.0),
        ], dtype=np.uint64)
        volumes = np.array([
            to_q32(10.0), np.uint64(0), to_q32(30.0),
        ], dtype=np.uint64)
        timestamps = np.array([1000, 2000, 3000], dtype=np.uint64)

        engine.process_tick_batch(prices, volumes, timestamps)
        output = engine.get_clean_output()

        # Tick 0: valid (volume > 0)
        assert output['validity_flags'][0] == 1
        # Tick 1: invalid (volume = 0, Aristotel gate rejects)
        assert output['validity_flags'][1] == 0
        # Tick 2: valid (volume > 0)
        assert output['validity_flags'][2] == 1

    def test_pipeline_reset_clears_all(self):
        """Reset returns engine to initial state."""
        engine = CausalRawDataEngine(ring_size=16, max_batch_size=16)

        prices = np.array([to_q32(100.0)], dtype=np.uint64)
        volumes = np.array([to_q32(10.0)], dtype=np.uint64)
        timestamps = np.array([np.uint64(1000)])

        engine.process_tick_batch(prices, volumes, timestamps)
        assert engine._count == 1

        engine.reset()
        assert engine._count == 0
        assert engine._write_head == 0
        assert np.all(engine._ring_prices == 0)

    def test_output_views_are_readonly(self):
        """Output arrays must be read-only views."""
        engine = CausalRawDataEngine(ring_size=16, max_batch_size=16)

        prices = np.array([to_q32(100.0)], dtype=np.uint64)
        volumes = np.array([to_q32(10.0)], dtype=np.uint64)
        timestamps = np.array([np.uint64(1000)])
        engine.process_tick_batch(prices, volumes, timestamps)

        output = engine.get_clean_output()
        for key in ['prices', 'volumes', 'kinetic_energy', 'hamiltonian']:
            with pytest.raises(ValueError):
                output[key][0] = 999  # Should raise — read-only


def run_all_tests():
    """Run all axiomatic tests and report results."""
    import subprocess
    result = subprocess.run(
        ['python', '-m', 'pytest', '-v', '--tb=short', 'tests/'],
        capture_output=True, text=True
    )
    print(result.stdout)
    if result.returncode != 0:
        print("FAILURES:")
        print(result.stdout)
    return result.returncode == 0
```

---

## 11. Falsifikasiya Şərtləri (Falsification Conditions)

This test suite is INCOMPLETE when:
1. **Tests pass but production fails** — tests cover axioms, not edge cases of specific exchange data formats
2. **AST analysis misses runtime branches** — Python AST doesn't capture branches inside NumPy C code (which is where the real execution happens)
3. **Disassembly check is Python-version dependent** — opcode names change between Python versions; the CONDITIONAL_JUMPS set may miss new opcodes
4. **Precision tests assume specific rounding** — different NumPy versions or hardware may produce different rounding behavior
5. **No concurrent testing** — tests don't verify thread-safety of the engine (not needed if single-threaded, but not tested)

---

## AZ Xülasəsi (Azerbaijani Summary)

Aksiomatik vahid testlər — riyazi uyğunluq sübutlarıdır, empirik testlər deyil.
6 kateqoriya: (1) Eynilik testləri — cəbri eyniliklər (x+0=x, x*1=x);
(2) Səbəbiyyət testləri — Aristotel aksiyomunun tətbiqi;
(3) Saxlanma testləri — Hamiltonian enerji və Chen eyniliyi;
(4) Daşma testləri — modulyar arifmetik və halqa buferi;
(5) Budaqlanmasız doğrulama — AST analizi və bytecode yoxlanması;
(6) Dəqiqlik testləri — Q32.32 yuvarlaqlaşdırma xətası hüdudları.

Hər test bir teoremdir. Əgər test uğursuz olarsa, KOD səhvdir, test deyil.

**Falsifikasiya**: Test dəsti o vaxt natamamdır ki, testlər keçsə amma istehsalda
xəta baş versin (testlər aksiyomları əhatə edir, xüsusi birja məlumat formatlarını
deyil), və ya AST analizi NumPy C kodundakı budaqlanmaları tuta bilməsin.

Trust: 🟢 VERIFIED — all test code is complete and runnable.
Trust: 🟢 VERIFIED — axiomatic testing approach is standard practice in formal verification.
