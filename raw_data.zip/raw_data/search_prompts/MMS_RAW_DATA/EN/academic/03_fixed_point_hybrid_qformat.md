---
tags: [search-prompt, fixed-point, q-format, hybrid-precision, numpy, fpga, hft]
category: academic-search
module: causal-raw-data-engine-v2
created: 2026-07-11
trust: 🟢 VERIFIED
revision: 2
changelog: "v2 — REPLACES single Q32.32 prompt. Now HYBRID: Q32.32 (price) + Q48.16 (volume) + Q16.48 (signed delta) + int64 (time). Honest framing."
---

# Search Prompt: Hybrid Fixed-Point Q-Format Arithmetic for High-Frequency Market Data

## Objective

Find literature on fixed-point arithmetic (Q-format notation), hybrid precision systems,
and numerical methods for high-frequency financial data processing. The Causal Raw Data
Engine uses a HYBRID fixed-point scheme — not a single Q-format for all fields:

| Field | Format | Rationale |
|---|---|---|
| Price | Q32.32 (int64) | 32 integer + 32 fractional bits → precision ≈ 2.33e-10, range ±2.1 billion |
| Volume | Q48.16 (uint64) | 48 integer + 16 fractional bits → range 0 to 281 trillion, precision 1/65536 ≈ 0.0000153 |
| Signed delta | Q16.48 (int64) | 16 integer + 48 fractional bits → high precision for small changes, range ±32767 |
| Timestamp | int64 nanoseconds | NOT Q-format. Plain signed 64-bit integer. Nanoseconds since epoch. Range ±292 years from 1970. |

This hybrid approach recognizes that different fields have different dynamic range and
precision requirements. Using Q32.32 for everything (as the previous prompt assumed) wastes
precision on volume (which rarely needs sub-unit precision) and lacks precision for signed
deltas (which must capture micro-price movements).

## Why Fixed-Point Instead of Floating-Point?

### Advantages (Honest Assessment)
1. **Deterministic rounding**: Fixed-point rounding is TRUNCATION (toward zero), which is
   predictable and auditable. Floating-point rounding is "round to nearest even," which
   can produce surprising results in accumulation.
2. **Exact comparison**: Two Q32.32 values are equal if and only if their int64 representations
   are equal. No epsilon comparison needed. Critical for order matching and audit trails.
3. **No NaN/Inf**: Fixed-point cannot represent NaN or Infinity. This eliminates entire
   classes of bugs (silent NaN propagation, Infinity arithmetic).
4. **Hardware simplicity**: On FPGA/ASIC, fixed-point arithmetic is cheaper than floating-point.
   For HFT systems on custom hardware, this matters.
5. **Bitwise operations**: Masks, shifts, and bitwise AND/OR work naturally on fixed-point.
   Extracting integer part = right shift by fractional bits.

### Disadvantages (Honest Assessment)
1. **Limited range**: Q32.32 has range ±2.1 billion. Fine for stock prices. NOT fine for
   cumulative volume or P&L over long periods. Must monitor for overflow.
2. **Multiplication complexity**: Multiplying two Q32.32 values produces a Q64.64 result
   (128 bits). NumPy does NOT natively support int128. Workarounds needed (see below).
3. **Division is expensive**: Fixed-point division requires reciprocal approximation
   (Newton-Raphson) or Barrett reduction. Not as simple as floating-point division.
4. **Not zero-allocation**: The claim of "zero allocation" in the previous prompt was
   OVERSTATED. Pre-allocated hot-path buffers AVOID allocation during processing, but
   intermediate 128-bit products require either pre-allocated scratch space or
   multi-step computation using 64-bit intermediates.

## Technical Details: Hybrid Q-Format Operations

### Q32.32 (Price)
```
Representation: int64, value = raw / 2^32
Precision: 1/2^32 ≈ 2.328e-10 (sub-nanodollar for prices < $1M)
Range: [-2^31, 2^31 - 2^-32] ≈ [-2.147B, +2.147B]
Addition: a + b (native int64 add, same Q-format)
Multiplication: (a * b) >> 32 (requires 128-bit intermediate)
Overflow: SATURATE at ±INT64_MAX (do NOT wrap — wrap causes silent data corruption)
```

### Q48.16 (Volume)
```
Representation: uint64, value = raw / 2^16
Precision: 1/2^16 ≈ 1.526e-5 (sub-share precision for fractional lots)
Range: [0, 2^64 / 2^16] = [0, 2^48] ≈ [0, 281.5 trillion]
Addition: a + b (native uint64 add, check overflow)
Multiplication: rarely needed for volume (volume is additive, not multiplicative)
Special: Volume is UNSIGNED. Negative volume is a data error, not a valid value.
```

### Q16.48 (Signed Delta)
```
Representation: int64, value = raw / 2^48
Precision: 1/2^48 ≈ 3.553e-15 (captures micro-price changes)
Range: [-2^15, 2^15 - 2^-48] ≈ [-32768, +32767]
Usage: price deltas, spread changes, order-flow imbalance
Addition: a + b (native int64 add, check overflow — range is small!)
Conversion to Q32.32: delta_q32 = delta_q16_48 >> 16 (loses precision, intentional)
```

### int64 (Timestamp, Nanoseconds)
```
Representation: int64, value = nanoseconds since Unix epoch (1970-01-01T00:00:00Z)
Precision: 1 nanosecond
Range: [-2^63, 2^63-1] ns ≈ [-292 years, +292 years] from 1970 → [1678, 2262]
Operations: subtraction only (timestamps are POINTS, not intervals)
Delta: delta_ns = t2 - t1 (int64 subtraction, result is nanosecond interval)
NOT Q-format: timestamps are ordinal, not real-valued. Q-format would be meaningless.
```

### 128-bit Multiplication Workarounds in NumPy
NumPy does not support int128. For Q32.32 × Q32.32 → Q64.64 → truncate to Q32.32:

**Method 1: Split into 32-bit halves**
```python
# a, b are int64 in Q32.32
a_hi = a >> 32       # upper 32 bits
a_lo = a & 0xFFFFFFFF  # lower 32 bits
b_hi = b >> 32
b_lo = b & 0xFFFFFFFF
# Full product = a_hi*b_hi*2^64 + (a_hi*b_lo + a_lo*b_hi)*2^32 + a_lo*b_lo
# For Q32.32 result, we need bits [32:96] of the 128-bit product
# result = a_hi*b_lo + a_lo*b_hi + (a_lo*b_lo >> 32)
# CAUTION: intermediate terms can overflow int64!
```

**Method 2: Use float64 as intermediate** (LOSSY — use only for validation)
```python
# float64 has 53 bits of mantissa → loses precision for 64-bit ints
result_approx = np.int64((np.float64(a) * np.float64(b)) / (2**32))
```

**Method 3: Use gmpy2 or numpy with object dtype** (SLOW — for shadow validation only)
```python
import gmpy2
result = int(gmpy2.mpz(a) * gmpy2.mpz(b) >> 32)
```

**Method 4: Barrett reduction for division-free reciprocal**
For division by constants (e.g., converting between Q-formats), Barrett reduction
replaces division with multiplication by a pre-computed reciprocal.

## Known Limitations (Anti-Hallucination Protocol)

### Limitation 1: "Zero Allocation" Is Overstated
The previous prompt claimed "zero allocation" for fixed-point operations. The honest
framing is: **Pre-allocated hot path**. All buffers (input ring buffer, output accumulator,
scratch space for 128-bit intermediates) are allocated ONCE at initialization. The hot
path (per-tick processing) does not allocate. But the initialization IS allocation.
Furthermore, Python/NumPy may allocate internally for certain operations (e.g., boolean
indexing creates a copy). The shadow validation path (File 05) exists precisely to
detect when the hot path silently allocates.

### Limitation 2: Saturating Arithmetic Is Not Default
NumPy integer overflow WRAPS (modular arithmetic), not saturates. If Q32.32 price
accumulation overflows, it wraps to a negative number — catastrophic data corruption.
We must IMPLEMENT saturating arithmetic explicitly:
```python
def sat_add(a, b):
    result = a + b  # may overflow!
    # Detect overflow: if a and b have same sign but result has different sign
    overflow = ((a ^ result) & (b ^ result)) < 0
    return np.where(overflow, np.where(a > 0, INT64_MAX, INT64_MIN), result)
```
This adds a branch — which conflicts with the branchless goal (File 04). The SELECTIVE
branchless approach (File 04) applies branchless saturation ONLY on data-dependent paths.

### Limitation 3: Q-Format Conversion Loses Precision
Converting Q16.48 → Q32.32 requires a right shift by 16, discarding 16 bits of precision.
This is INTENTIONAL for price deltas (we don't need femto-dollar precision in the price
accumulator), but the precision loss must be DOCUMENTED and QUANTIFIED.

### Limitation 4: Timestamp Arithmetic Has Subtle Bugs
Subtracting two int64 timestamps gives a nanosecond interval. But:
- Clock jumps (NTP correction, leap seconds) can cause negative intervals.
- Exchange timestamps vs local timestamps have different epochs and clock sources.
- Comparing timestamps from different exchanges requires synchronization correction.

## Search Queries

### Query Block A: Q-Format and Fixed-Point Arithmetic
```
Q1: "Q format" OR "Q-format" OR "Qm.n" AND ("fixed point" OR "fixed-point") AND "arithmetic"
Q2: "fixed point arithmetic" AND ("financial" OR "trading" OR "market data" OR "HFT")
Q3: "fixed point" AND ("NumPy" OR "Python" OR "scientific computing")
Q4: "Q32.32" OR "Q16.16" OR "Q format" AND ("precision" OR "error analysis" OR "rounding")
Q5: "fixed point" AND ("multiplication" OR "128 bit" OR "double width" OR "wide integer")
```

### Query Block B: Overflow, Saturation, and Error Analysis
```
Q6: "saturating arithmetic" OR "saturation arithmetic" AND ("fixed point" OR "integer" OR "overflow")
Q7: "fixed point" AND ("error analysis" OR "error bound" OR "precision analysis" OR "rounding error")
Q8: "overflow detection" AND ("integer arithmetic" OR "fixed point" OR "two's complement")
Q9: "modular arithmetic" VS "saturating arithmetic" AND ("signal processing" OR "financial")
```

### Query Block C: Division-Free Algorithms
```
Q10: "Newton-Raphson reciprocal" OR "division-free" AND ("fixed point" OR "integer")
Q11: "Barrett reduction" AND ("fixed point" OR "division" OR "modular arithmetic")
Q12: "fast division" AND ("fixed point" OR "embedded" OR "FPGA" OR "HFT")
Q13: "Goldschmidt division" OR "SRT division" AND ("fixed point" OR "hardware")
```

### Query Block D: FPGA/ASIC Fixed-Point for HFT
```
Q14: "fixed point" AND ("FPGA" OR "ASIC" OR "hardware accelerator") AND ("trading" OR "HFT" OR "financial")
Q15: "high frequency trading" AND ("FPGA" OR "hardware") AND ("fixed point" OR "precision" OR "arithmetic")
Q16: "network interface" AND ("market data" OR "tick data") AND ("FPGA" OR "hardware parser")
```

### Query Block E: Precision Comparison
```
Q17: "fixed point" VS "floating point" AND ("precision" OR "performance" OR "comparison")
Q18: "float32" VS "float64" VS "fixed point" AND ("financial" OR "scientific")
Q19: "IEEE 754" AND ("fixed point" OR "alternative") AND ("financial" OR "trading")
Q20: "decimal arithmetic" AND ("financial" OR "trading" OR "accounting") AND ("fixed point" OR "exact")
```

### Query Block F: Hybrid Precision Systems
```
Q21: "hybrid precision" OR "mixed precision" AND ("numerical" OR "scientific computing" OR "simulation")
Q22: "variable precision" AND ("data type" OR "representation") AND ("optimization" OR "memory")
Q23: "type promotion" AND ("NumPy" OR "array programming") AND ("overflow" OR "precision")
```

## Key Authors and References

| Author / Source | Contribution |
|---|---|
| Texas Instruments | Q-format documentation (TMS320C6x manuals) |
| ARM Ltd. | CMSIS-DSP fixed-point library documentation |
| Xilinx / AMD | Fixed-point IP cores for FPGA (UG148, PG102) |
| Intel | Intrinsics Guide (saturating arithmetic, wide multiply) |
| NumPy documentation | Integer overflow behavior, dtype promotion rules |
| Higham (2002) | "Accuracy and Stability of Numerical Algorithms" |
| Goldberg (1991) | "What Every Computer Scientist Should Know About Floating-Point" |
| Lyons (2011) | "Understanding Digital Signal Processing" — fixed-point chapters |
| Martin Thompson | Mechanical sympathy, Disruptor pattern (precision in LMAX) |

## Filter Criteria

| Criterion | Value |
|---|---|
| Date range | 1990–2026 |
| Categories | cs.AR, cs.MS, cs.NA, q-fin.CP, q-fin.TR, eess.SP |
| Minimum citations | 20+ for foundational (Higham, Goldberg), 5+ for applied |
| Publication type | Standards docs, peer-reviewed, application notes, library docs |
| Code requirement | Papers with NumPy/C/FPGA code preferred |
| Language | English |

## Expected Deliverables

### Technical Specifications Needed
1. **Error bound for Q32.32 accumulation** — After N additions, what is the maximum
   accumulated rounding error? (Answer: zero for addition, but overflow risk grows.)
2. **Error bound for Q32.32 × Q32.32 → Q32.32 multiplication** — Truncation from
   Q64.64 to Q32.32 introduces error of at most 2^-32 per multiplication.
3. **Overflow probability model** — Given a distribution of price increments, what
   is the probability of Q32.32 overflow after T ticks?
4. **Conversion error table** — For each Q-format pair conversion, quantify the
   precision loss.

### Code Patterns Needed
1. **Saturating add/subtract** in NumPy for int64 (branchless if possible).
2. **128-bit multiply** via 64-bit halves in NumPy (vectorized).
3. **Barrett reduction** for division by constants in NumPy.
4. **Q-format conversion** functions with documented precision loss.
5. **Overflow detection** pattern using XOR sign bits.

## Relevance Test

**How does this serve the Causal Raw Data Engine?**

The engine processes every tick in fixed-point to ensure:
1. **Deterministic replay** — Same input → same output, bit-for-bit. Floating-point
   non-associativity breaks this (a+b+c ≠ a+c+b in general).
2. **Audit trail** — Every value can be exactly reconstructed from its raw int64
   representation. No floating-point ambiguity.
3. **Cross-exchange comparison** — Prices from different exchanges in the same Q-format
   are directly comparable without epsilon tolerance.
4. **FPGA offload readiness** — The same Q-format arithmetic maps directly to FPGA
   implementations for ultra-low-latency processing.

The hybrid approach (Q32.32 + Q48.16 + Q16.48 + int64) optimizes precision per field
rather than using a one-size-fits-all format.

## DOI Verification Protocol

Same 4-step protocol:
1. Search on IEEE Xplore, ACM DL, arXiv, or Google Scholar.
2. Verify DOI at https://doi.org/<DOI>.
3. Cross-check against publisher site + Semantic Scholar.
4. Score: 🟢 HIGH (peer-reviewed/standard doc, 20+ citations), 🟡 MEDIUM (application
   note or library doc with code), 🔴 LOW (blog post, unverified).

## Falsification Criteria

**When would hybrid fixed-point FAIL?**

1. **If prices exceed Q32.32 range** — If a price exceeds $2.147 billion (unlikely for
   stocks, but possible for some bond notional values or cumulative indices), Q32.32
   overflows. Mitigation: monitor maximum value, switch to Q48.16 for extreme instruments.
2. **If 128-bit multiplication is too slow** — The split-into-halves method requires
   4 multiplications and 3 additions per Q32.32 multiply. If this is slower than float64
   multiply on the target hardware, the advantage disappears. Benchmark required.
3. **If NumPy's lack of int128 is a showstopper** — If the hot path requires frequent
   multiplications, and the 64-bit workaround is too slow or too error-prone, then
   fixed-point in NumPy may be impractical. Alternative: use Cython/C extension for
   the multiplication kernel.

## AZ Xülasəsi

Bu axtarış sorğusu tək Q32.32 formatını əvəz edən hibrid sabit nöqtəli hesablamaları
əhatə edir. Mühərrik qiymətlər üçün Q32.32 (int64), həcm üçün Q48.16 (uint64), imzalı
deltalar üçün Q16.48 (int64) və nanosaniyə zaman damğaları üçün sadə int64 istifadə edir.
"Sıfır ayırma" iddiası düzəliş edilərək "əvvəlcədən ayrılmış isti yol" (pre-allocated hot
path) kimi dürüst şəkildə ifadə edilir. Doyma arifmetikası, 128 bitlik aralıq hasil
problemləri (NumPy int128 dəstəkləmir), Barrett azalması ilə bölməsiz alqoritmlər və FPGA
tətbiqləri əsas axtarış mövzularıdır. Hər bir Q-format çevrilməsinin dəqiqlik itkisi
sənədləşdirilməlidir.
