---
tags: [search-prompt, branchless, cpu, prediction, conditional-move, simd, selective]
category: academic-search
module: causal-raw-data-engine-v2
created: 2026-07-11
trust: 🟢 VERIFIED
revision: 2
changelog: "v2 — REPLACES 'all branchless' prompt. SELECTIVE branchless on data-dependent paths only. CMOV can be SLOWER. Profile-guided optimization."
---

# Search Prompt: Selective Branchless Programming & CPU Branch Prediction for Market Data Processing

## Objective

Find literature on CPU branch prediction, conditional execution, branchless programming
patterns, and profile-guided optimization — applied SELECTIVELY to data-dependent paths
in high-frequency market data processing. This REPLACES the previous "all branchless"
framing, which was misleading: not all branches benefit from elimination. Only
DATA-DEPENDENT branches on the hot path justify branchless transformation. Many branches
(loop control, error handling, one-time initialization) are PERFECTLY predicted by modern
CPUs and removing them adds complexity without benefit.

## Why NOT "All Branchless" (Anti-Hallucination Correction)

The previous version of this prompt claimed that the engine should be "all branchless."
This is WRONG for several reasons:

1. **Modern branch predictors are excellent for predictable branches**: The TAGE predictor
   (used in Intel since Nehalem, AMD since Zen) and perceptron predictors achieve 95-99%
   accuracy on typical code. A loop counter branch is predicted correctly 99.99%+ of the
   time. Making it branchless adds code complexity for zero gain.

2. **CMOV is NOT always faster than a branch**: Conditional move (CMOV) eliminates the
   branch but ALWAYS executes both paths and discards one. If the "false" path involves
   an expensive computation (e.g., a cache miss, a complex expression), CMOV is SLOWER
   than a correctly-predicted branch that skips the computation entirely.

3. **Branchless code is harder to read and debug**: Transformations like `x = (x < 0) ?
   -x : x` → `x = (x ^ (x >> 63)) - (x >> 63)` are correct but opaque. On non-critical
   paths, readability trumps micro-optimization.

4. **NumPy vectorized operations ARE already branchless at the C level**: When you write
   `np.where(condition, a, b)`, NumPy's C implementation uses SIMD mask registers (AVX-512
   or NEON) — this IS branchless. The Python-level code has a "branch" (the where call),
   but the actual computation is vectorized and branchless.

5. **Compilers do branchless optimization automatically**: GCC and Clang will convert
   simple conditionals to CMOV when `-O2` or `-O3` is set. Manual branchless code can
   actually PREVENT the compiler from optimizing further.

## Corrected Framework: Selective Branchless on Data-Dependent Paths

### Decision Tree: When to Go Branchless

```
Is this branch on the HOT PATH (executed per-tick)?
├─ NO → Keep the branch. Readability wins. Branch predictor handles it.
└─ YES → Is the branch DATA-DEPENDENT (outcome depends on input data)?
    ├─ NO (loop counter, error check) → Keep the branch. It's predictable.
    └─ YES → What's the branch misprediction rate?
        ├─ < 5% → Keep the branch. Predictor handles it well.
        ├─ 5-50% → CONVERT to branchless. This is where mispredictions kill.
        └─ > 50% → INVERT the branch condition (predict the common case).
                    Consider branchless if inversion isn't sufficient.
```

### Categories of Branches in the Engine

| Branch Type | Hot Path? | Data-Dependent? | Mispredict Rate | Action |
|---|---|---|---|---|
| Tick processing loop | Yes | No (always N ticks) | ~0% | Keep branch |
| Ring buffer wrap-around | Yes | No (periodic) | ~0% | Keep branch |
| Price > threshold filter | Yes | Yes | 5-50% | **Branchless** |
| Order type dispatch | Yes | Yes | ~50% | **Branchless** (jump table) |
| Error/exception handling | No | N/A | N/A | Keep branch |
| Regime state machine | Yes | Yes | 10-30% | **Selective branchless** |
| Overflow saturation check | Yes | Yes (rarely true) | ~1% | Keep branch (predict not-taken) |
| Shadow validation trigger | No | No (async) | ~0% | Keep branch |

## Technical Details: Branch Cost and Alternatives

### Branch Misprediction Cost
- **Misprediction penalty**: 15-20 cycles on modern x86 (pipeline flush + re-fetch)
- **At 4 GHz**: 15 cycles = 3.75 nanoseconds per misprediction
- **For 1M ticks/sec with 50% mispredict rate**: 500K mispredicts × 3.75ns = 1.875ms/sec
  wasted = 0.1875% of CPU time. This is SIGNIFICANT on a latency-sensitive hot path.
- **For 10M ticks/sec**: 18.75ms/sec = 1.875% of CPU time. Becomes critical.

### Branch Elimination Techniques

**1. Conditional Move (CMOV)**
```c
// Branch version (1 mispredict penalty when wrong):
if (a > b) result = a; else result = b;

// CMOV version (no branch, but ALWAYS evaluates both a and b):
result = (a > b) ? a : b;  // Compiler emits CMOV at -O2
```
**When CMOV is SLOWER**: If `a` or `b` involves a memory load that might cache-miss,
CMOV forces BOTH loads to execute. A correctly-predicted branch only loads the taken path.

**2. Arithmetic Branchless (bit tricks)**
```c
// Absolute value without branch:
int64_t abs_branchless(int64_t x) {
    int64_t mask = x >> 63;  // all 1s if negative, all 0s if positive
    return (x ^ mask) - mask;
}

// Min/Max without branch:
int64_t min_branchless(int64_t a, int64_t b) {
    int64_t diff = a - b;
    int64_t mask = diff >> 63;
    return a - (diff & mask);  // if a < b, subtract the difference
}
```

**3. SIMD Mask Registers (AVX-512)**
```c
// Process 8 prices at once, applying threshold filter branchlessly
__m512i prices = _mm512_load_si512(price_ptr);
__m512i threshold = _mm512_set1_epi64(THRESHOLD_Q32_32);
__mmask8 mask = _mm512_cmpgt_epi64_mask(prices, threshold);
__m512i result = _mm512_mask_blend_epi64(mask, zero_vec, prices);
```

**4. Jump Tables (for multi-way dispatch)**
```c
// Instead of if/else chain for order type:
switch (order_type) {  // Compiler generates jump table
    case MARKET: process_market(); break;
    case LIMIT:  process_limit();  break;
    case STOP:   process_stop();   break;
    // ...
}
```
Jump tables are NOT branchless — they use an indirect jump. But the branch predictor
handles indirect jumps via BTB (Branch Target Buffer). If order types are uniformly
distributed (50% mispredict for simple if/else), the jump table has ~0% mispredict
because each case is a separate target that the BTB learns independently.

**5. Profile-Guided Optimization**
```c
// Tell the compiler which branch is likely:
if (__builtin_expect(error_condition, 0)) {  // "unlikely"
    handle_error();  // Placed far from hot path → better I-cache
}
process_tick();  // Always in the straight-line path
```
This is NOT branchless — it's branch OPTIMIZATION. The branch remains, but the
compiler arranges code so the likely path is sequential (no jump) and the unlikely
path is out-of-line.

## Known Limitations (Anti-Hallucination Protocol)

### Limitation 1: Branch Prediction Is CPU-Specific
Branch predictor behavior varies across CPU generations:
- **Intel Skylake/Zen2**: TAGE predictor, ~95% accuracy on SPEC benchmarks
- **Intel Alder Lake/Zen4**: Enhanced TAGE + perceptron, ~97% accuracy
- **Apple M1/M2**: Wide decode + large BTB, different characteristics
- **ARM Neoverse**: Server ARM, different predictor design

Conclusions drawn on one CPU may not transfer to another. ALWAYS profile on the
target hardware.

### Limitation 2: NumPy Abstracts Away Branch Control
In Python/NumPy, you don't directly control branching. `np.where()` is vectorized
(branchless at SIMD level), but Python-level `if` statements are NOT. The hot path
must be implemented in C/Cython/Numba to have meaningful branch control. Pure Python
branchless tricks are mostly irrelevant because CPython's interpreter overhead
dominates.

### Limitation 3: Branchless Code Can Defeat Speculative Execution
Modern CPUs speculatively execute instructions past branches. Branchless code using
data-dependent masks may PREVENT useful speculation. In some cases, a branch that
the predictor gets right allows the CPU to speculatively execute 20+ instructions
ahead, which is FASTER than branchless code that serializes dependencies.

### Limitation 4: Security Considerations (Spectre)
Branchless code is sometimes recommended to prevent Spectre-style speculative execution
attacks. However, financial data processing typically runs in a trusted environment
(no untrusted input from network directly to hot path). Spectre mitigation is NOT
a primary concern for the engine's internal hot path.

## Search Queries

### Query Block A: Branch Prediction Models
```
Q1: "branch prediction" AND ("TAGE" OR "perceptron" OR "tournament") AND ("processor" OR "CPU")
Q2: "branch misprediction" AND ("penalty" OR "cost" OR "latency" OR "pipeline")
Q3: "branch target buffer" AND ("indirect jump" OR "virtual dispatch" OR "switch statement")
Q4: "branch prediction" AND ("high frequency" OR "low latency" OR "trading" OR "financial")
Q5: "modern branch predictor" AND ("accuracy" OR "benchmark" OR "SPEC") AND ("Skylake" OR "Zen" OR "ARM")
```

### Query Block B: Branchless Programming Techniques
```
Q6: "branchless programming" OR "branch free" OR "branchless code" AND ("algorithm" OR "technique" OR "pattern")
Q7: "conditional move" AND ("CMOV" OR "branchless") AND ("performance" OR "comparison" OR "slower")
Q8: "bit manipulation" AND ("branchless" OR "branch free") AND ("min" OR "max" OR "abs" OR "clamp")
Q9: "data dependent branch" AND ("elimination" OR "removal" OR "branchless")
Q10: "branchless" AND ("sorting" OR "searching" OR "hashing" OR "parsing")
```

### Query Block C: SIMD and Vectorized Branchless Patterns
```
Q11: "SIMD" AND ("branchless" OR "mask" OR "predicated") AND ("AVX" OR "SSE" OR "NEON" OR "AVX-512")
Q12: "vectorized" AND ("branch" OR "conditional") AND ("NumPy" OR "array" OR "SIMD")
Q13: "mask register" AND ("AVX-512" OR "writemask" OR "opmask") AND ("branchless" OR "predicated")
Q14: "auto-vectorization" AND ("branch" OR "conditional" OR "loop") AND ("compiler" OR "GCC" OR "Clang")
```

### Query Block D: Profile-Guided Optimization
```
Q15: "profile guided optimization" OR "PGO" AND ("branch" OR "layout" OR "hot path")
Q16: "__builtin_expect" OR "likely" OR "unlikely" AND ("branch" OR "prediction hint" OR "code layout")
Q17: "feedback directed optimization" OR "FDO" AND ("performance" OR "branch" OR "cache")
Q18: "code layout optimization" AND ("branch" OR "I-cache" OR "instruction cache")
```

### Query Block E: HFT and Low-Latency Specific
```
Q19: "low latency" AND ("branch" OR "branchless" OR "branch prediction") AND ("trading" OR "HFT" OR "financial")
Q20: "mechanical sympathy" AND ("branch" OR "CPU" OR "cache" OR "pipeline")
Q21: "lock free" AND ("branch" OR "CAS" OR "compare and swap") AND ("performance" OR "latency")
Q22: "market data" AND ("parsing" OR "decoding") AND ("branchless" OR "vectorized" OR "SIMD")
```

### Query Block F: Compiler Intrinsics and Optimization
```
Q23: "compiler intrinsic" AND ("branchless" OR "conditional" OR "select") AND ("Intel" OR "ARM" OR "x86")
Q24: "loop unrolling" AND ("branch" OR "conditional") AND ("optimization" OR "performance")
Q25: "strength reduction" AND ("branch" OR "conditional" OR "comparison") AND ("compiler optimization")
```

## Key Authors and References

| Author / Source | Contribution |
|---|---|
| André Seznec | TAGE branch predictor (used in Intel, AMD) |
| Daniel Jimenez | Perceptron branch predictor |
| Agner Fog | x86 optimization manuals (branch timing, pipeline analysis) |
| Chandler Carruth | CppCon talks on branch prediction, optimization |
| Martin Thompson | Mechanical sympathy, LMAX Disruptor (branchless ring buffer) |
| Travis Downs | Performance analysis blog (branch prediction deep dives) |
| Daniel Lemire | Branchless parsing, SIMD techniques, fast random numbers |
| Fabian Giesen | Branchless programming (ryu, fpzip) |
| Intel Corporation | Optimization Reference Manual (branch prediction chapters) |
| ARM Limited | Cortex-A72/A78/Neoverse Software Optimization Guide |
| NumPy developers | `np.where`, `np.select` — vectorized conditional patterns |

## Filter Criteria

| Criterion | Value |
|---|---|
| Date range | 2000–2026 |
| Categories | cs.AR, cs.PF, cs.MS, q-fin.TR, q-fin.CP |
| Minimum citations | 30+ for foundational (TAGE, perceptron), 5+ for applied |
| Publication type | Peer-reviewed, conference papers (MICRO, HPCA, ISCA, CGO), tech reports |
| Must include | At least 2 papers showing CMOV is SLOWER than branches |
| Language | English |

## Expected Deliverables

### Quantitative Data Needed
1. **Branch misprediction penalty** for Intel Skylake, Ice Lake, Alder Lake, and
   AMD Zen2/Zen3/Zen4 (in cycles and nanoseconds).
2. **Branch prediction accuracy** for typical market data processing workloads
   (per-tick processing, order matching, price filtering).
3. **CMOV vs branch performance comparison** on real benchmarks showing cases
   where CMOV is slower.
4. **SIMD mask register throughput** for AVX-512 vs AVX2 vs scalar on branchless
   selection operations.

### Code Patterns Needed
1. **Branchless saturating arithmetic** for Q-format (see File 03).
2. **Branchless ring buffer index update** (masking instead of modulo).
3. **Branchless order type dispatch** (jump table or computed goto).
4. **Branchless price threshold filter** (SIMD mask).
5. **Profile-guided branch layout** for the per-tick hot path.

## Relevance Test

**How does this serve the Causal Raw Data Engine?**

The engine processes 1-10 million ticks per second. At this rate:
- A 50% mispredicted branch costs ~18.75ms/sec at 10M ticks (1.875% CPU).
- A branchless SIMD filter can process 8 prices per cycle → 32 GHz effective throughput
  on a 4 GHz 8-wide AVX-512 core = 32 billion ops/sec.
- Selective application means we only pay the complexity cost WHERE it matters:
  data-dependent branches on the hot path with high misprediction rates.

The shadow validation path (File 05) does NOT need branchless optimization — it runs
asynchronously and is not latency-sensitive.

## DOI Verification Protocol

Same 4-step protocol:
1. Search on IEEE Xplore, ACM DL, or Google Scholar.
2. Verify DOI at https://doi.org/<DOI>.
3. Cross-check against 2+ sources.
4. Score: 🟢 HIGH (top-tier conference: MICRO, HPCA, ISCA, CGO), 🟡 MEDIUM (workshop
   paper or tech report with benchmarks), 🔴 LOW (blog post, unverified claims).

## Falsification Criteria

**When would selective branchless FAIL?**

1. **If branch prediction is >99% accurate on our workload**: Then misprediction cost
   is < 0.02% CPU time, and branchless transformation is premature optimization.
   Test: run `perf stat -e branch-misses` on the engine. If branch-miss rate < 1%,
   stop optimizing branches.
2. **If NumPy/Cython overhead dominates**: If the Python interpreter overhead is 90%
   of per-tick time, branchless tricks in C save at most 10% of the remaining 10%.
   The optimization target is wrong. Test: profile with `perf record`.
3. **If the hot path has too few data-dependent branches**: If the hot path is mostly
   straight-line arithmetic (Q-format operations), there are few branches to eliminate.
   The "selective branchless" framework has nothing to select.

## AZ Xülasəsi

Bu axtarış sorğusu "tamamilə budaqsız" (all branchless) yanaşmasını əvəz edərək, yalnız
məlumatdan asılı budaqlarda seçimli budaqsız proqramlaşdırmanı tövsiyə edir. Müasir CPU
budaq proqnozlaşdırıcıları (TAGE, perseptron) proqnozlaşdırıla bilən budaqları 95-99%
dəqiqliklə idarə edir — onları budaqsız etmək lazımsız mürəkkəblik əlavə edir. Şərti
yerdəyişmə (CMOV) bəzi hallarda budaqdan YAVAŞDIR, çünki hər iki yolu məcburi hesablayır.
NumPy vektorlaşdırılmış əməliyyatları C səviyyəsində onsuz da budaqsızdır (SIMD mask
registrləri). Profilə əsaslanan optimallaşdırma (__builtin_expect) və yalnız isti yolda
işlək budaqlar hədəflənir.
