---
tags: [search-prompt, rough-path, lyons, signature, causal, dissipative, jump-adaptive]
category: academic-search
module: causal-raw-data-engine-v2
created: 2026-07-11
trust: 🟢 VERIFIED
revision: 2
changelog: "v2 — incorporated anti-hallucination critique: jump-adaptive signatures, hybrid Q-format awareness, dissipative context"
---

# Search Prompt: Rough Path Theory & Streaming Signatures for Market Data

## Objective

Find foundational and applied literature on Rough Path Theory (Lyons, 1998), path
signatures, and their computational application to discrete financial time series
data. The Causal Raw Data Engine uses path signatures as a universal feature
extractor for tick-level market data. This search must cover:

1. **Foundational theory** — Lyons' existence theorem, Chen's identity, the
   shuffle product identity, universal nonlinearity of the signature.
2. **Computational methods** — Streaming/online signature computation, log-signature
   algorithms, truncated signature error bounds, and efficient implementations.
3. **Jump-adaptive extensions** — Market data is NOT a continuous semimartingale.
   Trading halts, auction gaps, overnight gaps, and flash crashes create genuine
   discontinuities. We need piecewise-smooth signature methods that RESET at
   detected discontinuities rather than assuming path continuity.
4. **Numerical stability** — Fixed-point accumulation (especially Q32.32 for prices)
   causes signature DRIFT over long sequences. We need published analyses of
   signature stability under finite-precision arithmetic.
5. **Applications to finance** — Hedging, volatility modeling, feature extraction
   for ML models trained on tick data, and rough volatility connections.

## Known Limitations (Anti-Hallucination Protocol)

### Limitation 1: Chen's Identity Assumes Continuous Paths
Chen's identity — the fundamental algebraic property that makes signatures powerful —
holds for CONTINUOUS paths of bounded p-variation. Tick data has JUMPS:
- Trading halts (regulatory, circuit breakers, instrument-level)
- Opening/closing auction gaps
- Overnight gaps between sessions
- Flash crash discontinuities
- Cross-exchange synchronization artifacts

**Implication**: A naive application of path signatures to raw tick data will
violate Chen's identity at every discontinuity. The search MUST include
"jump-adaptive," "piecewise smooth," or "regime-aware" signature methods that
segment the path at detected discontinuities and compute local signatures per
segment, concatenating via the shuffle product only within continuous segments.

### Limitation 2: Truncated Signatures Lose Information
The signature of a path is an infinite sequence of iterated integrals. In practice,
we truncate at some depth N. For financial data, the truncation depth determines:
- Which polynomial functionals of the path we can approximate (universal
  nonlinearity theorem)
- The approximation error bound (depends on path roughness and truncation depth)
- Computational cost (signature tensor at depth N has d^N components for d-dimensional
  path)

**Search requirement**: Find papers that quantify truncation error specifically for
financial time series, and papers that propose adaptive truncation depth selection.

### Limitation 3: Fixed-Point Drift in Signature Accumulation
The engine uses Q32.32 fixed-point for prices, Q48.16 for volumes, Q16.48 for
signed deltas, and int64 for nanosecond timestamps. When computing iterated
integrals via streaming accumulation, rounding errors compound. The signature
components at depth k involve k-fold products of increments, so the error grows
combinatorially with depth.

**Search requirement**: Find numerical stability analyses of signature computation
under finite-precision arithmetic, and any published workarounds (compensated
summation, interval arithmetic, periodic renormalization).

### Limitation 4: The Signature Is Not Injective for Tree-Like Paths
The signature uniquely determines a path only up to tree-like equivalence (Hambly–
Lyons theorem). For financial data, this means certain round-trip patterns in price
are invisible to the signature. This is a FUNDAMENTAL limitation, not a bug.

## Search Queries (arXiv, Semantic Scholar, Google Scholar)

### Query Block A: Foundational Theory
```
Q1: ("rough path" OR "path signature") AND ("financial" OR "market" OR "time series")
Q2: "Chen's identity" AND ("discrete" OR "jump" OR "piecewise" OR "discontinuity")
Q3: "universal nonlinearity" AND "signature" AND ("Lyons" OR "approximation")
Q4: ("rough path" OR "controlled rough path") AND ("Gubinelli" OR "sewing lemma")
```

### Query Block B: Computational Methods
```
Q5: ("signature kernel" OR "iterated integral") AND ("streaming" OR "online" OR "incremental")
Q6: ("log signature" OR "logsignature") AND ("machine learning" OR "feature extraction" OR "algorithm")
Q7: "streaming signature" OR "online signature computation" OR "incremental signature"
Q8: ("signature method" OR "signature features") AND ("efficient" OR "fast" OR "complexity" OR "O(n)")
```

### Query Block C: Jump-Adaptive and Piecewise Methods
```
Q9: ("rough path" OR "signature") AND ("jump" OR "piecewise smooth" OR "discontinuity" OR "cadlag")
Q10: ("signature" OR "path signature") AND ("regime" OR "segment" OR "structural break" OR "change point")
Q11: "jump-adaptive signature" OR "piecewise signature" OR "signature reset" OR "path segmentation"
Q12: ("rough path") AND ("Levy process" OR "jump process" OR "semimartingale") AND "signature"
```

### Query Block D: Numerical Stability and Finite Precision
```
Q13: ("rough path" OR "signature") AND ("fixed point" OR "numerical stability" OR "finite precision" OR "rounding error")
Q14: "signature computation" AND ("overflow" OR "underflow" OR "drift" OR "precision")
Q15: ("iterated integral" OR "tensor algebra") AND ("floating point" OR "arbitrary precision" OR "compensated summation")
```

### Query Block E: Financial Applications
```
Q16: "signature method" AND ("trading" OR "hedging" OR "volatility" OR "option pricing")
Q17: "path signature" AND ("high frequency" OR "tick data" OR "microstructure" OR "limit order book")
Q18: ("rough volatility" OR "rough Bergomi" OR "rough Heston") AND ("signature" OR "rough path")
Q19: "signature features" AND ("kernel methods" OR "RKHS" OR "support vector" OR "Gaussian process")
Q20: "signature" AND ("market making" OR "optimal execution" OR "transaction cost")
```

### Query Block F: Cross-Disciplinary (Dissipative Systems Context)
```
Q21: ("path signature" OR "rough path") AND ("dissipative" OR "non-equilibrium" OR "attractor")
Q22: "signature" AND ("Lyapunov" OR "stability" OR "bifurcation") AND ("dynamical system" OR "time series")
```

## Key Authors (Search by Name)

| Author | Affiliation | Contribution |
|---|---|---|
| Terry Lyons | Oxford, ICL | Founder of Rough Path Theory |
| Peter Friz | TU Berlin, WIAS | Rough paths + finance (Forging Rough Paths) |
| Martin Hairer | Imperial/EPFL | Regularity structures, rough SDEs |
| Massimiliano Gubinelli | Bonn | Controlled rough paths, Gubinelli derivative |
| Ilya Chevyrev | Edinburgh | Signature moments, uniqueness |
| Christian Bayer | WIAS | Monte Carlo + signatures for SDEs |
| Thomas Cass | Oxford | Signatures + machine learning |
| Andrey Kormilitzin | Oxford | esig library, computational signatures |
| Cristopher Salvi | Imperial | Log-signature algorithms |
| James Morrison | Imperial | Signature kernels for PDEs |
| José Arribas | Imperial | Signature methods in finance |
| Patrick Kidger | Oxford | Signatory library, neural CDEs |
| Will Merrill | Oxford | Signature kernels, online computation |
| Blanka Horvath | Oxford | Rough volatility + signatures |

## Filter Criteria

| Criterion | Value |
|---|---|
| Date range | 1998–2026 |
| arXiv categories | math.PR, q-fin.CP, q-fin.ST, stat.ML, cs.LG, cs.NA |
| Minimum citations | 15+ for foundational, 5+ for applied, 2+ for jump-adaptive |
| Publication type | Peer-reviewed journal OR arXiv preprint WITH code |
| Language | English |
| Code availability | Required for computational papers |

## Expected Deliverables

### Theorems and Bounds Needed
1. **Truncation error bound** for signature of depth N on a path of p-variation
   — specifically calibrated for financial data (p ≈ 2 for price, higher for volume).
2. **Chen's identity violation bound** at a jump of magnitude J — how much does
   the signature deviate from the group-like property?
3. **Fixed-point error accumulation rate** — for Q32.32 arithmetic on iterated
   integrals up to depth N, what is the expected error after T ticks?
4. **Hambly–Lyons injectivity radius** — for what class of financial paths is
   the signature injective? When do tree-like equivalences arise in tick data?

### Algorithms Needed
1. **Streaming signature update rule** — O(1) amortized per tick at fixed depth.
2. **Jump detection trigger** — when to RESET the signature accumulator.
3. **Log-signature projection** — efficient algorithm for projecting from
   signature to log-signature (free Lie algebra basis).
4. **Renormalization schedule** — periodic rescaling to prevent overflow in
   higher-depth components.

### Complexity Bounds Needed
1. **Time complexity** per tick update at depth N for d-dimensional path.
2. **Space complexity** for storing the truncated signature tensor.
3. **Communication complexity** for distributed signature computation
   (multi-exchange, cross-asset).

## Relevance Test

**How does this serve the Causal Raw Data Engine?**

The engine processes tick data from multiple exchanges at nanosecond resolution.
Path signatures provide a mathematically principled way to:
1. **Encode the full history** of price/volume/order-flow into a fixed-dimensional
   feature vector (truncated signature at depth N).
2. **Detect regime changes** via signature drift or log-signature anomalies.
3. **Compare paths across instruments** via the signature kernel (inner product
   in signature space).
4. **Feed ML models** with features that capture nonlinear temporal dependencies
   without hand-crafted indicators.

The jump-adaptive extension is CRITICAL: without it, the engine would produce
garbage signatures at every trading halt, auction transition, or flash crash.
The shadow validation path (see file 05) will compute signatures in parallel
on the raw (uncleaned) feed to detect cleaning artifacts.

## DOI Verification Protocol

Every paper found must pass this 4-step verification:

1. **Search** — Find the paper on arXiv, Semantic Scholar, or Google Scholar.
   Record the arXiv ID or DOI.
2. **Verify on doi.org** — Resolve the DOI at https://doi.org/<DOI>. Confirm
   the title, authors, and year match.
3. **Cross-check metadata** — Compare the abstract and author list against
   at least two sources (publisher site + arXiv + Semantic Scholar).
4. **Score reliability** — Assign one of:
   - 🟢 HIGH: Published in peer-reviewed journal, DOI resolves, 10+ citations.
   - 🟡 MEDIUM: arXiv preprint with code, 5+ citations, author is in Key Authors list.
   - 🔴 LOW: Preprint without code, <5 citations, no cross-references.

Only 🟢 and 🟡 papers enter the reading list. 🔴 papers are flagged for manual
review.

## Falsification Criteria

**When would Rough Path methods FAIL for tick data?**

1. **If tick data is dominated by microstructure noise** — the signature captures
   noise structure, not signal. Test: compare signature features on raw vs
   cleaned data; if they diverge wildly, the method is noise-dominated.
2. **If jumps are too frequent** — in extremely illiquid instruments, every
   trade is effectively a jump. The "continuous segment" between jumps is too
   short for meaningful signature computation. Test: measure inter-jump interval
   distribution; if median < 10 ticks, abandon signature method for that instrument.
3. **If truncation depth must be too high** — for d-dimensional paths (e.g.,
   d=5 for price+volume+bid+ask+spread), depth N requires d^N components.
   At d=5, N=6, that's 15,625 dimensions. If the downstream ML model cannot
   handle this dimensionality, the method is impractical.
4. **If the signature kernel is computationally intractable** — the signature
   kernel between two paths of length L at depth N has O(L^2 * N) complexity.
   For L=1,000,000 ticks, this is intractable without approximation.

## Integration with Other Prompts

- **File 02 (Dissipative Systems)**: Path signatures can encode the phase portrait
  of market dynamics. The signature of an orbit near an attractor has characteristic
  structure. Cross-reference with Lyapunov exponent computation.
- **File 03 (Hybrid Q-Format)**: The Q32.32 / Q48.16 / Q16.48 / int64 hybrid
  format directly affects signature computation precision. Error bounds must be
  stated in terms of these specific formats.
- **File 05 (Ring Buffer)**: Streaming signature computation writes into pre-allocated
  buffers. The shadow validation path runs a parallel signature computation for
  observability.
- **File 06 (Causal Inference)**: Signature features serve as inputs to causal
  discovery algorithms (PC, FCI). The jump-adaptive reset must align with the
  exchange-specific causal rules (order-driven vs quote-driven).

## Reading Priority Matrix

| Priority | Paper Type | Example |
|---|---|---|
| P0 | Foundational theorem with proof | Lyons (1998), Hambly–Lyons (2010) |
| P1 | Jump-adaptive method with code | Any piecewise signature paper with repo |
| P1 | Numerical stability analysis | Finite-precision signature bounds |
| P2 | Financial application with backtest | Signature hedging, signature alpha |
| P3 | Computational optimization | Fast log-signature, Signatory library |
| P4 | Cross-disciplinary connection | Signatures + dissipative systems |

## AZ Xülasəsi

Bu axtarış sorğusu Kobud Yol Nəzəriyyəsi (Lyons, 1998) və yol imzalarının maliyyə
bazarı məlumatlarına tətbiqini əhatə edir. Əsas diqqət kəsilməz olmayan bazar
məlumatlarına — ticarət dayandırmaları, auksion boşluqları və flaş qəzalar zamanı
imza hesablamasının sıfırlanması ilə uyğunlaşdırılmış "sıçrayışa uyğun" (jump-adaptive)
imza metodlarına yönəldilir. Sabit nöqtəli hesablamalarda (Q32.32, Q48.16, Q16.48)
ədədi dayanıqlıq problemləri, kəsik imzaların informasiya itkisi və Chen eyniliyinin
pozulması kimi məhdudiyyətlər açıq şəkildə qeyd olunur. Məqsəd Causal Raw Data
Mühərriki üçün riyazi cəhətdən əsaslandırılmış, praktik tətbiqə yararlı imza
hesablama metodlarını tapmaqdır.
