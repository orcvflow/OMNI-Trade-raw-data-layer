---
tags: [search-prompt, causal-inference, exchange-specific, granger, transfer-entropy, pc-algorithm, volume-clock]
category: academic-search
module: causal-raw-data-engine-v2
created: 2026-07-11
trust: 🟢 VERIFIED
revision: 2
changelog: "v2 — REPLACES generic causal inference prompt. Exchange-SPECIFIC causal rules. Volume=0 does NOT mean price frozen in quote-driven markets. Variable-lag Granger."
---

# Search Prompt: Exchange-Specific Causal Inference for Market Microstructure

## Objective

Find literature on causal inference methods applied to financial market data, with
EMPHASIS on exchange-specific causal rules. The previous version of this prompt assumed
a universal causal rule: "volume=0 implies price is frozen." This is WRONG as a general
statement. The causal relationship between volume and price depends on the MARKET
MICROSTRUCTURE of each exchange:

| Market Type | Price Formation | Volume=0 Implication |
|---|---|---|
| **Order-driven** (NYSE, NASDAQ, most equity exchanges) | Price = last executed trade price | Price is FROZEN at last trade (no new trades → no new price) |
| **Quote-driven** (FX spot, OTC bonds, many crypto exchanges) | Price = midpoint of best bid/ask quotes | Price CAN CHANGE without volume (market makers update quotes) |
| **Auction** (opening/closing auctions, some bond markets) | Price = clearing price from batch auction | Price is UNDEFINED between auctions; volume is batch, not continuous |
| **Hybrid** (most modern exchanges) | Mix of order-driven + auction phases | Causal rules CHANGE depending on current phase |

This distinction is CRITICAL for the Causal Raw Data Engine: applying order-driven
causal rules to quote-driven data produces systematically wrong causal inferences.

## Exchange-Specific Causal Rules

### Rule Set 1: Order-Driven Markets (Continuous Auction)

**Applicable exchanges**: NYSE, NASDAQ, CBOE, most equity and equity-options exchanges.

**Causal rules**:
1. **Volume causes price change**: A trade executes at a new price only when a market
   order (or marketable limit order) crosses the spread. No volume → no trade → price
   (last sale) is frozen. ✅ "Volume=0 → price frozen" is VALID here.
2. **Order flow imbalance predicts direction**: More buy volume than sell volume at
   the ask → upward price pressure. This is a causal mechanism (demand exceeding supply
   at current price).
3. **Spread causes transaction cost**: The bid-ask spread is a CAUSAL determinant of
   round-trip transaction cost. Wider spread → higher cost, ceteris paribus.
4. **Depth causes resilience**: Order book depth (volume at each price level) causally
   determines how much a large order moves the price (market impact).

**Causal graph (simplified)**:
```
Order Flow ──► Volume ──► Price Change
     │                        ▲
     │    Spread ─────────────┘
     │
     └──► Order Book Depth ──► Market Impact ──► Price Change
```

### Rule Set 2: Quote-Driven Markets (Dealer Markets)

**Applicable exchanges**: FX spot (Reuters, EBS), OTC corporate bonds, many crypto
exchanges (especially DEX), wholesale fixed income.

**Causal rules**:
1. **Price CAN change without volume**: Market makers continuously update their bid and
   ask quotes in response to information, even when no trades occur. The mid-price moves
   without any volume. ❌ "Volume=0 → price frozen" is INVALID here.
2. **Information causes quote revision**: News, macro data, and correlated asset movements
   cause market makers to revise quotes. This is a causal mechanism independent of volume.
3. **Quote updates CAUSE future volume**: When a market maker narrows the spread or moves
   the mid-price, this attracts order flow. Quote change → volume, not the other way around.
4. **Inventory causes quote adjustment**: Market makers adjust quotes to manage inventory
   risk. Large long inventory → lower bid (to discourage more buying). This is a causal
   mechanism invisible in trade data alone.

**Causal graph (simplified)**:
```
Information ──► Quote Revision ──► Price Change
                     │                   ▲
                     └──► Volume ────────┘
                               │
  Inventory ──► Quote Revision  │
                                └──► Inventory Change
```

### Rule Set 3: Auction Markets (Batch Clearing)

**Applicable exchanges**: Opening/closing auctions on most exchanges, some bond markets,
electricity markets (PJM, Nord Pool).

**Causal rules**:
1. **Price is undefined between auctions**: There is no continuous price. The causal
   concept of "price change" is meaningless between auction events.
2. **Aggregate demand/supply CAUSES clearing price**: The auction clearing price is
   determined by the intersection of aggregate demand and supply curves. This is a
   batch causal mechanism, not a continuous one.
3. **Pre-auction indications are not causal**: Indications of interest (IOIs) submitted
   before the auction may be revised or cancelled. They do not CAUSE the clearing price;
   only final orders do.

### Rule Set 4: Hybrid Markets (Phase-Dependent)

**Applicable exchanges**: Most modern exchanges that have continuous trading + opening/
closing auctions + halt/auction phases.

**Causal rules**:
1. **Causal structure CHANGES by phase**: During continuous trading, order-driven rules
   apply. During auctions, auction rules apply. During halts, NO causal rules apply
   (price is administratively frozen, not causally frozen).
2. **Phase transitions are causal events**: The transition from auction to continuous
   trading is itself a causal event that affects subsequent price dynamics (opening
   auction sets the initial price for continuous trading).
3. **Cross-phase causality**: Order flow during the pre-open auction phase causally
   affects the opening price, which causally affects the first minutes of continuous
   trading.

## Known Limitations (Anti-Hallucination Protocol)

### Limitation 1: Granger Causality Is Not True Causality
Granger causality tests whether past values of X improve prediction of Y beyond what
past values of Y alone provide. This is PREDICTIVE causality, not structural causality.
- Granger causality can be confounded by common causes (omitted variables).
- Granger causality assumes stationarity (problematic for regime-switching markets).
- Granger causality is sensitive to lag selection (wrong lag → wrong conclusion).
- **Variable-lag Granger causality** (Kim et al.) allows the causal lag to vary, which
  is more appropriate for markets where information propagation speed varies.

### Limitation 2: Transfer Entropy Requires Large Samples
Transfer entropy (Schreiber, 2000) is a non-parametric measure of directed information
flow. It does not assume linearity (unlike Granger causality). However:
- It requires LARGE samples for reliable estimation (10,000+ observations).
- It is sensitive to the choice of bin size (for discretized estimation) or kernel
  bandwidth (for kernel-based estimation).
- For high-frequency tick data, the sample size is large, but the data is highly
  autocorrelated, reducing the effective sample size.

### Limitation 3: PC/FCI Algorithms Assume Faithfulness
The PC algorithm (Spirtes, Glymour, Scheines) and FCI algorithm (for latent confounders)
for causal discovery assume:
- **Causal Markov condition**: Each variable is independent of its non-effects given
  its direct causes.
- **Faithfulness**: The observed independencies are EXACTLY those implied by the causal
  graph. No "accidental" cancellations.
- **No feedback (for PC)**: The causal graph is a DAG. Markets have feedback loops
  (price affects order flow, which affects price). FCI handles some feedback, but not
  all.

### Limitation 4: Volume Clocks vs Time Clocks Change Causal Structure
Using time clocks (fixed intervals: 1 second, 1 minute) vs volume clocks (fixed volume
per bar: every 1000 shares) changes the causal structure of the data:
- **Time clocks**: Causality is measured in wall-clock time. A "cause" at time t affects
  "effect" at time t+k seconds. But during low-volume periods, k seconds may contain
  zero trades, making the causal relationship vacuous.
- **Volume clocks**: Causality is measured in event time. A "cause" at volume-bar n
  affects "effect" at volume-bar n+k. This aligns with market activity, not wall-clock
  time. Causal relationships are more stable in volume time (Easley, Lopez de Prado,
  O'Hara, 2012).

### Limitation 5: Tick Data Cleaning Affects Causal Validity
Raw tick data contains errors (stale quotes, erroneous trades, out-of-sequence messages).
Cleaning this data (removing outliers, correcting timestamps) can INTRODUCE or REMOVE
causal relationships:
- Removing an outlier trade may remove a genuine causal event (flash crash).
- Correcting a timestamp may create a false causal ordering.
- The causal inference must be run on BOTH raw and cleaned data, with discrepancies
  flagged. The shadow validation path (File 05) runs causal analysis on raw data to
  detect cleaning-induced causal artifacts.

## Search Queries

### Query Block A: Exchange-Specific Causal Structure
```
Q1: "causal inference" AND ("market microstructure" OR "exchange" OR "order driven" OR "quote driven")
Q2: "order driven market" AND ("causal" OR "causality" OR "price formation" OR "price discovery")
Q3: "quote driven market" AND ("causal" OR "price change" OR "dealer" OR "market maker")
Q4: "auction market" AND ("causal" OR "price discovery" OR "clearing" OR "batch")
Q5: "market microstructure" AND ("volume" OR "price") AND ("causal" OR "causality" OR "Granger")
```

### Query Block B: Granger Causality and Variable-Lag Extensions
```
Q6: "Granger causality" AND ("financial" OR "stock" OR "market" OR "trading") AND ("high frequency" OR "tick")
Q7: "variable lag Granger" OR "time-varying Granger" AND ("financial" OR "market" OR "stock")
Q8: "Granger causality" AND ("volume" OR "order flow") AND ("price" OR "return")
Q9: "nonlinear Granger causality" AND ("financial" OR "market" OR "volatility")
Q10: "Granger causality" AND ("regime switching" OR "structural break" OR "non-stationary")
```

### Query Block C: Transfer Entropy
```
Q11: "transfer entropy" AND ("financial" OR "market" OR "stock" OR "trading")
Q12: "transfer entropy" AND ("information flow" OR "causality" OR "directed information")
Q13: "transfer entropy" AND ("high frequency" OR "tick data" OR "microstructure")
Q14: "transfer entropy" AND ("volume" OR "order flow") AND ("price" OR "return")
Q15: "conditional transfer entropy" AND ("financial" OR "market") AND ("confounder" OR "common cause")
```

### Query Block D: PC/FCI Causal Discovery Algorithms
```
Q16: "PC algorithm" OR "FCI algorithm" AND ("causal discovery" OR "causal graph") AND ("financial" OR "market")
Q17: "constraint based causal discovery" AND ("time series" OR "financial" OR "market")
Q18: "causal DAG" AND ("finance" OR "market" OR "trading") AND ("confounder" OR "latent")
Q19: "do calculus" OR "intervention" AND ("financial" OR "market" OR "trading" OR "policy")
Q20: "causal inference" AND ("observational data" OR "non-experimental") AND ("finance" OR "economics")
```

### Query Block E: Volume Clocks vs Time Clocks
```
Q21: "volume clock" OR "volume time" OR "event time" AND ("causal" OR "Granger" OR "time series")
Q22: "volume bar" OR "tick bar" OR "dollar bar" AND ("financial" OR "market" OR "trading")
Q23: "Easley" AND "Lopez de Prado" AND ("volume" OR "information" OR "clock" OR "tick")
Q24: "sampling frequency" AND ("causal" OR "Granger") AND ("financial" OR "high frequency")
Q25: "time aggregation" AND ("causal" OR "Granger" OR "volatility") AND ("financial" OR "market")
```

### Query Block F: Causal Validity of Cleaned Data
```
Q26: "data cleaning" AND ("causal" OR "causality") AND ("bias" OR "artifact" OR "distortion")
Q27: "outlier removal" AND ("causal inference" OR "Granger" OR "time series") AND ("bias" OR "effect")
Q28: "tick data" AND ("cleaning" OR "filtering" OR "error") AND ("causal" OR "statistical")
Q29: "survivorship bias" AND ("causal" OR "Granger" OR "return") AND ("financial" OR "stock")
Q30: "look-ahead bias" AND ("causal" OR "backtest" OR "inference") AND ("financial" OR "trading")
```

## Key Authors

| Author | Contribution | Key Work |
|---|---|---|
| Clive Granger | Granger causality (Nobel 2003) | "Investigating Causal Relations" (1969) |
| Thomas Schreiber | Transfer entropy | "Measuring Information Transfer" (2000) |
| Peter Spirtes | PC algorithm, causal discovery | "Causation, Prediction, and Search" (2000) |
| Clark Glymour | PC algorithm co-developer | "Causation, Prediction, and Search" |
| Richard Scheines | PC/FCI algorithms | TETRAD software |
| Judea Pearl | Causal inference framework, do-calculus | "Causality" (2000, 2009) |
| Robert Easley | Volume clocks, information-based trading | Easley–O'Hara VPIN model |
| Marcos Lopez de Prado | Advances in Financial ML, tick data bars | "Advances in Financial Machine Learning" (2018) |
| Maureen O'Hara | Market microstructure theory | "Market Microstructure Theory" (1995) |
| David Hendry | Econometric causality, structural breaks | "Econometric Modelling" |
| Peter Carr | Causal effects in options markets | Multiple papers |
| Jean-Philippe Bouchaud | Market impact, causal response functions | "Trades, Quotes and Prices" (2018) |
| Fabrizio Lillo | Market microstructure, cross-impact | Multiple papers on causal market models |
| Sebastian Kim | Variable-lag Granger causality | "Variable-lag Granger Causality" (2023) |

## Filter Criteria

| Criterion | Value |
|---|---|
| Date range | 1969–2026 |
| Categories | q-fin.ST, q-fin.TR, stat.ME, stat.ML, econ.EM, cs.LG |
| Minimum citations | 100+ for foundational (Granger 1969, Pearl 2000), 10+ for applied |
| Publication type | Peer-reviewed journal preferred; arXiv with code accepted |
| Must include | At least 3 papers distinguishing order-driven vs quote-driven causal structure |
| Must include | At least 2 papers on volume clocks vs time clocks for causal analysis |
| Language | English |

## Expected Deliverables

### Causal Models Needed
1. **Exchange-type-specific causal graph** — A DAG (or cyclic causal model) for each
   market type (order-driven, quote-driven, auction, hybrid) showing the causal
   relationships between volume, price, spread, depth, and information.
2. **Variable-lag Granger framework** — A method for estimating Granger causality with
   variable lags that adapt to market activity (fast in high-volume periods, slow in
   low-volume periods).
3. **Transfer entropy estimator** — A non-parametric estimator for directed information
   flow between instruments, robust to autocorrelation and non-stationarity.
4. **Causal discovery output** — PC or FCI algorithm applied to multi-instrument tick
   data, producing a causal graph with edge confidence scores.

### Validation Methods Needed
1. **Intervention test** — A natural experiment (e.g., exchange halt, circuit breaker)
   that acts as a causal intervention, allowing validation of the inferred causal graph.
2. **Cross-exchange comparison** — Same instrument on two exchanges with different
   microstructure (e.g., order-driven vs quote-driven). Causal rules should differ
   predictably.
3. **Cleaning sensitivity analysis** — Run causal inference on raw and cleaned data.
   Report which causal edges change. Flag edges that appear only in cleaned data as
   potential cleaning artifacts.

## Relevance Test

**How does this serve the Causal Raw Data Engine?**

1. **Correct causal inference**: The engine must apply the CORRECT causal rules for each
   exchange it processes. Applying order-driven rules to quote-driven data produces
   systematically wrong causal conclusions (e.g., falsely concluding that price changes
   are volume-caused when they are actually quote-revision-caused).
2. **Multi-exchange consistency**: When combining data from multiple exchanges, the
   engine must translate between different causal frameworks. A price change on an
   order-driven exchange and a price change on a quote-driven exchange have DIFFERENT
   causal meanings.
3. **Causal feature engineering**: Causal graphs guide feature selection for downstream
   ML models. If the causal graph shows that order flow imbalance causes price change
   (but not vice versa), then order flow imbalance is a valid feature for price
   prediction, but past price change is NOT a valid feature for order flow prediction.
4. **Shadow validation**: The shadow validation path (File 05) runs causal inference on
   raw (uncleaned) data. Comparing causal graphs from raw vs cleaned data detects
   cleaning-induced causal artifacts.

## DOI Verification Protocol

Same 4-step protocol:
1. Search on Google Scholar, Semantic Scholar, or journal websites.
2. Verify DOI at https://doi.org/<DOI>.
3. Cross-check metadata against 2+ sources.
4. Score: 🟢 HIGH (peer-reviewed, 50+ citations), 🟡 MEDIUM (working paper with
   code, 10+ citations), 🔴 LOW (preprint, <10 citations).

## Falsification Criteria

**When would exchange-specific causal inference FAIL?**

1. **If the exchange type is misclassified**: If we label a hybrid exchange as
   order-driven and apply order-driven rules during an auction phase, the causal
   inference is wrong. Mitigation: detect exchange phase dynamically, not statically.
2. **If feedback loops dominate**: If the causal graph has strong feedback (price →
   order flow → price), DAG-based methods (PC algorithm) cannot represent the true
   structure. Cyclic causal models or time-unrolled DAGs are needed.
3. **If the causal structure changes within a regime**: Even within a single exchange
   phase, the causal structure may shift (e.g., during stress, information causes price
   directly, bypassing order flow). Time-varying causal models are needed.
4. **If volume clocks are impractical**: If the instrument is too illiquid for volume
   bars (e.g., < 100 trades per day), volume-clock causal analysis has insufficient
   data. Time-clock analysis must be used, with appropriate caveats.

## Integration with Other Prompts

- **File 01 (Rough Paths)**: Path signatures encode the trajectory through the causal
  state space. Signature features can serve as inputs to causal discovery algorithms.
  Jump-adaptive signature resets should align with exchange phase transitions.
- **File 02 (Dissipative Systems)**: Bifurcation analysis identifies WHEN the causal
  structure changes (regime transition). Variable-lag Granger should use different
  lags in different regimes.
- **File 03 (Hybrid Q-Format)**: Causal inference requires precise arithmetic.
  Cross-exchange price comparison in different Q-formats requires explicit conversion
  with documented precision loss. Volume=0 check in Q48.16: exact zero, no epsilon.
- **File 04 (Selective Branchless)**: Causal inference is NOT on the hot path.
  Branchless optimization is not needed for causal analysis (it runs in batch,
  not per-tick).
- **File 05 (Ring Buffer)**: The shadow validation path runs causal inference on
  raw data asynchronously. Pre-allocated buffers store raw data for causal analysis.

## Reading Priority Matrix

| Priority | Paper Type | Example |
|---|---|---|
| P0 | Exchange-specific causal rules | Bouchaud "Trades, Quotes and Prices" |
| P0 | Volume clocks vs time clocks | Easley, Lopez de Prado, O'Hara |
| P1 | Variable-lag Granger causality | Kim et al. variable-lag paper |
| P1 | Transfer entropy for finance | Schreiber + applied finance papers |
| P2 | PC/FCI for financial time series | Spirtes + applied causal discovery |
| P2 | Causal validity of cleaned data | Lopez de Prado cleaning chapters |
| P3 | Intervention / natural experiment | Exchange halts as causal interventions |
| P4 | Cyclic causal models for markets | Feedback-aware causal models |

## AZ Xülasəsi

Bu axtarış sorğusu birja-xüsusi səbəb-nəticə təhlilini əhatə edir. Əvvəlki "həcm=0 →
qiymət donmuşdur" qaydası yalnız sifarişlə idarə olunan bazarlar (NYSE, NASDAQ) üçün
keçərlidir. Kotirovka ilə idarə olunan bazarlarda (FX, OTC istiqrazlar) qiymət həcm
olmadan da dəyişə bilər — bazar yaradıcıları kotirovkaları yeniləyir. Auksion bazarlarında
qiymət auksionlar arasında qeyri-müəyyəndir. Dəyişən gecikməli Granger səbəbiyyəti,
transfer entropiyası, PC/FCI alqoritmləri, həcm saatları ilə vaxt saatları arasındakı
fərq və təmizlənmiş məlumatların səbəb-nəticə etibarlılığı əsas axtarış mövzularıdır.
Kölgə doğrulama yolu xam məlumatlar üzərində səbəb-nəticə analizi apararaq təmizləmə
artefaktlarını aşkar edir.
