---
tags: [search-prompt, ring-buffer, pre-allocated, lock-free, spsc, disruptor, numa, shadow-validation]
category: academic-search
module: causal-raw-data-engine-v2
created: 2026-07-11
trust: 🟢 VERIFIED
revision: 2
changelog: "v2 — UPDATED: zero allocation replaced by pre-allocated hot path. Added shadow validation path. NUMA-aware layout."
---

# Search Prompt: Pre-Allocated Ring Buffers, Lock-Free Queues, and Shadow Validation for Market Data

## Objective

Find literature on pre-allocated ring buffers, lock-free single-producer/single-consumer
(SPSC) queues, cache-line alignment, the Disruptor pattern, memory-mapped I/O, NUMA-aware
memory layout, and shadow validation paths — applied to high-frequency market data
processing. The critical reframing from the previous version: **"zero allocation" is
replaced by "pre-allocated hot path"** — an honest description of what the engine actually
does. Memory IS allocated; it is allocated ONCE at initialization, not during per-tick
processing.

## Honest Framing: Pre-Allocated Hot Path (Not "Zero Allocation")

The previous prompt claimed the engine achieves "zero allocation" on the hot path. This
was misleading. The correct description:

### What Actually Happens

1. **At initialization** (startup, before any ticks arrive):
   - Allocate ring buffer(s) — typically 2^N entries for power-of-2 masking
   - Allocate scratch arrays for Q-format intermediates (128-bit multiply scratch)
   - Allocate shadow validation buffer (parallel copy of hot path state)
   - Allocate output accumulator arrays
   - Pin memory to specific NUMA nodes
   - Pre-warm page tables (touch every page to force OS mapping)
   - Pre-allocate NumPy output arrays for `out=` parameter usage

2. **During the hot path** (per-tick processing, no new allocations):
   - Read from ring buffer head (pre-allocated)
   - Compute Q-format operations into pre-allocated scratch arrays
   - Write results into pre-allocated output accumulator
   - Use NumPy `out=` parameter to write into pre-allocated arrays (avoids internal copy)
   - Advance ring buffer head/tail pointers (pointer arithmetic, no allocation)

3. **During shadow validation** (asynchronous, off hot path):
   - Shadow process reads from a SECOND pre-allocated ring buffer
   - Computes the same transformations independently
   - Compares results to hot path output
   - Logs discrepancies
   - This shadow path MAY allocate (it is not latency-sensitive)

### Why This Matters

The distinction is not pedantic — it affects system design:
- **Garbage collection**: Python's GC can pause the hot path if allocations trigger
  collection. Pre-allocation prevents this. But we must VERIFY no hidden allocations
  occur (e.g., NumPy boolean indexing creates copies).
- **Memory fragmentation**: Even if we pre-allocate, the OS may page-fault during
  the hot path if pages are lazily mapped. Pre-warming prevents this.
- **NUMA effects**: If the ring buffer spans two NUMA nodes, cross-node access adds
  ~100ns latency per access. Pre-allocation must be NUMA-aware.

## Technical Components

### A. Ring Buffer (Pre-Allocated, Power-of-2)

```
Design:
- Capacity: 2^N entries (typically 2^16 = 65536 or 2^20 = 1048576)
- Entry size: fixed (e.g., 128 bytes per tick: price[8] + volume[8] + delta[8] +
  timestamp[8] + flags[8] + padding[88] = 128 bytes, exactly 2 cache lines on x86)
- Head pointer: atomically updated by producer (single thread)
- Tail pointer: atomically updated by consumer (single thread)
- Index masking: index = raw_counter & (capacity - 1)  [no modulo needed]
- Full check: head - tail >= capacity  [unsigned subtraction, branchless]
- Empty check: head == tail  [branchless comparison]
```

**Cache-line alignment**:
- x86-64: 64-byte cache lines. Head and tail pointers MUST be on separate cache lines
  to avoid false sharing.
  `struct { alignas(64) atomic<uint64_t> head; alignas(64) atomic<uint64_t> tail; }`
- ARM (Graviton, Ampere): 128-byte cache lines on some cores. Use `alignas(128)` for
  ARM deployments.
- False sharing between head and tail causes cache coherence traffic (MESI protocol)
  that adds 50-100ns per access.

### B. Lock-Free SPSC Queue

The ring buffer is a single-producer, single-consumer (SPSC) queue:
- **Producer**: Network I/O thread that receives market data feed and writes to ring buffer.
- **Consumer**: Processing thread that reads from ring buffer and computes transformations.
- **No locks needed**: SPSC queues can be lock-free using only atomic loads/stores with
  acquire/release semantics.
- **Memory ordering**: Producer writes data FIRST, then advances head (release store).
  Consumer reads tail FIRST (acquire load), then reads data. This ensures data is visible
  before the consumer sees the updated pointer.

### C. Disruptor Pattern (LMAX / Martin Thompson)

The LMAX Disruptor is a high-performance inter-thread messaging pattern:
1. **Pre-allocated ring buffer** of event slots
2. **Sequencer** that manages claim/publish protocol
3. **Multiple consumers** via dependency graph (not just SPSC)
4. **Batch processing** — consumer processes all available events in one pass
5. **Wait strategies** — busy-spin for lowest latency, yielding for lower CPU usage

For the engine, we use a simplified Disruptor:
- Single producer (feed handler), single consumer (processor)
- No dependency graph needed
- Batch processing: consumer drains all available events per wake-up
- Busy-spin on consumer for < 1 microsecond latency

### D. Memory-Mapped I/O for Market Data Feeds

Some exchange feeds (e.g., NASDAQ ITCH via shared memory, CME MDP 3.0 via multicast)
can be consumed via memory-mapped files or shared memory segments:
- `mmap()` the shared memory region
- Ring buffer IS the shared memory — no copy from kernel to user space
- Kernel bypass: NIC writes directly to user-space buffer (DPDK, Solarflare OpenOnload)
- Latency: < 1 microsecond from NIC to ring buffer entry

### E. Shadow Validation Path (Observability Without Hot Path Impact)

The shadow validation path is a CRITICAL addition for production reliability:

```
Architecture:
                    ┌──────────────────────────┐
  Market Feed ────► │  Ring Buffer (Primary)   │ ────► Hot Path Consumer
                    │  (pre-allocated, SPSC)   │        ├── Q-format ops
                    └──────────────────────────┘        ├── Signature computation
                                                        ├── Regime detection
                                                        └── Output accumulator
                                                                   │
                                                                   ▼
                                                          ┌────────────────┐
                                                          │ Output Stream  │
                                                          └────────────────┘
                                                                   ▲
                                                                   │
                    ┌──────────────────────────┐                   │
  Market Feed ────► │  Ring Buffer (Shadow)    │ ────► Shadow Consumer
  (same feed,       │  (pre-allocated, SPSC)   │        ├── Same Q-format ops
   independent      └──────────────────────────┘        ├── Independent implementation
   copy)                                                ├── Compares to primary output
                                                        └── Logs discrepancies to metrics
```

**Why shadow validation?**
1. **Detect hot path bugs**: If the hot path has a subtle bug (e.g., Q-format overflow
   not caught, signature drift), the shadow path (independently implemented, possibly in
   float64 for comparison) will produce different results.
2. **Monitor data quality**: Shadow path can compute statistics (min, max, mean, stddev)
   without affecting hot path latency.
3. **Audit trail**: Shadow path writes a detailed log of every transformation, enabling
   post-mortem analysis of any anomalous output.
4. **Safe deployment**: When deploying a new version of the hot path, run old and new
   in shadow mode. If shadow (new) matches primary (old), promote to primary.

**Shadow path is NOT on the hot path**:
- It runs on a separate thread with lower priority
- It may use floating-point (for cross-validation against fixed-point)
- It may allocate memory (for logging, metrics)
- It may be slower (even 10x slower is acceptable)

### F. NUMA-Aware Memory Layout

On multi-socket systems (common in co-located HFT servers):
- Each CPU socket has its own local memory (NUMA node)
- Accessing remote memory adds ~100ns latency per cache line
- The ring buffer MUST be allocated on the NUMA node where the consumer thread runs
- `numactl --cpunodebind=0 --membind=0` or `mbind()` syscall to pin memory
- In Python: use `os.sched_setaffinity()` + `mmap` with `MAP_POPULATE` flag

### G. Mechanical Sympathy Principles

"Mechanical sympathy" (coined by race car driver Jackie Stewart, popularized in software
by Martin Thompson) means designing software that works WITH the hardware, not against it:

1. **Cache-line alignment**: Align data structures to cache line boundaries
2. **Sequential access**: Access memory sequentially (prefetcher friendly)
3. **Avoid false sharing**: Separate writer and reader state onto different cache lines
4. **Batch processing**: Process multiple items per cache line fetch
5. **Pre-allocation**: Allocate all memory at startup, never during processing
6. **Minimal system calls**: Avoid syscalls on the hot path (no logging, no allocation)
7. **Power-of-2 sizes**: Use power-of-2 ring buffer sizes for bitwise masking

## Known Limitations (Anti-Hallucination Protocol)

### Limitation 1: Pre-Allocation Requires Knowing Maximum Load
The ring buffer size must accommodate peak tick rate. If peak is 10M ticks/sec and
processing takes 100ns/tick, the buffer must hold at least 10M × 0.0001 = 1000 ticks
to survive a 1ms processing stall. In practice, use 2^16 = 65536 entries (64x headroom).

### Limitation 2: Python's GIL Limits True Parallelism
Python's Global Interpreter Lock (GIL) prevents true multi-threaded parallelism for
CPU-bound code. The shadow validation path must run in a separate PROCESS (multiprocessing)
or use a GIL-releasing library (NumPy releases GIL during array operations). For true
SPSC lock-free behavior, the hot path should be implemented in C/Cython/Numba.

### Limitation 3: Shadow Validation Cannot Catch All Bugs
If both primary and shadow implementations share a common bug (e.g., same Q-format
overflow logic, same misunderstanding of exchange protocol), shadow validation will not
detect it. The shadow path must be INDEPENDENTLY implemented (different code, possibly
different language or arithmetic).

### Limitation 4: NUMA Pinning Is Fragile
OS schedulers may migrate threads between NUMA nodes, defeating pinning. Use
`sched_setaffinity` + `numactl` + verify with `/proc/PID/status` (check `Cpus_allowed_list`).
Container environments (Docker, K8s) may override NUMA settings.

## Search Queries

### Query Block A: Ring Buffers and Lock-Free Queues
```
Q1: "ring buffer" OR "circular buffer" AND ("lock-free" OR "lockless" OR "wait-free") AND ("SPSC" OR "single producer")
Q2: "lock-free queue" AND ("SPSC" OR "single producer single consumer") AND ("performance" OR "latency")
Q3: "ring buffer" AND ("market data" OR "trading" OR "high frequency" OR "HFT")
Q4: "bounded buffer" AND ("real-time" OR "low latency" OR "deterministic") AND "allocation"
```

### Query Block B: Disruptor Pattern and Mechanical Sympasympathy
```
Q5: "Disruptor" AND ("LMAX" OR "Martin Thompson" OR "mechanical sympathy" OR "inter-thread")
Q6: "mechanical sympathy" AND ("cache" OR "CPU" OR "hardware" OR "latency")
Q7: "Disruptor pattern" AND ("performance" OR "benchmark" OR "throughput" OR "latency")
Q8: "event sourcing" AND ("ring buffer" OR "Disruptor") AND ("trading" OR "financial")
```

### Query Block C: Cache-Line Alignment and False Sharing
```
Q9: "false sharing" AND ("cache line" OR "cache-line" OR "cache coherence") AND ("performance" OR "latency")
Q10: "cache line alignment" AND ("lock-free" OR "concurrent" OR "multi-threaded")
Q11: "MESI protocol" AND ("false sharing" OR "cache coherence" OR "invalidation")
Q12: "cache oblivious" OR "cache aware" AND ("data structure" OR "ring buffer" OR "queue")
```

### Query Block D: Memory-Mapped I/O and Kernel Bypass
```
Q13: "memory mapped" OR "mmap" AND ("market data" OR "trading" OR "low latency")
Q14: "kernel bypass" AND ("network" OR "NIC" OR "DPDK" OR "Solarflare" OR "OpenOnload")
Q15: "shared memory" AND ("market data" OR "exchange feed" OR "multicast") AND "latency"
Q16: "user space networking" AND ("trading" OR "financial" OR "HFT")
```

### Query Block E: NUMA-Aware Design
```
Q17: "NUMA" AND ("memory layout" OR "allocation" OR "pinning") AND ("low latency" OR "HFT" OR "trading")
Q18: "NUMA aware" AND ("data structure" OR "ring buffer" OR "queue") AND "performance"
Q19: "memory affinity" AND ("thread" OR "process" OR "NUMA") AND "latency"
Q20: "cross-NUMA" AND ("latency" OR "penalty" OR "remote access") AND "benchmark"
```

### Query Block F: Shadow Validation and Observability
```
Q21: "shadow" AND ("validation" OR "testing" OR "comparison") AND ("data pipeline" OR "streaming" OR "real-time")
Q22: "dual path" OR "parallel validation" AND ("data processing" OR "financial" OR "market data")
Q23: "canary deployment" AND ("data pipeline" OR "streaming" OR "real-time" OR "trading")
Q24: "observability" AND ("low latency" OR "HFT" OR "hot path") AND ("monitoring" OR "metrics")
Q25: "data quality" AND ("streaming" OR "real-time" OR "tick data") AND ("validation" OR "monitoring")
```

## Key Authors and References

| Author / Source | Contribution |
|---|---|
| Martin Thompson | Disruptor pattern, mechanical sympathy, LMAX Exchange |
| Michael Barker | Disruptor co-creator, LMAX |
| Dmitry Vyukov | Lock-free data structures, Go runtime concurrent structures |
| Herb Sutter | "Writing Lock-Free Code" series, effective concurrency |
| Ulrich Drepper | "What Every Programmer Should Know About Memory" (cache, NUMA) |
| Intel Corporation | 64-ia-32-architectures-optimization-manual (cache, NUMA, false sharing) |
| DPDK Project | Data Plane Development Kit (kernel bypass, hugepages) |
| Solarflare / Xilinx | OpenOnload (kernel bypass networking) |
| LMAX Exchange | Disruptor open-source library + performance papers |
| Nitsan Shaked | JCTools (Java lock-free queues, SPSC ring buffers) |
| Paul E. McKenney | RCU, memory ordering, "Is Parallel Programming Hard" |

## Filter Criteria

| Criterion | Value |
|---|---|
| Date range | 2005–2026 |
| Categories | cs.DC, cs.PF, cs.OS, q-fin.TR, q-fin.CP |
| Minimum citations | 20+ for foundational (Disruptor, false sharing), 5+ for applied |
| Publication type | Peer-reviewed, conference (SOSP, OSDI, EuroSys), tech reports, open-source docs |
| Must include | At least 1 reference on shadow validation or dual-path processing |
| Language | English |

## Expected Deliverables

### Architecture Patterns Needed
1. **Pre-allocated SPSC ring buffer** — With cache-line aligned head/tail, power-of-2
   sizing, memory ordering guarantees documented.
2. **Disruptor adaptation** — How to adapt the LMAX Disruptor for a Python/Cython engine
   (which parts translate, which need C).
3. **Shadow validation architecture** — Independent implementation, comparison protocol,
   discrepancy handling, metrics emission.
4. **NUMA pinning recipe** — Exact syscalls, Python bindings, and verification steps.

### Quantitative Data Needed
1. **False sharing latency cost** — Measured in nanoseconds per access for x86 and ARM.
2. **Cross-NUMA access penalty** — Measured for common server configurations (2-socket,
   4-socket).
3. **Ring buffer throughput** — Maximum ticks/sec for various buffer sizes and entry sizes.
4. **Shadow validation overhead** — CPU cost of running shadow path as % of hot path cost.

## Relevance Test

**How does this serve the Causal Raw Data Engine?**

1. **Deterministic latency**: Pre-allocated ring buffers ensure that per-tick processing
   has no allocation-induced latency spikes. The hot path has bounded worst-case latency.
2. **Data integrity**: Shadow validation catches bugs that unit tests miss — particularly
   Q-format overflow, signature drift, and exchange protocol parsing errors.
3. **Scalability**: NUMA-aware layout ensures the engine scales to multi-socket servers
   without cross-node latency degradation.
4. **Production safety**: Canary deployment via shadow path allows safe rollout of new
   engine versions without risking the primary processing pipeline.

## DOI Verification Protocol

Same 4-step protocol:
1. Search on ACM DL, IEEE Xplore, or Google Scholar.
2. Verify DOI at https://doi.org/<DOI>.
3. Cross-check against 2+ sources.
4. Score: 🟢 HIGH (top-tier conference: SOSP, OSDI, EuroSys), 🟡 MEDIUM (open-source
   project with benchmarks), 🔴 LOW (blog post, no benchmarks).

## Falsification Criteria

**When would pre-allocated ring buffers FAIL?**

1. **If tick rate exceeds buffer capacity**: If a burst of 100M ticks arrives in 1 second
   and the buffer holds only 65536 entries, the buffer overflows. Mitigation: monitor
   buffer utilization, alert at 80% capacity, dynamically resize (requires brief pause).
2. **If Python GC pauses are unavoidable**: If NumPy or Python internals allocate despite
   pre-allocation (e.g., temporary objects in ufunc evaluation), GC pauses may still
   occur. Mitigation: `gc.disable()` on hot path thread, use `gc.freeze()` in Python 3.7+.
3. **If shadow validation is too expensive**: If running a shadow path doubles CPU usage
   and the server is already at capacity, the shadow path must be downgraded (sample
   every Nth tick instead of every tick).

## AZ Xülasəsi

Bu axtarış sorğusu əvvəlcədən ayrılmış (pre-allocated) halqalı buferləri, kilidsiz SPSC
növbələri və kölgə doğrulama yolunu (shadow validation path) əhatə edir. "Sıfır ayırma"
iddiası "əvvəlcədən ayrılmış isti yol" ilə əvəz edilir — yaddaş AYRILIR, lakin yalnız işə
salma zamanı, hər tik emalı zamanı deyil. Keş xətti uyğunlaşması (x86 üçün 64 bayt, ARM
üçün 128 bayt), yalan paylaşımın (false sharing) qarşısının alınması, LMAX Disruptor
nümunəsi, NUMA-fərqli yaddaş yerləşdirməsi və müşahidə qabiliyyəti üçün kölgə doğrulama
yolu əsas texniki komponentlərdir. Kölgə yolu isti yoldan müstəqil tətbiq edilir və
ayrıqcalıqları aşkar etmək üçün nəticələri müqayisə edir.
