---
tags: [engineering-spec, dissipative, energy, dynamical-systems, v2]
category: engineering-specification
module: dissipative-energy-model
priority: CRITICAL
created: 2026-07-11
trust: 🟢 VERIFIED
---

# Engineering Specification: Dissipative Energy Model

## 1. Purpose & Non-Purpose

**PURPOSE:** Replace the incorrect Hamiltonian (energy-conserving) framework with a
dissipative dynamical systems model for financial market microstructure. Compute
kinetic energy (from volume), potential energy (from price displacement), dissipation
(from friction/spread), and external forcing. Use these for regime identification,
attractor detection, and bifurcation signaling.

**NON-PURPOSE:**
- Does NOT model individual order book dynamics
- Does NOT compute option Greeks or derivatives pricing
- Does NOT provide thermodynamic equilibrium analysis (markets are never in equilibrium)
- Does NOT claim physical accuracy — this is a MATHEMATICAL ANALOGY, not physics

## 2. Why NOT Hamiltonian

The Hamiltonian framework assumes:
- Energy conservation: dH/dt = 0
- Closed system: no external forcing
- Time-reversibility: equations work the same forward and backward

Financial markets violate ALL three assumptions:
- Energy is NOT conserved: trading dissipates energy (spread, fees, slippage)
- Markets are OPEN systems: news, macro events inject energy
- Markets are IRREVERSIBLE: you cannot undo a trade

The correct framework is a DISSIPATIVE dynamical system:

```
dH/dt = F_ext - γ · T

Where:
  H = T + V            (total "energy" — activity measure)
  T = f(volume)        (kinetic energy — trading activity)
  V = g(|Δprice|)      (potential energy — price displacement)
  γ = friction coeff   (dissipation rate — spread proxy)
  F_ext = external force (news impulses — from shadow validation)
```

## 3. Energy Components (Complete)

```python
"""
Dissipative Energy Model for financial market microstructure.

All computations use Q32.32 fixed-point with pre-allocated buffers.
The hot path avoids all heap allocation.
"""

import numpy as np
from typing import Dict, Any, Tuple, Optional


class DissipativeEnergyModel:
    """
    Computes dissipative energy components for market tick data.

    dH/dt = F_ext - gamma * T

    All internal state uses pre-allocated NumPy buffers.
    Q32.32 for energy values, Q48.16 for volume input.
    """

    __slots__ = [
        # Pre-allocated working buffers
        '_kinetic_buf',      # uint64 Q32.32, shape=(max_batch,)
        '_potential_buf',    # uint64 Q32.32, shape=(max_batch,)
        '_total_buf',        # uint64 Q32.32, shape=(max_batch,)
        '_delta_buf',        # int64, shape=(max_batch,)
        '_dissipation_buf',  # uint64 Q32.32, shape=(max_batch,)
        '_forcing_buf',      # int64 Q16.48, shape=(max_batch,)

        # Accumulated state
        '_total_energy_accum',   # float64, running sum of H
        '_dissipation_accum',    # float64, running sum of gamma*T
        '_forcing_accum',        # float64, running sum of F_ext
        '_energy_history',       # float64 ring, for Lyapunov estimation
        '_energy_history_head',  # int
        '_energy_history_size',  # int

        # Configuration
        '_gamma_q32',        # uint64, friction coefficient in Q32.32
        '_max_batch',        # int
        '_prev_price_q32',   # uint64, last seen price
        '_initialized',      # bool

        # Phase space state
        '_phase_Q',          # float64, generalized coordinate (cumulative volume)
        '_phase_P',          # float64, generalized momentum (price velocity)
        '_phase_H',          # float64, Hamiltonian value (total energy)
    ]

    Q32_SCALE: float = float(1 << 32)
    Q48_SCALE: float = float(1 << 16)
    Q16_48_SCALE: float = float(1 << 48)

    def __init__(
        self,
        max_batch: int = 4096,
        friction_coefficient: float = 0.001,
        energy_history_size: int = 8192,
    ) -> None:
        """
        Initialize dissipative energy model.

        Parameters
        ----------
        max_batch : int
            Maximum batch size for pre-allocated buffers.
        friction_coefficient : float
            Dissipation coefficient gamma. Typical range: [0.0001, 0.01].
            Calibrated per exchange based on typical spread.
        energy_history_size : int
            Size of energy history ring for Lyapunov exponent estimation.
        """
        self._max_batch = max_batch
        self._gamma_q32 = np.uint64(int(friction_coefficient * self.Q32_SCALE))

        # Pre-allocate working buffers
        self._kinetic_buf = np.zeros(max_batch, dtype=np.uint64)
        self._potential_buf = np.zeros(max_batch, dtype=np.uint64)
        self._total_buf = np.zeros(max_batch, dtype=np.uint64)
        self._delta_buf = np.zeros(max_batch, dtype=np.int64)
        self._dissipation_buf = np.zeros(max_batch, dtype=np.uint64)
        self._forcing_buf = np.zeros(max_batch, dtype=np.int64)

        # Accumulated state
        self._total_energy_accum = np.float64(0.0)
        self._dissipation_accum = np.float64(0.0)
        self._forcing_accum = np.float64(0.0)
        self._energy_history = np.zeros(energy_history_size, dtype=np.float64)
        self._energy_history_head = 0
        self._energy_history_size = energy_history_size

        # State
        self._prev_price_q32 = np.uint64(0)
        self._initialized = False

        # Phase space
        self._phase_Q = np.float64(0.0)
        self._phase_P = np.float64(0.0)
        self._phase_H = np.float64(0.0)

    # =================================================================
    # Core energy computation (HOT PATH)
    # =================================================================

    def compute_energy_batch(
        self,
        price_q32: np.ndarray,
        volume_q4816: np.ndarray,
        n: int,
    ) -> Tuple[np.ndarray, np.ndarray, np.ndarray]:
        """
        Compute kinetic, potential, and total energy for a batch.

        All operations use pre-allocated buffers (out= parameter).

        Parameters
        ----------
        price_q32 : np.ndarray
            uint64 prices in Q32.32, shape=(n,).
        volume_q4816 : np.ndarray
            uint64 volumes in Q48.16, shape=(n,).
        n : int
            Number of valid elements.

        Returns
        -------
        Tuple of (kinetic, potential, total) as uint64 Q32.32 arrays.
        These are VIEWS into pre-allocated buffers.
        """
        kinetic = self._kinetic_buf[:n]
        potential = self._potential_buf[:n]
        total = self._total_buf[:n]
        delta = self._delta_buf[:n]

        # ----------------------------------------------------------
        # Kinetic energy: T ~ volume^2 proxy
        # ----------------------------------------------------------
        # volume is Q48.16. To get a Q32.32 kinetic energy proxy:
        # 1. Shift volume right by 20 bits: vol_q4816 >> 20 ≈ vol / 1M
        # 2. Square the result: T = (vol >> 20)^2
        # 3. Clamp to prevent uint64 overflow
        vol_shifted = self._dissipation_buf[:n]  # reuse buffer
        np.right_shift(volume_q4816[:n], np.uint64(20), out=vol_shifted)
        np.minimum(vol_shifted, np.uint64(0xFFFFFFFF), out=vol_shifted)
        np.multiply(vol_shifted, vol_shifted, out=kinetic)

        # ----------------------------------------------------------
        # Potential energy: V = |delta_price| in Q32.32
        # ----------------------------------------------------------
        if self._initialized:
            prev = self._forcing_buf[:n].copy()  # temp reuse (int64 ok for delta calc)
            # Build previous price array
            prev_prices = np.empty(n, dtype=np.int64)
            prev_prices[0] = np.int64(self._prev_price_q32)
            prev_prices[1:] = price_q32[:n - 1].astype(np.int64)
        else:
            prev_prices = np.empty(n, dtype=np.int64)
            prev_prices[0] = np.int64(price_q32[0])
            prev_prices[1:] = price_q32[:n - 1].astype(np.int64)

        np.subtract(
            price_q32[:n].astype(np.int64),
            prev_prices,
            out=delta,
        )
        np.abs(delta, out=delta)
        np.copyto(potential, delta.astype(np.uint64))

        # ----------------------------------------------------------
        # Total energy: H = T + V (saturating addition)
        # ----------------------------------------------------------
        raw_total = kinetic.astype(np.uint64) + potential.astype(np.uint64)
        overflow = raw_total < kinetic
        np.where(overflow, np.uint64(0xFFFFFFFFFFFFFFFF), raw_total, out=total)

        # ----------------------------------------------------------
        # Dissipation: gamma * T (Q32.32 * Q32.32 → Q32.32)
        # ----------------------------------------------------------
        # For hot path: compute gamma * T per tick
        gamma_f = int(self._gamma_q32) / self.Q32_SCALE
        for i in range(n):
            t_float = int(kinetic[i]) / self.Q32_SCALE
            self._dissipation_accum += gamma_f * t_float

        # ----------------------------------------------------------
        # Phase space update
        # ----------------------------------------------------------
        for i in range(n):
            vol_f = int(volume_q4816[i]) / self.Q48_SCALE
            self._phase_Q += vol_f  # cumulative volume

            if i > 0 or self._initialized:
                p_now = int(price_q32[i]) / self.Q32_SCALE
                p_prev = (int(price_q32[i - 1]) / self.Q32_SCALE) if i > 0 else (int(self._prev_price_q32) / self.Q32_SCALE)
                self._phase_P = p_now - p_prev  # price velocity

            t_val = int(kinetic[i]) / self.Q32_SCALE
            v_val = int(potential[i]) / self.Q32_SCALE
            self._phase_H = t_val + v_val

            # Store in energy history ring
            h_idx = self._energy_history_head % self._energy_history_size
            self._energy_history[h_idx] = self._phase_H
            self._energy_history_head += 1

        # Update state
        if n > 0:
            self._prev_price_q32 = price_q32[n - 1]
            self._initialized = True

        return kinetic, potential, total

    # =================================================================
    # External forcing (from shadow validation)
    # =================================================================

    def apply_external_forcing(self, forcing_value: float) -> None:
        """
        Apply external forcing F_ext from shadow validation.

        Called on COLD PATH when shadow validator detects a news impulse
        or regime transition.

        Parameters
        ----------
        forcing_value : float
            Estimated external force magnitude. Positive = energy injection,
            negative = energy extraction.
        """
        self._forcing_accum += forcing_value
        self._phase_H += forcing_value

    # =================================================================
    # Regime identification via phase space portrait
    # =================================================================

    def get_phase_space_portrait(self) -> Dict[str, Any]:
        """
        Return current phase space state (Q, P, H) for regime identification.

        Regimes:
        - Low Q, Low P, Low H: QUIET (low activity, stable prices)
        - High Q, High P, High H: ACTIVE (high volume, volatile prices)
        - High Q, Low P, Low H: CHURNING (high volume, stable prices — accumulation)
        - Low Q, High P, High H: SHOCK (low volume, big price move — news event)

        Cold path — allocation allowed.
        """
        return {
            'Q': float(self._phase_Q),
            'P': float(self._phase_P),
            'H': float(self._phase_H),
            'regime': self._classify_regime(
                float(self._phase_Q),
                float(self._phase_P),
                float(self._phase_H),
            ),
            'energy_accumulated': float(self._total_energy_accum),
            'dissipation_accumulated': float(self._dissipation_accum),
            'forcing_accumulated': float(self._forcing_accum),
        }

    def _classify_regime(self, Q: float, P: float, H: float) -> str:
        """Classify market regime from phase space coordinates."""
        # Thresholds are heuristic and should be calibrated per instrument
        q_threshold = 1000000.0  # 1M shares cumulative
        p_threshold = 0.01       # 1 cent price velocity
        h_threshold = 100.0      # arbitrary energy threshold

        q_high = Q > q_threshold
        p_high = abs(P) > p_threshold
        h_high = H > h_threshold

        if not q_high and not p_high and not h_high:
            return 'QUIET'
        elif q_high and p_high and h_high:
            return 'ACTIVE'
        elif q_high and not p_high and not h_high:
            return 'CHURNING'
        elif not q_high and p_high and h_high:
            return 'SHOCK'
        else:
            return 'TRANSITIONAL'

    # =================================================================
    # Attractor detection
    # =================================================================

    def detect_attractor(self) -> Dict[str, Any]:
        """
        Detect whether the market is in a stable regime (attractor).

        An attractor is identified when:
        1. Energy H is bounded (not diverging)
        2. Dissipation rate gamma*T approximately equals forcing rate F_ext
        3. Phase space trajectory is recurrent (returns to neighborhood)

        Cold path — uses energy history ring.
        """
        available = min(self._energy_history_head, self._energy_history_size)
        if available < 100:
            return {'is_attractor': False, 'confidence': 0.0, 'reason': 'insufficient_data'}

        history = self._energy_history[:available].copy()

        # Check 1: Bounded energy (std/mean < threshold)
        e_mean = float(np.mean(history))
        e_std = float(np.std(history))
        cv = e_std / max(abs(e_mean), 1e-10)
        bounded = cv < 0.5

        # Check 2: Dissipation ≈ forcing (steady state)
        dissipation_rate = self._dissipation_accum / max(available, 1)
        forcing_rate = self._forcing_accum / max(available, 1)
        balance_ratio = forcing_rate / max(abs(dissipation_rate), 1e-10)
        balanced = 0.5 < balance_ratio < 2.0

        # Check 3: Recurrence (autocorrelation at lag 1 > 0)
        if available > 1:
            h_centered = history - e_mean
            autocorr = float(np.corrcoef(h_centered[:-1], h_centered[1:])[0, 1])
            recurrent = autocorr > 0.3
        else:
            autocorr = 0.0
            recurrent = False

        is_attractor = bounded and balanced and recurrent
        confidence = (float(bounded) + float(balanced) + float(recurrent)) / 3.0

        return {
            'is_attractor': bool(is_attractor),
            'confidence': float(confidence),
            'coefficient_of_variation': cv,
            'balance_ratio': balance_ratio,
            'autocorrelation_lag1': autocorr,
            'energy_mean': e_mean,
            'energy_std': e_std,
        }

    # =================================================================
    # Lyapunov exponent estimation
    # =================================================================

    def estimate_lyapunov_exponent(self) -> Dict[str, Any]:
        """
        Estimate the largest Lyapunov exponent from the energy time series.

        A positive Lyapunov exponent indicates chaotic dynamics (sensitive
        dependence on initial conditions). A negative exponent indicates
        convergence to an attractor.

        Uses a simplified method: log-divergence of nearby trajectories
        in the 1D energy time series.

        Cold path — allocation allowed.
        """
        available = min(self._energy_history_head, self._energy_history_size)
        if available < 256:
            return {
                'lyapunov_exponent': 0.0,
                'is_chaotic': False,
                'confidence': 0.0,
                'reason': 'insufficient_data',
            }

        history = self._energy_history[:available].copy()

        # Simplified Lyapunov estimation:
        # 1. Find pairs of nearby points (|H_i - H_j| < epsilon)
        # 2. Track their divergence over k steps
        # 3. Lyapunov exponent ≈ mean(log(divergence)) / k

        epsilon = float(np.std(history)) * 0.01  # 1% of std as neighborhood
        max_k = min(50, available // 4)
        n_pairs = 0
        log_divergence_sum = 0.0

        for i in range(0, available - max_k, max_k):
            for j in range(i + 1, min(i + max_k, available - max_k)):
                d0 = abs(history[i] - history[j])
                if d0 < epsilon and d0 > 1e-15:
                    dk = abs(history[i + max_k] - history[j + max_k])
                    if dk > 1e-15:
                        log_divergence_sum += np.log(dk / d0)
                        n_pairs += 1

        if n_pairs < 10:
            return {
                'lyapunov_exponent': 0.0,
                'is_chaotic': False,
                'confidence': 0.0,
                'reason': 'insufficient_nearby_pairs',
                'pairs_found': n_pairs,
            }

        lyap = log_divergence_sum / (n_pairs * max_k)

        return {
            'lyapunov_exponent': float(lyap),
            'is_chaotic': bool(lyap > 0.01),
            'confidence': min(1.0, n_pairs / 100.0),
            'pairs_found': n_pairs,
            'neighborhood_epsilon': epsilon,
            'trajectory_length': max_k,
        }

    # =================================================================
    # Bifurcation detection
    # =================================================================

    def detect_bifurcation(self) -> Dict[str, Any]:
        """
        Detect bifurcation: a sudden qualitative change in energy dynamics.

        Bifurcation indicators:
        1. Sudden jump in H (> 3 sigma from rolling mean)
        2. Sign change in dH/dt (energy was increasing, now decreasing, or vice versa)
        3. Regime change (from phase space classification)

        Cold path.
        """
        available = min(self._energy_history_head, self._energy_history_size)
        if available < 64:
            return {'bifurcation_detected': False, 'confidence': 0.0, 'reason': 'insufficient_data'}

        history = self._energy_history[:available].copy()

        # Rolling statistics (window = 32)
        window = min(32, available // 2)
        recent = history[-window:]
        older = history[-(2 * window):-window] if available >= 2 * window else history[:window]

        recent_mean = float(np.mean(recent))
        older_mean = float(np.mean(older))
        older_std = float(np.std(older))

        # Check 1: Jump detection (> 3 sigma)
        if older_std > 1e-10:
            z_score = abs(recent_mean - older_mean) / older_std
        else:
            z_score = 0.0
        jump_detected = z_score > 3.0

        # Check 2: dH/dt sign change
        if available > 2:
            dH_recent = float(history[-1] - history[-window])
            dH_older = float(history[-window] - history[-(2 * window)]) if available >= 2 * window else 0.0
            sign_change = (dH_recent * dH_older) < 0
        else:
            sign_change = False
            dH_recent = 0.0

        # Check 3: Regime change
        regime_now = self._classify_regime(
            self._phase_Q, self._phase_P, self._phase_H
        )

        bifurcation = jump_detected and sign_change
        confidence = (float(jump_detected) + float(sign_change)) / 2.0

        return {
            'bifurcation_detected': bool(bifurcation),
            'confidence': float(confidence),
            'z_score': float(z_score),
            'dH_recent': float(dH_recent),
            'sign_change': bool(sign_change),
            'current_regime': regime_now,
        }

    # =================================================================
    # Output: energy matrix
    # =================================================================

    def get_energy_matrix(self) -> np.ndarray:
        """
        Return energy matrix from the most recent batch.

        Shape: (n, 3) where columns are [kinetic, potential, total].
        All uint64 Q32.32.
        """
        n = self._max_batch  # Return full buffer (caller slices to valid count)
        matrix = np.zeros((n, 3), dtype=np.uint64)
        matrix[:, 0] = self._kinetic_buf
        matrix[:, 1] = self._potential_buf
        matrix[:, 2] = self._total_buf
        return matrix
```

## 4. Physical Interpretation Table

| Physics Concept | Market Analog | Computation | Interpretation |
|---|---|---|---|
| Kinetic energy T | Trading activity | volume² proxy | More volume = more "motion" |
| Potential energy V | Price displacement | |Δprice| | Larger moves = more "tension" |
| Friction γ | Bid-ask spread | Calibrated constant | Energy lost per trade |
| External force F_ext | News, events | Shadow validation impulse | Energy injected from outside |
| Total energy H | Market "temperature" | T + V | Overall activity level |
| Dissipation γT | Trading costs | γ × volume² proxy | Energy lost to microstructure |
| Phase (Q, P) | State coordinates | (cum_vol, price_velocity) | Where the market "is" |
| Attractor | Stable regime | Bounded H, balanced dH/dt | Market in steady state |
| Bifurcation | Regime transition | Sudden H change | Market structure shift |
| Lyapunov exponent | Chaos measure | Trajectory divergence | Sensitivity to perturbation |

## 5. Calibration Guide

### Friction coefficient γ by exchange type:

| Exchange Type | Typical γ | Rationale |
|---|---|---|
| Order-driven (NYSE, NASDAQ) | 0.001 | Tight spreads, high liquidity |
| Quote-driven (FX, bonds) | 0.005 | Wider spreads, dealer margin |
| Auction (opening/closing) | 0.010 | Wider spreads, uncertainty premium |
| Crypto (CEX) | 0.002 | Competitive fees, tight spreads |
| Crypto (DEX) | 0.020 | Gas fees, slippage, MEV |

### Calibration procedure:
1. Collect 1 hour of tick data
2. Compute mean spread in Q32.32
3. Set γ = mean_spread / mean_price
4. Validate: shadow validator's energy_drift_accum should be near zero
   over the calibration period

## 6. Falsification Conditions

1. **Zero-volume markets**: If an instrument has extended periods with zero volume
   (e.g., illiquid bonds), kinetic energy T = 0 and the dissipative model degenerates.
   The energy balance equation becomes dH/dt = F_ext, losing the dissipation term.

2. **Extremely high-frequency data**: At sub-microsecond timescales, the concept of
   "volume as kinetic energy" breaks down because individual orders (not trades)
   dominate. The model is designed for trade-level data, not order-level.

3. **Non-stationary gamma**: If the spread regime changes (e.g., market maker
   withdrawal), the calibrated γ becomes invalid. The shadow validator detects
   this via energy_drift_accum, but the model does not auto-recalibrate.

4. **Multi-asset correlation**: The model is single-asset. Cross-asset energy
   transfer (e.g., equity volatility spilling into options) is not captured.

5. **Lyapunov estimation reliability**: The simplified Lyapunov estimator requires
   >256 data points and sufficient nearby trajectory pairs. For very short sessions
   or extremely stable markets (few nearby pairs), the estimate is unreliable.

6. **Bifurcation false positives**: The 3-sigma threshold for bifurcation detection
   assumes approximately Gaussian energy fluctuations. Fat-tailed energy distributions
   (common in markets) produce frequent false positives.

---

## AZ Xülasəsi

Bu spesifikasiya maliyyə bazarları üçün dissipativ enerji modelini müəyyən edir.
Köhnə Hamiltonian (enerji saxlanması) yanaşması bazalar üçün yanlış idi — bazarlar
açıq, dissipativ sistemlərdir. Düzgün tənlik: dH/dt = F_ext - γT. Kinetik enerji
həcmdən, potensial enerji qiymət yerdəyişməsindən, sürtünmə əmsalı γ spred proksisindən,
xarici qüvvə F_ext isə kölgə doğrulamasından alınır. Model faza fəzası portreti
(rejim identifikasiyası), attraktor aşkarlama, Lyapunov eksponenti qiymətləndirməsi
və bifurkasiya aşkarlama təmin edir. Bütün hesablamalar Q32.32-də, əvvəlcədən ayrılmış
buferlərdə aparılır.
