---
tags: [engineering-spec, rough-paths, signature, jump-adaptive, v2]
category: engineering-specification
module: jump-adaptive-signature
priority: CRITICAL
created: 2026-07-11
trust: 🟢 VERIFIED
---

# Engineering Specification: Jump-Adaptive Rough Path Signatures

## 1. Purpose & Non-Purpose

**PURPOSE:** Compute streaming rough path signatures (Level 1 and Level 2) for
market tick data, with automatic reset at price discontinuities (jumps). Replaces
the naive "always accumulate" approach that produces meaningless signatures when
the price path has jumps.

**NON-PURPOSE:**
- Does NOT compute signatures beyond Level 2 (Level 3+ is exponentially expensive)
- Does NOT provide closed-form signature inversion
- Does NOT replace Fourier/wavelet analysis for frequency-domain features
- Does NOT handle multi-dimensional paths beyond 2D (Q, P)

## 2. Why Jump-Adaptive

Standard rough path signatures assume the underlying path is CONTINUOUS (or at
least has finite p-variation for p < 2). Financial price paths VIOLATE this:

- Flash crashes: 5-10% moves in seconds
- Opening gaps: overnight news creates discontinuities
- Auction boundaries: indicative → clearing price is a jump
- Data errors: bad ticks create artificial jumps

A naive signature accumulator would blend these jumps into the signature,
producing values that:
1. Overflow the Q16.48 range within hours
2. Lose all discriminative power (everything looks like a "big signature")
3. Violate Chen's identity (which assumes continuous paths)

The fix: DETECT jumps, RESET the signature, COUNT segments.

## 3. Mathematical Framework

### 3.1 Path and Increments

Let X_t = (Q_t, P_t) be a 2D path where:
- Q_t = cumulative volume proxy (generalized coordinate)
- P_t = price in Q32.32 (generalized momentum proxy)

Increments:
- ΔQ_i = Q_i - Q_{i-1} (volume increment, stored in Q16.48)
- ΔP_i = P_i - P_{i-1} (price increment, stored in Q16.48)

### 3.2 Signature Levels

**Level 1** (linear): S¹ = [ΣΔQ, ΣΔP]
- Captures net displacement of the path
- Shape: (2,), dtype=int64 Q16.48

**Level 2** (quadratic): S² = [[ΣΔQ·ΔQ, ΣΔQ·ΔP], [ΣΔP·ΔQ, ΣΔP·ΔP]]
- Captures area enclosed by the path (iterated integrals)
- Uses Chen's identity for streaming update
- Shape: (2,2), dtype=int64 Q16.48

### 3.3 Chen's Identity (Streaming Update)

For a continuous path segment, Chen's identity states:

```
S(X ⊕ Y) = S(X) ⊗ S(Y)

Where ⊗ is the tensor product in the truncated tensor algebra.

For Level 1 and Level 2:
  S¹_new = S¹_old + dX
  S²_new = S²_old + S¹_old ⊗ dX + ½(dX ⊗ dX)
```

This allows O(1) update per tick instead of O(n) recomputation.

### 3.4 Jump Detection and Reset

```
If |ΔP_i| > jump_threshold:
    S¹ ← [0, 0]
    S² ← [[0,0],[0,0]]
    segment_count += 1
Else:
    Apply Chen's identity update
```

## 4. Complete Implementation

```python
"""
Jump-adaptive rough path signature computation.

Level 1: [ΔQ, ΔP] in Q16.48
Level 2: [ΔQ², ΔQ·ΔP, ΔP·ΔQ, ΔP²] in Q16.48
Chen's identity for streaming update within continuous segments.
Automatic reset at detected jumps.
"""

import numpy as np
from typing import Dict, Any, Tuple, Optional


class JumpAdaptiveSignature:
    """
    Streaming rough path signature with jump-adaptive reset.

    Maintains Level 1 (2D) and Level 2 (2x2D) signatures in Q16.48 int64.
    Resets at detected price discontinuities.
    Tracks segment count for regime identification.
    """

    __slots__ = [
        # Signature accumulators
        '_sig_l1',           # int64 Q16.48, shape=(2,) [ΣdQ, ΣdP]
        '_sig_l2',           # int64 Q16.48, shape=(2,2) iterated integrals
        '_segment_count',    # int64, number of continuous segments

        # State tracking
        '_prev_Q',           # int64 Q16.48, previous cumulative volume proxy
        '_prev_P',           # uint64 Q32.32, previous price
        '_initialized',      # bool

        # Configuration
        '_jump_threshold',   # int64 Q16.48, |ΔP| threshold for reset
        '_drift_renorm_interval',  # int, renormalize every N ticks
        '_tick_counter',     # int, ticks since last renormalization

        # Pre-allocated working buffers
        '_dQ_buf',           # int64 Q16.48, shape=(max_batch,)
        '_dP_buf',           # int64 Q16.48, shape=(max_batch,)
        '_jump_mask_buf',    # uint8, shape=(max_batch,)

        # Ring buffer for signature history
        '_sig_history_l1',   # int64 Q16.48, shape=(history_size, 2)
        '_sig_history_l2',   # int64 Q16.48, shape=(history_size, 2, 2)
        '_sig_history_seg',  # int64, shape=(history_size,) segment counts
        '_history_head',     # int
        '_history_size',     # int
    ]

    Q16_48_SCALE: float = float(1 << 48)
    Q32_SCALE: float = float(1 << 32)

    def __init__(
        self,
        jump_threshold_price: float = 0.05,
        max_batch: int = 4096,
        history_size: int = 4096,
        drift_renorm_interval: int = 100000,
    ) -> None:
        """
        Initialize jump-adaptive signature computer.

        Parameters
        ----------
        jump_threshold_price : float
            Price displacement threshold for jump detection.
            In base price units (will be converted to Q32.32 internally).
        max_batch : int
            Maximum batch size for pre-allocated buffers.
        history_size : int
            Number of signature snapshots to retain in ring buffer.
        drift_renorm_interval : int
            Renormalize accumulators every N ticks to prevent drift overflow.
        """
        # Convert threshold: price is Q32.32, we compare delta in Q16.48
        # delta_price in Q32.32 → shift left 16 to get Q16.48
        threshold_q32 = int(jump_threshold_price * self.Q32_SCALE)
        self._jump_threshold = np.int64(min(threshold_q32 << 16, 0x7FFFFFFFFFFFFFFF))

        self._drift_renorm_interval = drift_renorm_interval
        self._tick_counter = 0

        # Signature accumulators
        self._sig_l1 = np.zeros(2, dtype=np.int64)
        self._sig_l2 = np.zeros((2, 2), dtype=np.int64)
        self._segment_count = np.int64(1)

        # State
        self._prev_Q = np.int64(0)
        self._prev_P = np.uint64(0)
        self._initialized = False

        # Pre-allocated buffers
        self._dQ_buf = np.zeros(max_batch, dtype=np.int64)
        self._dP_buf = np.zeros(max_batch, dtype=np.int64)
        self._jump_mask_buf = np.zeros(max_batch, dtype=np.uint8)

        # History ring buffer
        self._history_size = history_size
        self._sig_history_l1 = np.zeros((history_size, 2), dtype=np.int64)
        self._sig_history_l2 = np.zeros((history_size, 2, 2), dtype=np.int64)
        self._sig_history_seg = np.zeros(history_size, dtype=np.int64)
        self._history_head = 0

    # =================================================================
    # Core streaming update (HOT PATH)
    # =================================================================

    def update_batch(
        self,
        price_q32: np.ndarray,
        volume_q4816: np.ndarray,
        validity_mask: np.ndarray,
        n: int,
    ) -> np.ndarray:
        """
        Process a batch of ticks, updating signatures.

        This is the HOT PATH. Uses pre-allocated buffers.

        Parameters
        ----------
        price_q32 : np.ndarray
            uint64 prices in Q32.32, shape=(n,).
        volume_q4816 : np.ndarray
            uint64 volumes in Q48.16, shape=(n,).
        validity_mask : np.ndarray
            uint64 mask, 1=valid, shape=(n,).
        n : int
            Number of elements.

        Returns
        -------
        np.ndarray
            uint8 jump flags, shape=(n,). 1 = jump detected at this tick.
        """
        dQ = self._dQ_buf[:n]
        dP = self._dP_buf[:n]
        jump_mask = self._jump_mask_buf[:n]
        np.zeros(n, dtype=np.uint8, out=jump_mask)

        for i in range(n):
            if not validity_mask[i]:
                dQ[i] = np.int64(0)
                dP[i] = np.int64(0)
                continue

            # ---- Compute increments ----
            # dQ: volume increment (volume is Q48.16, convert to Q16.48 delta)
            # Simplified: dQ = volume[i] >> 32 (take integer part of volume)
            vol_i = int(volume_q4816[i])
            dQ_val = np.int64(vol_i >> 32)  # integer volume in Q16.48 scale

            # dP: price increment (price is Q32.32, convert delta to Q16.48)
            if self._initialized:
                delta_p_q32 = np.int64(int(price_q32[i]) - int(self._prev_P))
            else:
                delta_p_q32 = np.int64(0)

            # Convert Q32.32 delta to Q16.48: shift left 16, with clamping
            delta_p_clamped = np.int64(np.clip(delta_p_q32, -131071, 131071))
            dP_val = np.int64(delta_p_clamped << 16)

            dQ[i] = dQ_val
            dP[i] = dP_val

            # ---- Jump detection ----
            abs_dP = abs(int(dP_val))
            threshold = abs(int(self._jump_threshold))

            if abs_dP > threshold and self._initialized:
                # JUMP DETECTED — reset signature accumulators
                self._sig_l1[0] = np.int64(0)
                self._sig_l1[1] = np.int64(0)
                self._sig_l2[0, 0] = np.int64(0)
                self._sig_l2[0, 1] = np.int64(0)
                self._sig_l2[1, 0] = np.int64(0)
                self._sig_l2[1, 1] = np.int64(0)
                self._segment_count += np.int64(1)
                jump_mask[i] = np.uint8(1)
            else:
                # ---- Chen's identity update (within segment) ----
                self._apply_chens_identity(dQ_val, dP_val)

            # ---- Drift correction (periodic renormalization) ----
            self._tick_counter += 1
            if self._tick_counter >= self._drift_renorm_interval:
                self._renormalize_signature()
                self._tick_counter = 0

            # ---- Update state ----
            self._prev_Q = np.int64(int(self._prev_Q) + int(dQ_val))
            self._prev_P = price_q32[i]
            self._initialized = True

        # ---- Store snapshot in history ring ----
        h_idx = self._history_head % self._history_size
        self._sig_history_l1[h_idx] = self._sig_l1.copy()
        self._sig_history_l2[h_idx] = self._sig_l2.copy()
        self._sig_history_seg[h_idx] = self._segment_count
        self._history_head += 1

        return jump_mask.copy()

    # =================================================================
    # Chen's Identity (streaming tensor update)
    # =================================================================

    def _apply_chens_identity(self, dQ: np.int64, dP: np.int64) -> None:
        """
        Apply Chen's identity for streaming signature update.

        S¹_new = S¹_old + dX
        S²_new = S²_old + S¹_old ⊗ dX + ½(dX ⊗ dX)

        All in Q16.48 int64. Overflow is accepted (wraps modulo 2^64)
        because the signature is a relative measure within a segment.
        """
        # Save old Level 1 before update
        old_s1_Q = np.int64(self._sig_l1[0])
        old_s1_P = np.int64(self._sig_l1[1])

        # Level 1 update: S¹ += dX
        self._sig_l1[0] = np.int64(int(self._sig_l1[0]) + int(dQ))
        self._sig_l1[1] = np.int64(int(self._sig_l1[1]) + int(dP))

        # Level 2 update: S² += S¹_old ⊗ dX + ½(dX ⊗ dX)
        # [0,0]: S²_QQ += S¹_Q_old * dQ + ½ * dQ * dQ
        self._sig_l2[0, 0] = np.int64(
            int(self._sig_l2[0, 0])
            + int(old_s1_Q) * int(dQ) // (1 << 48)  # normalize product
            + int(dQ) * int(dQ) // (2 * (1 << 48))
        )

        # [0,1]: S²_QP += S¹_Q_old * dP + ½ * dQ * dP
        self._sig_l2[0, 1] = np.int64(
            int(self._sig_l2[0, 1])
            + int(old_s1_Q) * int(dP) // (1 << 48)
            + int(dQ) * int(dP) // (2 * (1 << 48))
        )

        # [1,0]: S²_PQ += S¹_P_old * dQ + ½ * dP * dQ
        self._sig_l2[1, 0] = np.int64(
            int(self._sig_l2[1, 0])
            + int(old_s1_P) * int(dQ) // (1 << 48)
            + int(dP) * int(dQ) // (2 * (1 << 48))
        )

        # [1,1]: S²_PP += S¹_P_old * dP + ½ * dP * dP
        self._sig_l2[1, 1] = np.int64(
            int(self._sig_l2[1, 1])
            + int(old_s1_P) * int(dP) // (1 << 48)
            + int(dP) * int(dP) // (2 * (1 << 48))
        )

    # =================================================================
    # Drift correction / renormalization
    # =================================================================

    def _renormalize_signature(self) -> None:
        """
        Periodic renormalization to prevent accumulator drift overflow.

        Divides all signature values by 2 (right shift by 1).
        This is a LOSSY operation — it discards the least significant bit.
        Trade-off: prevents overflow at the cost of precision.

        This is acceptable because:
        1. The signature is used for REGIME IDENTIFICATION, not exact reconstruction
        2. The most significant bits carry the regime information
        3. The segment counter preserves the count of discontinuities exactly
        """
        self._sig_l1[0] = np.int64(int(self._sig_l1[0]) >> 1)
        self._sig_l1[1] = np.int64(int(self._sig_l1[1]) >> 1)
        self._sig_l2[0, 0] = np.int64(int(self._sig_l2[0, 0]) >> 1)
        self._sig_l2[0, 1] = np.int64(int(self._sig_l2[0, 1]) >> 1)
        self._sig_l2[1, 0] = np.int64(int(self._sig_l2[1, 0]) >> 1)
        self._sig_l2[1, 1] = np.int64(int(self._sig_l2[1, 1]) >> 1)

    # =================================================================
    # Output methods
    # =================================================================

    def get_signature_vector(self) -> np.ndarray:
        """
        Return current signature as flat vector.

        Shape: (6,), dtype=int64 Q16.48
        Layout: [L1_Q, L1_P, L2_QQ, L2_QP, L2_PQ, L2_PP]
        """
        vec = np.zeros(6, dtype=np.int64)
        vec[0] = self._sig_l1[0]
        vec[1] = self._sig_l1[1]
        vec[2] = self._sig_l2[0, 0]
        vec[3] = self._sig_l2[0, 1]
        vec[4] = self._sig_l2[1, 0]
        vec[5] = self._sig_l2[1, 1]
        return vec

    def get_segment_count(self) -> int:
        """Return number of continuous segments (jumps + 1)."""
        return int(self._segment_count)

    def get_signature_history(self) -> Dict[str, np.ndarray]:
        """
        Return signature history from ring buffer.

        Cold path — copies data.
        """
        available = min(self._history_head, self._history_size)
        return {
            'level1': self._sig_history_l1[:available].copy(),
            'level2': self._sig_history_l2[:available].copy(),
            'segments': self._sig_history_seg[:available].copy(),
            'count': available,
        }

    def get_signature_report(self) -> Dict[str, Any]:
        """
        Return comprehensive signature report.

        Cold path — allocation allowed.
        """
        sig_vec = self.get_signature_vector()
        l1_norm = float(np.linalg.norm(sig_vec[:2].astype(np.float64))) / self.Q16_48_SCALE
        l2_norm = float(np.linalg.norm(sig_vec[2:].astype(np.float64))) / self.Q16_48_SCALE

        # Anti-symmetric component of L2 (area proxy)
        anti_sym = float(self._sig_l2[0, 1] - self._sig_l2[1, 0]) / self.Q16_48_SCALE

        return {
            'signature_vector': sig_vec.tolist(),
            'level1_norm': l1_norm,
            'level2_norm': l2_norm,
            'antisymmetric_area': anti_sym,
            'segment_count': int(self._segment_count),
            'ticks_since_renorm': self._tick_counter,
            'initialized': self._initialized,
        }

    # =================================================================
    # Signature-based regime features
    # =================================================================

    def compute_regime_features(self) -> Dict[str, float]:
        """
        Compute regime-identification features from signature.

        Features:
        - l1_direction: angle of Level 1 vector (path direction)
        - l2_area: antisymmetric component (enclosed area)
        - l2_symmetry: symmetric vs antisymmetric ratio
        - segments_per_tick: jump frequency

        Cold path.
        """
        l1_Q = float(self._sig_l1[0]) / self.Q16_48_SCALE
        l1_P = float(self._sig_l1[1]) / self.Q16_48_SCALE

        # Level 1 direction (angle in radians)
        direction = float(np.arctan2(l1_P, l1_Q))

        # Level 2 area (antisymmetric: QP - PQ)
        area = float(self._sig_l2[0, 1] - self._sig_l2[1, 0]) / self.Q16_48_SCALE

        # Level 2 symmetry ratio
        sym_component = float(self._sig_l2[0, 1] + self._sig_l2[1, 0]) / self.Q16_48_SCALE
        asym_component = area
        total_l2_off = abs(sym_component) + abs(asym_component)
        symmetry_ratio = abs(sym_component) / max(total_l2_off, 1e-15)

        # Segment frequency
        total_ticks = self._tick_counter + (
            (int(self._segment_count) - 1) * self._drift_renorm_interval
        )
        seg_freq = int(self._segment_count) / max(total_ticks, 1)

        return {
            'l1_direction_rad': direction,
            'l1_magnitude': float(np.sqrt(l1_Q**2 + l1_P**2)),
            'l2_area': area,
            'l2_symmetry_ratio': symmetry_ratio,
            'segments_per_tick': seg_freq,
            'total_segments': int(self._segment_count),
        }
```

## 5. Ring Buffer Integration

The signature module maintains its own ring buffer for signature history.
This integrates with the main engine's ring buffer as follows:

```
Engine Ring Buffer (tick-level)      Signature Ring Buffer (batch-level)
┌──────────────────────┐              ┌──────────────────────────┐
│ price[i]  (Q32.32)   │              │ sig_l1[batch] (2,) Q16.48│
│ volume[i] (Q48.16)   │───update───►│ sig_l2[batch] (2,2)      │
│ delta[i]  (Q16.48)   │              │ seg_count[batch]         │
│ kinetic[i]           │              └──────────────────────────┘
│ potential[i]         │
└──────────────────────┘
```

Each call to `update_batch()` writes one entry to the signature history ring.
The history ring is smaller (default 4096 entries) because it stores one
snapshot per batch, not per tick.

## 6. Q-Format Implementation Notes

### Why Q16.48 for signatures:

Signatures are accumulated products of increments. The increments themselves
are small (price changes are ~10⁻³ in base units), but products can be
extremely small (~10⁻⁶ or smaller). Q16.48 provides 3.55×10⁻¹⁵ resolution,
which is necessary to preserve meaningful signature values.

### Overflow handling:

Within a segment, Q16.48 accumulators can overflow if millions of ticks
accumulate without a jump. The drift renormalization (right-shift by 1
every N ticks) mitigates this. The segment counter provides exact jump
count regardless of accumulator state.

### Inter-format conversion:

Price increments arrive as Q32.32 deltas. Conversion to Q16.48:
1. Compute signed delta in int64 (Q32.32 scale)
2. Clamp to ±131071 (Q16.48 integer range)
3. Left-shift by 16 bits (32 fractional → 48 fractional)

Volume increments arrive as Q48.16 values. Conversion to Q16.48:
1. Right-shift by 32 bits (take integer part)
2. Interpret as Q16.48 (no fractional component for volume delta)

## 7. Falsification Conditions

1. **2D path limitation**: The signature only captures (Q, P) — volume proxy
   and price. Markets with important dynamics in other dimensions (e.g.,
   order book depth, spread, implied volatility) are incompletely characterized.

2. **Level 2 truncation**: Truncating at Level 2 loses higher-order path
   features. Paths with identical Level 1 and Level 2 signatures but different
   Level 3+ signatures cannot be distinguished.

3. **Renormalization information loss**: The periodic right-shift discards
   the least significant bit at each renormalization. Over many renormalizations,
   this accumulates into significant precision loss. The signature becomes
   progressively less informative within very long segments.

4. **Jump threshold calibration**: The jump threshold is a fixed parameter.
   If the "normal" price volatility changes (e.g., from low-vol to high-vol
   regime), the threshold may be too low (excessive resets) or too high
   (missed jumps). No adaptive threshold is provided.

5. **Chen's identity overflow**: The tensor product in Chen's identity involves
   multiplying two Q16.48 values and dividing by 2^48. If both operands are
   near the Q16.48 maximum (~131K), the product is ~1.7×10¹⁰, which fits in
   int64 but loses precision after division. For extreme paths, a 128-bit
   intermediate would be needed.

6. **Segment count unbounded growth**: The segment counter increments with each
   jump but never resets. Over very long sessions with many jumps, the counter
   grows without bound (though int64 overflow would take ~9.2×10¹⁸ jumps).

---

## AZ Xülasəsi

Bu spesifikasiya sıçrayışa uyğunlaşan kobud yol imzalarını (rough path signatures)
müəyyən edir. Standard kobud yol imzaları kəsilməz yolları fərz edir, lakin maliyyə
qiymət yolları sıçrayışlar ehtiva edir (flash crash-lar, açılış boşluqları, hərrac
sərhədləri). Həll: hər tick-də Chen eyniliyi ilə axın yenilənməsi, sıçrayış aşkar
edildikdə imzanın sıfırlanması və seqment sayğacının artırılması. Səviyyə 1 [ΔQ, ΔP]
və Səviyyə 2 [ΔQ², ΔQ·ΔP, ΔP·ΔQ, ΔP²] Q16.48 int64 formatında saxlanılır.
Drift düzəlişi (periodik renormallaşdırma) daşmanın qarşısını alır. İmza tarixini
saxlamaq üçün halqa buferi istifadə olunur.
