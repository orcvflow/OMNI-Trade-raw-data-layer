---
tags: [engineering-spec, branchless, validation, exchange-specific, v2]
category: engineering-specification
module: selective-branchless-validation
priority: CRITICAL
created: 2026-07-11
trust: 🟢 VERIFIED
---

# Engineering Specification: Selective Branchless Validation

## 1. Purpose & Non-Purpose

**PURPOSE:** Define the exchange-specific causal validation pipeline that uses
selective branchless operations ONLY for data-dependent conditions. Structural
decisions (which exchange type, which rules) use normal control flow.

**NON-PURPOSE:**
- Does NOT make all code branchless (only data-dependent paths)
- Does NOT replace the shadow validator (this is the hot-path gate)
- Does NOT validate cross-venue consistency
- Does NOT check business logic (order state, position limits)

## 2. Design Philosophy: "Selective Branchless"

The term "branchless" is often misused to mean "no if-statements anywhere."
That is both impossible and undesirable. Our approach:

| Decision Type | Branchless? | Rationale |
|---|---|---|
| Exchange type selection | NO | Set once at init, never changes per-tick |
| Batch size check | NO | Structural guard, not data-dependent |
| Price > 0 check | YES | Data-dependent, varies per tick |
| Volume < upper_bound | YES | Data-dependent |
| Timestamp monotonicity | YES | Data-dependent |
| Jump threshold comparison | YES | Data-dependent |
| Signature reset decision | NO* | Depends on jump detection result |

*The signature reset is technically data-dependent but its stateful nature
(accumulator reset) makes branchless implementation impractical without
sacrificing correctness.

## 3. Exchange-Specific Causal Rules

### 3.1 ORDER-DRIVEN Exchanges (NYSE, NASDAQ, LSE, TSE)

In order-driven markets, trades result from matching buy/sell orders:

```
Rule 1: trade_volume = 0 → last_price frozen ✅ (quote update, not trade)
Rule 2: trade_volume = 0 → mid_price frozen ✅ (no trade implies no mid change)
Rule 3: trade_volume > 0 → timestamp MUST advance (causal ordering)
Rule 4: trade_volume > 0 AND price = prev_price → VALID (same-price trade)
Rule 5: trade_volume > 0 AND price ≠ prev_price → VALID (price discovery)
```

**Key insight:** In order-driven markets, volume=0 ticks are quote updates.
These are valid and should NOT be masked out, but they carry different
causal implications (no energy exchange, only potential energy change).

### 3.2 QUOTE-DRIVEN Exchanges (OTC, FX spot, bond markets)

In quote-driven markets, dealers post bid/ask and trades happen against quotes:

```
Rule 1: bid/ask update without volume → VALID (quote refresh)
Rule 2: last_sale frozen without volume → VALID (no trade occurred)
Rule 3: volume > 0 → price must be within [bid, ask] (causal)
Rule 4: volume > 0 → timestamp MUST advance
Rule 5: quote update → timestamp MUST advance
```

**Key insight:** Quote-driven markets have frequent price updates without
volume. The causal gate is looser than order-driven.

### 3.3 AUCTION Exchanges (opening/closing auctions, call markets)

In auction markets, an indicative price is computed from accumulated orders:

```
Rule 1: indicative price changes without volume → VALID (auction process)
Rule 2: volume > 0 only at auction clearing time → VALID
Rule 3: timestamp MUST advance for every update
Rule 4: price can jump freely during auction (no continuity assumption)
Rule 5: post-auction: normal order-driven rules apply
```

**Key insight:** Auction markets VIOLATE the continuity assumption by design.
The jump-adaptive signature MUST reset at auction boundaries.

## 4. Complete Validation Pipeline

```python
"""
Selective branchless validation pipeline.

All data-dependent conditions use branchless NumPy operations.
Structural decisions use normal Python control flow.
"""

import numpy as np
from typing import Tuple


class SelectiveBranchlessValidator:
    """
    Hot-path causal validator with exchange-specific rules.

    All data-dependent branches use branchless NumPy operations
    (bitwise AND, np.where, np.clip). Structural branches use
    normal if/elif.
    """

    __slots__ = [
        '_exchange_type',
        '_price_upper_q32',
        '_price_lower_q32',
        '_volume_upper_q4816',
        '_prev_price_q32',
        '_prev_timestamp_ns',
        '_initialized',
        # Pre-allocated working buffers
        '_work_a',
        '_work_b',
        '_mask_out',
    ]

    def __init__(
        self,
        exchange_type: str,
        max_batch: int = 4096,
        price_upper: float = 2_147_483_647.0,  # ~2.14B
        price_lower: float = 0.0001,            # min tick size
        volume_upper: float = 281_000_000_000_000.0,  # ~281T
    ) -> None:
        self._exchange_type = exchange_type
        self._price_upper_q32 = np.uint64(int(price_upper * (1 << 32)))
        self._price_lower_q32 = np.uint64(int(price_lower * (1 << 32)))
        self._volume_upper_q4816 = np.uint64(int(volume_upper * (1 << 16)))
        self._prev_price_q32 = np.uint64(0)
        self._prev_timestamp_ns = np.int64(0)
        self._initialized = False

        # Pre-allocated working buffers
        self._work_a = np.zeros(max_batch, dtype=np.uint64)
        self._work_b = np.zeros(max_batch, dtype=np.uint64)
        self._mask_out = np.zeros(max_batch, dtype=np.uint64)

    def validate_batch(
        self,
        price_q32: np.ndarray,
        volume_q4816: np.ndarray,
        timestamp_ns: np.ndarray,
        n: int,
    ) -> np.ndarray:
        """
        Run the full selective branchless validation pipeline.

        Returns uint64 mask array: 1 = valid, 0 = invalid.
        All intermediate operations use pre-allocated buffers.
        """
        mask = self._mask_out[:n]
        np.ones(n, dtype=np.uint64, out=mask)

        # ---- Layer 1: Universal checks (all exchange types) ----
        self._check_price_bounds(price_q32, mask, n)
        self._check_volume_sanity(volume_q4816, mask, n)
        self._check_timestamp_monotonicity(timestamp_ns, mask, n)

        # ---- Layer 2: Exchange-specific causal gates ----
        if self._exchange_type == 'order_driven':
            self._gate_order_driven(price_q32, volume_q4816, timestamp_ns, mask, n)
        elif self._exchange_type == 'quote_driven':
            self._gate_quote_driven(price_q32, volume_q4816, timestamp_ns, mask, n)
        elif self._exchange_type == 'auction':
            self._gate_auction(price_q32, volume_q4816, timestamp_ns, mask, n)

        # ---- Layer 3: Jump detection (branchless threshold) ----
        jump_flags = self._detect_jumps(price_q32, mask, n)

        # Update state
        if n > 0:
            valid_mask = mask.astype(bool)
            if np.any(valid_mask):
                last_valid_idx = np.max(np.nonzero(valid_mask)[0])
                self._prev_price_q32 = price_q32[last_valid_idx]
                self._prev_timestamp_ns = timestamp_ns[last_valid_idx]
                self._initialized = True

        return mask.copy()

    # =================================================================
    # Layer 1: Universal checks (branchless)
    # =================================================================

    def _check_price_bounds(
        self, price_q32: np.ndarray, mask: np.ndarray, n: int
    ) -> None:
        """
        Branchless price bounds check.
        mask &= (price > lower) & (price < upper)
        """
        above_lower = np.greater(price_q32[:n], self._price_lower_q32)
        below_upper = np.less(price_q32[:n], self._price_upper_q32)
        in_bounds = np.logical_and(above_lower, below_upper)
        np.bitwise_and(mask, in_bounds.astype(np.uint64), out=mask)

    def _check_volume_sanity(
        self, volume_q4816: np.ndarray, mask: np.ndarray, n: int
    ) -> None:
        """
        Branchless volume sanity check.
        mask &= (volume <= upper_bound)
        Note: uint64 is always >= 0, so no lower bound check needed.
        """
        vol_ok = np.less_equal(volume_q4816[:n], self._volume_upper_q4816)
        np.bitwise_and(mask, vol_ok.astype(np.uint64), out=mask)

    def _check_timestamp_monotonicity(
        self, timestamp_ns: np.ndarray, mask: np.ndarray, n: int
    ) -> None:
        """
        Branchless timestamp monotonicity check.
        Uses sign-bit check on diff: dt >= 0 means monotone.

        Within-batch: each timestamp must be >= previous.
        Cross-batch: first timestamp must be >= _prev_timestamp_ns.
        """
        if n == 0:
            return

        # Cross-batch check (first element vs previous batch)
        if self._initialized:
            first_ok = timestamp_ns[0] >= self._prev_timestamp_ns
            if not first_ok:
                mask[0] = np.uint64(0)

        # Within-batch monotonicity (branchless via diff + sign)
        if n > 1:
            dt = np.diff(timestamp_ns[:n])
            # dt >= 0 → valid (1), dt < 0 → invalid (0)
            # Branchless: use comparison result directly
            ts_valid = np.greater_equal(dt, np.int64(0))

            # Prepend first element's validity (already handled above)
            full_valid = np.ones(n, dtype=bool)
            full_valid[1:] = ts_valid
            np.bitwise_and(mask, full_valid.astype(np.uint64), out=mask)

    # =================================================================
    # Layer 2: Exchange-specific causal gates
    # =================================================================

    def _gate_order_driven(
        self,
        price_q32: np.ndarray,
        volume_q4816: np.ndarray,
        timestamp_ns: np.ndarray,
        mask: np.ndarray,
        n: int,
    ) -> None:
        """
        Order-driven causal gate.

        If volume > 0, timestamp MUST have advanced from previous batch.
        Volume = 0 is valid (quote update).
        """
        if not self._initialized:
            return

        # volume > 0 AND timestamp <= prev → INVALID
        vol_positive = np.greater(volume_q4816[:n], np.uint64(0))
        ts_not_advanced = np.less_equal(timestamp_ns[:n], self._prev_timestamp_ns)
        violation = np.logical_and(vol_positive, ts_not_advanced)

        # Branchless: mask &= ~violation
        np.bitwise_and(mask, np.logical_not(violation).astype(np.uint64), out=mask)

    def _gate_quote_driven(
        self,
        price_q32: np.ndarray,
        volume_q4816: np.ndarray,
        timestamp_ns: np.ndarray,
        mask: np.ndarray,
        n: int,
    ) -> None:
        """
        Quote-driven causal gate.

        Price updates without volume are NORMAL.
        Only timestamp monotonicity is enforced (already in Layer 1).
        Additional: if volume > 0, price should not be zero.
        """
        # volume > 0 AND price = 0 → suspicious (data error)
        vol_positive = np.greater(volume_q4816[:n], np.uint64(0))
        price_zero = np.equal(price_q32[:n], np.uint64(0))
        violation = np.logical_and(vol_positive, price_zero)
        np.bitwise_and(mask, np.logical_not(violation).astype(np.uint64), out=mask)

    def _gate_auction(
        self,
        price_q32: np.ndarray,
        volume_q4816: np.ndarray,
        timestamp_ns: np.ndarray,
        mask: np.ndarray,
        n: int,
    ) -> None:
        """
        Auction causal gate.

        Indicative prices change freely without volume.
        Volume > 0 only valid at clearing time (we cannot verify clearing
        time on hot path — accept all, flag for shadow validation).
        Timestamp must advance (already in Layer 1).
        """
        # Auction: minimal gating. All ticks pass Layer 2.
        # Shadow validator checks auction-specific timing rules.
        pass

    # =================================================================
    # Layer 3: Jump detection (branchless)
    # =================================================================

    def _detect_jumps(
        self,
        price_q32: np.ndarray,
        mask: np.ndarray,
        n: int,
    ) -> np.ndarray:
        """
        Branchless jump detection: |delta_price| > threshold.

        Returns boolean array of jump locations.
        Does NOT modify mask — jumps are valid ticks, they just
        trigger signature resets.
        """
        jump_flags = np.zeros(n, dtype=bool)

        if n == 0:
            return jump_flags

        # Compute within-batch deltas
        if self._initialized:
            prev = np.empty(n, dtype=np.uint64)
            prev[0] = self._prev_price_q32
            prev[1:] = price_q32[:n - 1]
        else:
            prev = np.empty(n, dtype=np.uint64)
            prev[0] = price_q32[0]
            prev[1:] = price_q32[:n - 1]

        # Signed delta (int64 to handle negative)
        delta = price_q32[:n].astype(np.int64) - prev.astype(np.int64)
        abs_delta = np.abs(delta)

        # Branchless threshold comparison
        # Convert threshold to same scale as delta (Q32.32 int64)
        threshold = np.int64(0.05 * (1 << 32))  # ~0.05 in Q32.32
        jump_flags = np.greater(abs_delta, threshold)

        # Only count jumps on valid ticks
        valid_bool = mask[:n].astype(bool)
        jump_flags = np.logical_and(jump_flags, valid_bool)

        return jump_flags

    # =================================================================
    # Validity mask computation helpers
    # =================================================================

    def compute_validity_summary(self, mask: np.ndarray) -> dict:
        """Compute summary statistics from validity mask (cold path OK)."""
        n = len(mask)
        valid_count = int(np.sum(mask))
        return {
            'total': n,
            'valid': valid_count,
            'invalid': n - valid_count,
            'validity_rate': valid_count / max(n, 1),
        }
```

## 5. Branchless Operation Catalog

Every data-dependent validation uses one of these branchless patterns:

| Operation | NumPy Expression | Branchless? |
|-----------|-----------------|-------------|
| Greater than | `np.greater(a, b)` | ✅ |
| Less than | `np.less(a, b)` | ✅ |
| Equal | `np.equal(a, b)` | ✅ |
| Logical AND | `np.logical_and(a, b)` | ✅ |
| Logical NOT | `np.logical_not(a)` | ✅ |
| Bitwise AND (mask) | `np.bitwise_and(mask, cond, out=mask)` | ✅ |
| Absolute value | `np.abs(x)` | ✅ |
| Clamp | `np.clip(x, lo, hi)` | ✅ |
| Select | `np.where(cond, a, b)` | ✅ |
| Sign extraction | `np.signbit(x)` | ✅ |
| Diff | `np.diff(x)` | ✅ |

**Anti-patterns (NOT branchless):**
- `if array[i] > threshold:` — scalar branch in loop
- `try: ... except:` — exception-based branching
- `for x in array: if x > 0:` — Python-level iteration with branch

## 6. Validity Mask Lifecycle

```
Input batch (n ticks)
    │
    ▼
mask = [1, 1, 1, ..., 1]   (all valid)
    │
    ├── Layer 1: price bounds
    │   mask &= (price > lower) & (price < upper)
    │
    ├── Layer 1: volume sanity
    │   mask &= (volume <= max_vol)
    │
    ├── Layer 1: timestamp monotonicity
    │   mask &= (dt >= 0) for each consecutive pair
    │
    ├── Layer 2: exchange-specific gate
    │   mask &= ~causal_violations
    │
    └── Output: mask[i] = 1 iff tick i passes ALL checks
```

The mask is applied AFTER the full pipeline. Invalid ticks are:
- Excluded from ring buffer write
- Counted in shadow validation statistics
- Never seen by downstream consumers

## 7. Falsification Conditions

1. **Non-monotonic exchange feeds**: Some exchanges send out-of-order ticks
   (e.g., late trade reports). Our monotonicity check rejects these as invalid.
   If the exchange's protocol explicitly allows late reports, this validator
   produces incorrect results.

2. **Sub-tick price updates**: If an exchange sends price updates at a rate
   faster than the timestamp resolution (e.g., multiple ticks in the same
   nanosecond), the monotonicity check rejects all but the first. This is
   correct behavior but loses data.

3. **Auction phase detection**: The auction gate cannot distinguish between
   pre-auction, auction, and post-auction phases without external state.
   All ticks are accepted, potentially passing invalid post-auction ticks
   that should follow order-driven rules.

4. **Cross-venue timestamp synchronization**: If data from two venues is
   merged before validation, timestamp monotonicity may fail even though
   each venue's data is individually monotonic.

5. **Negative volumes**: Q48.16 is unsigned, so negative volumes cannot be
   represented. A decode error that produces a very large uint64 value
   would be caught by the volume sanity check, but the error message
   would say "volume too large" rather than "negative volume."

---

## AZ Xülasəsi

Bu spesifikasiya MMS Causal Raw Data Engine V2 üçün seçimli budaqsız doğrulama
pipeline-nı müəyyən edir. "Seçimli budaqsız" o deməkdir ki, yalnız məlumatdan asılı
şərtlər (qiymət > 0, həcm < max, vaxt artımı) budaqsız NumPy əməliyyatları ilə
həyata keçirilir. Struktural qərarlər (birja tipi, partiya ölçüsü) normal idarə
axını istifadə edir. Üç birja tipi üçün xüsusi səbəb qapıları təmin edilmişdir:
sifariş əsaslı (order-driven), kotirovka əsaslı (quote-driven) və hərrac (auction).
Bütün etibarlılıq maskası hesablamaları əvvəlcədən ayrılmış buferlərdə aparılır.
