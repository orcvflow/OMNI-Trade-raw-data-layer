---
tags: [workflow, search-schema, execution-order]
category: execution-protocol
module: causal-raw-data-engine
created: 2026-07-11
version: 1.0
---

# MMS Raw Data Engine — Axtarış və İcra Sxemi

> Bu sənəd 18 promptun hansı ardıcıllıqla, hansı agent tərəfindən, və hansı çıxış meyarları ilə icra olunacağını müəyyən edir.

---

## 📋 İcra Protokolunun 3 Qızıl Qaydası

1. **Əvvəlcə Ədəbiyyat, Sonra Kod** — Heç bir mühəndislik spec-iDOI-doğrulanmamış ədəbiyyata əsaslanaraq yazıla bilməz
2. **Hər Agent Bir Rol** — Agent-lər rollarını dəyişə bilməz; "Raw Data Engine Builder" master rolu digər 5 rolu sintez edir
3. **Falsifikasiya = Çıxış Şərti** — Hər spec-in sonunda "bu nə vaxt SƏHV olar?" sualına cavab YOXDURSA, spec qəbul edilmir

---

## 🔀 Tam İcra Sxemi

```
FAZA 1: AKADEMİK TƏMƏL (Paralel — 6 agent eyni anda)
═══════════════════════════════════════════════════════

  Agent-A ──▶ 01_rough_path_signature_theory.md
  Agent-B ──▶ 02_hamiltonian_mechanics_finance.md
  Agent-C ──▶ 03_fixed_point_arithmetic_hft.md
  Agent-D ──▶ 04_branchless_programming_cpu.md
  Agent-E ──▶ 05_ring_buffer_zero_alloc.md
  Agent-F ──▶ 06_causal_inference_tick_data.md

  ÇIXIŞ MEYARI: Hər agent minimum 5 DOI-doğrulanmış paper qaytarmalıdır
  UĞURSUZLUQ: < 5 DOI paper → agent yenidən işləyir (max 3 cəhd)
  
  ↓ Bütün 6 agent tamamlandı

FAZA 2: ROLLARIN YARADILMASI (Paralel — 6 agent)
═══════════════════════════════════════════════════════

  Agent-G ──▶ 01_axiomatic_systems_engineer.md
  Agent-H ──▶ 02_rough_path_mathematician.md
  Agent-I ──▶ 03_fixed_point_arithmetic_specialist.md
  Agent-J ──▶ 04_branchless_code_auditor.md
  Agent-K ──▶ 05_hot_path_performance_engineer.md
  Agent-L ──▶ 06_raw_data_engine_builder.md    ← MASTER ROL

  ÇIXIŞ MEYARI: Hər rol "Rədd Etmə Qaydaları" + "Kod Nümunələri" ehtiva edir
  UĞURSUZLUQ: Kod nümunəsi yoxdur → agent yenidən işləyir
  
  ↓ Bütün 6 rol tamamlandı

FAZA 3: MÜHƏNDİSLİK SPECLƏRİ (Pipelined — ardıcıl asılılıq)
═══════════════════════════════════════════════════════════════

  Agent-M ──▶ 02_q32_32_fixed_point_spec.md     ← ƏVVƏL (digər speclər buna əsaslanır)
              │
              ▼
  Agent-N ──▶ 03_branchless_tick_validation.md   ← Q32.32 əməliyyatlarını istifadə edir
  Agent-O ──▶ 04_hamiltonian_energy_matrix.md    ← Q32.32 əməliyyatlarını istifadə edir
  Agent-P ──▶ 05_rough_path_signature_computation.md  ← Q32.32 əməliyyatlarını istifadə edir
              │
              ▼ (hamısı tamamlandı)
              
  Agent-Q ──▶ 01_causal_raw_data_engine_class.md  ← SİNTEZ (yuxarıdakı 4-ü birləşdirir)
              │
              ▼
              
  Agent-R ──▶ 06_axiomatic_unit_tests.md         ← DOĞRULAMA (bütün specləri test edir)

  ÇIXIŞ MEYARI: Hər spec-də TAMAMLAYICI Python kodu var (placeholder yoxdur)
  UĞURSUZLUQ: "TODO" və ya "..." varsa → agent yenidən işləyir
```

---

## 📐 Agent Konfiqurasiyası

### Akademik Axtarış Agent-ləri (Faza 1)
```yaml
model: research-grade (deep search capability)
tools: [web_search, web_fetch, file_write]
system_prompt: |
  Sən akademik tədqiqatçisan. Vəzifən:
  1. Verilmiş axtarış sorğularını arXiv, Semantic Scholar, Google Scholar-da icra et
  2. Hər tapılan paper-in DOI-ni doi.org-da doğrula
  3. DOI doğrulanmayan paper-ləri "🔴 UNVERIFIED" kimi işarələ
  4. Minimum 5 DOI-doğrulanmış paper tap
  5. Nəticəni verilmiş şablonda yaz
output_format: markdown (search prompt template-ə uyğun)
timeout: 30 min per agent
```

### Sistem Rolu Agent-ləri (Faza 2)
```yaml
model: code-generation-grade
tools: [file_write]
system_prompt: |
  Sən prompt mühəndisisən. Vəzifən:
  1. Verilmiş ixtisas sahəsi üçün DETALLI sistem rolu yaz
  2. Rolun "Rədd Etmə Qaydaları" (minimum 10 maddə) olmalıdır
  3. Rolun "Kod Nümunələri" (minimum 5 before/after cütü) olmalıdır
  4. MMS Konstitusiyasının 7 Rolu Ruthless Council-ə istinad etməlidir
  5. Azərbaycan dilində xülasə əlavə et
output_format: markdown (system role template-ə uyğun)
timeout: 20 min per agent
```

### Mühəndislik Spec Agent-ləri (Faza 3)
```yaml
model: code-generation-grade (highest capability)
tools: [file_write, bash (for numpy verification)]
system_prompt: |
  Sən MMS Konstitusiyasına tabe olan mühəndislik spesifikasiya yazıçısısan.
  1. Hər spec TAMAMLANMIŞ Python/NumPy kodu ehtiva etməlidir
  2. "TODO", "...", "implement later" QADAĞANDIR
  3. Bütün hot path əməliyyatları branchless olmalıdır
  4. Q32.32 fixed-point istifadə edilməlidir
  5. Falsifikasiya şərtləri mütləqdir
  6. Kod numpy ilə import edilib test edilə bilməlidir
output_format: markdown with embedded python code
timeout: 45 min per agent (code generation is slow)
```

---

## 🔄 Asılılıq Matrisi

```
              │ 01_rough │ 02_hamilton │ 03_fixed │ 04_branch │ 05_ring │ 06_causal
              │  _path   │  _mechanics │  _point  │  _less    │ _buffer │ _inference
──────────────┼──────────┼─────────────┼──────────┼───────────┼─────────┼──────────
Role 01 (Aksio)│    ●     │      ●      │    ●     │     ●     │    ●    │    ○
Role 02 (Rough)│    ●     │      ○      │    ○     │     ○     │    ○    │    ●
Role 03 (Fixed)│    ○     │      ○      │    ●     │     ●     │    ○    │    ○
Role 04 (Branch)│   ○     │      ○      │    ●     │     ●     │    ○    │    ○
Role 05 (Hot)  │    ○     │      ○      │    ○     │     ●     │    ●    │    ○
Role 06 (Build)│   ●     │      ●      │    ●     │     ●     │    ●    │    ●

Spec 01 (Core) │    ●     │      ●      │    ●     │     ●     │    ●    │    ●
Spec 02 (Q32)  │    ○     │      ○      │    ●     │     ○     │    ○    │    ○
Spec 03 (Valid)│   ○      │      ○      │    ●     │     ●     │    ○    │    ●
Spec 04 (Hamilt)│  ○      │      ●      │    ●     │     ○     │    ○    │    ○
Spec 05 (Signat)│  ●      │      ○      │    ●     │     ○     │    ●    │    ○
Spec 06 (Tests)│   ●      │      ●      │    ●     │     ●     │    ●    │    ●

● = birbaşa asılılıq (bu paper/rol/spec olmadan yaradıla bilməz)
○ = dolayı asılılıq (kontekst üçün faydalı, amma kritik deyil)
```

---

## ✅ Keyfiyyət Qapıları (Quality Gates)

### Qapı 1: Akademik Təməl Doğrulaması
```
HƏR academic search faylı üçün:
  [✓] Minimum 5 DOI-doğrulanmış paper var
  [✓] Hər paper-in arXiv/DOI linki var
  [✓] "Falsifikasiya" bölməsi mövcuddur
  [✓] Azərbaycan xülasəsi var
  [✓] MMS Konstitusiyasına istinad var
  
  Bütün 5 şərt ödənməsə → Faza 2-yə keçmə
```

### Qapı 2: Rol Tərifi Doğrulaması
```
HƏR system role faylı üçün:
  [✓] "Rədd Etmə Qaydaları" minimum 10 maddə
  [✓] "Kod Nümunələri" minimum 5 before/after
  [✓] MMS Konstitusiyasının §1 (7 Rol) referansı
  [✓] Rol digər rollarla konflikt etmir
  [✓] Azərbaycan xülasəsi var
  
  Bütün 5 şərt ödənmsə → Faza 3-ə keçmə
```

### Qapı 3: Mühəndislik Spec Doğrulaması
```
HƏR engineering spec faylı üçün:
  [✓] Tamamlanmış Python kodu var (placeholder yoxdur)
  [✓] `import numpy as np` ilə işləyir
  [✓] Hot path-də if/else/try/catch YOXDUR
  [✓] Q32.32 istifadə olunur (float yoxdur)
  [✓] Falsifikasiya şərtləri göstərilib
  [✓] Etibar etiketi (🟢/🟡/🔴) var
  
  Bütün 6 şərt ödənmsə → Növbəti spec-ə keçmə
```

---

## 🚨 Xəta Bərpa Protokolü

```
ƏGƏR agent uğursuz olarsa:
  1. Agent-in çıxışını oxu
  2. Uğursuzluq səbəbini təsnif et:
     a. Kifayət qədər paper tapa bilmədi → daha geniş sorğu ilə yenidən
     b. Kod placeholder-ları var → tam kod tələbi ilə yenidən
     c. Branchless pozuntuları var → auditor rolu ilə yenidən
  3. Max 3 cəhd. 3-cü cəhddən sonra → MANUAL INTERVENTION
  
ƏGƏR DOI doğrulama uğursuz olarsa:
  1. Alternative DOI mənbəyi axtar (Crossref, OpenAlex)
  2. Paper-i "🔴 UNVERIFIED" kimi işarələ
  3. Spec-də 🔴 işarəli paper-ə istinad QADAĞANDIR
```

---

## 📈 Gözlənilən Çıxış Statistikası

| Metrika | Hədəf | Minimum |
|---------|-------|---------|
| DOI-doğrulanmış paper (ümumi) | 40+ | 30 |
| Tamamlanmış kod faylı | 6 spec | 6 |
| Kod sətirləri (ümumi) | 3000+ | 2000 |
| Branchless pozuntu | 0 | 0 |
| Placeholder ("TODO", "...") | 0 | 0 |
| Falsifikasiya şərti (ümumi) | 18+ | 18 |
| Etibar etiketi 🟢 | >80% | >60% |

---

## ⏱️ Zaman Cədvəli (Təxmini)

| Faza | Müddət | Paralellik | Agent Sayı |
|------|--------|-----------|------------|
| Faza 1: Akademik | 30 dəq | 6 paralel | 6 |
| Faza 2: Rollar | 20 dəq | 6 paralel | 6 |
| Faza 3: Speclər | 90 dəq | 2-4 paralel | 6 |
| **CƏMİ** | **~2.5 saat** | — | **18 agent** |

---

AZ Xülasəsi: Bu sənəd 18 promptun icra ardıcıllığını, agent konfiqurasiyalarını, asılılıq matrisini, keyfiyyət qapılarını və xəta bərpa protokolunu müəyyən edir. 3 fazalı paralel icra sxemi ilə ~2.5 saatda tamamlanması gözlənilir.
